{{/*
Expand the name of the chart.
*/}}
{{- define "uctc.fullname" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "uctc-cntlr.name" -}}
{{- default .Chart.Name .Values.uctcController.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "uctc-cntlr.fullname" -}}
{{- if .Values.uctcController.fullnameOverride }}
{{- .Values.uctcController.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "uctc.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
UCTC Common labels
*/}}
{{- define "uctc.labels" -}}
helm.sh/chart: {{ include "uctc.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
UCTC Controller Common labels
*/}}
{{- define "uctc-cntlr.labels" -}}
helm.sh/chart: {{ include "uctc.chart" . }}
{{ include "uctc-cntlr.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/*
Selector labels
*/}}
{{- define "uctc-cntlr.selectorLabels" -}}
app.kubernetes.io/name: {{ include "uctc-cntlr.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: {{ include "uctc-cntlr.name" . }}
version: v1
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "uctc-cntlr.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "uctc-cntlr.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
UCTC Tap template
*/}}


{{/*
Expand the name of the chart.
*/}}
{{- define "uctc-tap.name" -}}
{{- default .Chart.Name .Values.uctcTap.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "uctc-tap.fullname" -}}
{{- if .Values.uctcTap.fullnameOverride }}
{{- .Values.uctcTap.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.uctcTap.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}

{{/*
Common labels
*/}}
{{- define "uctc-tap.labels" -}}
helm.sh/chart: {{ include "uctc.chart" . }}
{{ include "uctc-tap.selectorLabels" . }}
app: {{ include "uctc-tap.name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "uctc-tap.selectorLabels" -}}
app.kubernetes.io/name: {{ include "uctc-tap.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "uctc-tap.serviceAccountName" -}}
{{- if .Values.uctcTap.serviceAccount.create }}
{{- default (include "uctc-tap.fullname" .) .Values.uctTap.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.uctcTap.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Validate that only one of openShift.route.create or ingress.create is true
*/}}
{{- define "uctc.validateRouteAndIngress" -}}
{{- if and .Values.openShift.route.create .Values.ingress.enabled -}}
{{ fail "Error: Only one of openShift.route.create or ingress.create can be true." }}
{{- end -}}
{{- end -}}

{{/*
Validate that .Values.ingress.create can only be true when .Values.ingress.enabled is true
*/}}
{{- define "uctc.validateIngressDependency" -}}
{{- if and .Values.ingress.create (not .Values.ingress.enabled) -}}
{{ fail "Error: ingress.create can be true only when ingress.enabled is true." }}
{{- end -}}
{{- end -}}
