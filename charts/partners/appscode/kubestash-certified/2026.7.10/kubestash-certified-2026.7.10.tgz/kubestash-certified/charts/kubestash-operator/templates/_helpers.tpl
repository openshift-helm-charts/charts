{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "kubestash-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kubestash-operator.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubestash-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "kubestash-operator.labels" -}}
helm.sh/chart: {{ include "kubestash-operator.chart" . }}
{{ include "kubestash-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "kubestash-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubestash-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- with .Values.podLabels }}
{{- toYaml . | nindent 0 }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubestash-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "kubestash-operator.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{- define "kubestash-operator.webhookServiceName" -}}
{{- printf "%s-webhook" (include "kubestash-operator.fullname" . ) | trunc 63 | trimPrefix "-" -}}
{{- end -}}

{{/*
Returns the appscode license
*/}}
{{- define "appscode.license" -}}
{{- .Values.license }}
{{- end }}

{{/*
Returns if the TaskQueue feature enabled or not
*/}}
{{- define "operator.enableTaskQueue" -}}
{{- .Values.taskQueue.enabled }}
{{- end }}

{{/*
Returns the maximum number of concurrent backupsessions
*/}}
{{- define "operator.maxConcurrentSessions" -}}
{{- .Values.taskQueue.maxConcurrentSessions }}
{{- end }}


{{/*
Returns the appscode license secret name
*/}}
{{- define "appscode.licenseSecretName" -}}
{{- if .Values.licenseSecretName }}
{{- .Values.licenseSecretName -}}
{{- else if .Values.license }}
{{- printf "%s-license" (include "kubestash-operator.fullname" .) -}}
{{- end }}
{{- end }}

{{/*
Returns the registry used for operator docker image
*/}}
{{- define "operator.registry" -}}
{{- list .Values.registryFQDN .Values.operator.registry | compact | join "/" }}
{{- end }}

{{/*
Returns the registry used for cleaner docker image
*/}}
{{- define "cleaner.registry" -}}
{{- list .Values.registryFQDN .Values.cleaner.registry | compact | join "/" }}
{{- end }}

{{/*
Returns whether the cleaner job YAML will be generated or not
*/}}
{{- define "cleaner.generate" -}}
{{- ternary "false" "true" .Values.cleaner.skip -}}
{{- end }}

{{- define "appscode.imagePullSecrets" -}}
{{- with .Values.imagePullSecrets -}}
imagePullSecrets:
{{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- define "image-pull-secrets" -}}
{{- with .Values.imagePullSecrets -}}
imagePullSecrets:
{{- toYaml . | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.distro.openshift -}}
{{- end }}

{{/*
Returns if ubi images are to be used
*/}}
{{- define "operator.ubi" -}}
{{ ternary "-ubi" "" (list "operator" "all" | has .Values.distro.ubi) }}
{{- end }}

{{/*
Prepare certs
*/}}
{{- define "kubestash-operator.prepare-certs" -}}
{{- if not ._caCrt }}
{{- $caCrt := "" }}
{{- $serverCrt := "" }}
{{- $serverKey := "" }}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
{{- $caCrt = "" }}
{{- $serverCrt = "" }}
{{- $serverKey = "" }}
{{- else if .Values.apiserver.servingCerts.generate }}
{{- $ca := genCA "ca" 3650 }}
{{- $cn := include "kubestash-operator.webhookServiceName" . -}}
{{- $altName1 := printf "%s.%s" $cn .Release.Namespace }}
{{- $altName2 := printf "%s.%s.svc" $cn .Release.Namespace }}
{{- $server := genSignedCert $cn nil (list $altName1 $altName2) 3650 $ca }}
{{- $caCrt =  b64enc $ca.Cert }}
{{- $serverCrt = b64enc $server.Cert }}
{{- $serverKey = b64enc $server.Key }}
{{- else }}
{{- $caCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.caCrt }}
{{- $serverCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverCrt }}
{{- $serverKey = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverKey }}
{{- end }}

{{ $_ := set $ "_caCrt" $caCrt }}
{{ $_ := set $ "_serverCrt" $serverCrt }}
{{ $_ := set $ "_serverKey" $serverKey }}

{{- end }}
{{- end }}

{{/*
Webhook CA bundle helper
*/}}
{{- define "kubestash-operator.webhook-ca-bundle" -}}
{{- if not .Values.apiserver.servingCerts.certManager.enabled }}
caBundle: {{ $._caCrt }}
{{- end }}
{{- end }}

{{/*
Webhook CA injection annotations
*/}}
{{- define "kubestash-operator.webhook-ca-inject-annotations" -}}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
cert-manager.io/inject-ca-from-secret: {{ printf "%s/%s-cert" .Release.Namespace (include "kubestash-operator.fullname" .) }}
{{- end }}
{{- end }}

{{- define "security.enableNetworkPolicy" -}}
{{- $local := .Values.networkPolicy.enabled -}}
{{- ternary "true" "false" (dig "networkPolicy" "enabled" $local (default dict .Values.global)) -}}
{{- end }}

{{/*
Returns the configured NetworkPolicy flavor.
"cilium" emits cilium.io/v2 CiliumNetworkPolicy; anything else emits the
default networking.k8s.io/v1 NetworkPolicy.
*/}}
{{- define "security.networkPolicyFlavor" -}}
{{- $local := .Values.networkPolicy.flavor | default "kubernetes" -}}
{{- dig "networkPolicy" "flavor" $local (default dict .Values.global) -}}
{{- end }}

{{/*
Returns "true" when CiliumNetworkPolicy resources should be emitted.
*/}}
{{- define "security.useCiliumNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (eq "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}

{{/*
Returns "true" when the built-in networking.k8s.io/v1 NetworkPolicy resources
should be emitted (the default flavor).
*/}}
{{- define "security.useKubernetesNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (ne "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}
