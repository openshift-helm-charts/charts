{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "kubedb-webhook-server.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kubedb-webhook-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubedb-webhook-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubedb-webhook-server.labels" -}}
helm.sh/chart: {{ include "kubedb-webhook-server.chart" . }}
{{ include "kubedb-webhook-server.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubedb-webhook-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubedb-webhook-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubedb-webhook-server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kubedb-webhook-server.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Returns the registry used for operator docker image
*/}}
{{- define "server.registry" -}}
{{- list .Values.registryFQDN .Values.server.registry | compact | join "/" }}
{{- end }}

{{/*
Returns if ubi images are to be used
*/}}
{{- define "operator.ubi" -}}
{{ ternary "-ubi" "" (list "operator" "all" | has .Values.distro.ubi) }}
{{- end }}

{{- define "docker.imagePullSecrets" -}}
{{- with .Values.imagePullSecrets -}}
imagePullSecrets:
{{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Returns the enabled monitoring agent name
*/}}
{{- define "monitoring.agent" -}}
{{- .Values.monitoring.agent }}
{{- end }}

{{/*
Returns whether the ServiceMonitor will be labeled with custom label
*/}}
{{- define "monitoring.apply-servicemonitor-label" -}}
{{- ternary "false" "true" ( empty .Values.monitoring.serviceMonitor.labels ) -}}
{{- end }}

{{/*
Returns the ServiceMonitor labels
*/}}
{{- define "monitoring.servicemonitor-label" -}}
{{- range $key, $val := .Values.monitoring.serviceMonitor.labels }}
{{ $key }}: {{ $val }}
{{- end }}
{{- end }}

{{/*
Returns whether the NetworkPolicy should be enabled.
Local networkPolicy.enabled wins; falls back to global.networkPolicy.enabled.
*/}}
{{- define "security.enableNetworkPolicy" -}}
{{- $local := .Values.networkPolicy.enabled -}}
{{- ternary "true" "false" (dig "networkPolicy" "enabled" $local (default dict .Values.global)) -}}
{{- end }}

{{/*
Returns the configured NetworkPolicy flavor.
"cilium" emits cilium.io/v2 CiliumNetworkPolicy; anything else emits the
default networking.k8s.io/v1 NetworkPolicy. The local chart's
networkPolicy.flavor wins over the global value.
*/}}
{{- define "security.networkPolicyFlavor" -}}
{{- $local := .Values.networkPolicy.flavor | default "kubernetes" -}}
{{- dig "networkPolicy" "flavor" $local (default dict .Values.global) -}}
{{- end }}

{{/*
Returns "true" when CiliumNetworkPolicy resources should be emitted.
*/}}
{{- define "security.useCiliumNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (eq "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}

{{/*
Returns "true" when the built-in networking.k8s.io/v1 NetworkPolicy resources
should be emitted (the default flavor).
*/}}
{{- define "security.useKubernetesNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (ne "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.distro.openshift -}}
{{- end }}

{{/*
Prepare certs
*/}}
{{- define "kubedb-webhook-server.prepare-certs" -}}
{{- if not ._caCrt }}
{{- $caCrt := "" }}
{{- $serverCrt := "" }}
{{- $serverKey := "" }}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
{{- $caCrt = "" }}
{{- $serverCrt = "" }}
{{- $serverKey = "" }}
{{- else if .Values.apiserver.servingCerts.generate }}
{{- $ca := genCA "ca" 3650 }}
{{- $cn := include "kubedb-webhook-server.fullname" . -}}
{{- $altName1 := printf "%s.%s" $cn .Release.Namespace }}
{{- $altName2 := printf "%s.%s.svc" $cn .Release.Namespace }}
{{- $server := genSignedCert $cn nil (list $altName1 $altName2) 3650 $ca }}
{{- $caCrt =  b64enc $ca.Cert }}
{{- $serverCrt = b64enc $server.Cert }}
{{- $serverKey = b64enc $server.Key }}
{{- else }}
{{- $caCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.caCrt }}
{{- $serverCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverCrt }}
{{- $serverKey = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverKey }}
{{- end }}

{{ $_ := set $ "_caCrt" $caCrt }}
{{ $_ := set $ "_serverCrt" $serverCrt }}
{{ $_ := set $ "_serverKey" $serverKey }}

{{- end }}
{{- end }}

{{/*
Webhook CA bundle helper
*/}}
{{- define "kubedb-webhook-server.webhook-ca-bundle" -}}
{{- if not .Values.apiserver.servingCerts.certManager.enabled }}
caBundle: {{ $._caCrt }}
{{- end }}
{{- end }}

{{/*
Webhook CA injection annotations
*/}}
{{- define "kubedb-webhook-server.webhook-ca-inject-annotations" -}}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
cert-manager.io/inject-ca-from-secret: {{ printf "%s/%s-cert" .Release.Namespace (include "kubedb-webhook-server.fullname" .) }}
{{- end }}
{{- end }}
