{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "petset.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "petset.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "petset.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "petset.labels" -}}
helm.sh/chart: {{ include "petset.chart" . }}
{{ include "petset.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "petset.selectorLabels" -}}
app.kubernetes.io/name: {{ include "petset.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "petset.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "petset.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Returns the appscode license
*/}}
{{- define "appscode.license" -}}
{{- .Values.license }}
{{- end }}

{{/*
Returns the registry used for operator docker image
*/}}
{{- define "image.registry" -}}
{{- list .Values.registryFQDN .Values.image.registry | compact | join "/" }}
{{- end }}

{{- define "docker.imagePullSecrets" -}}
{{- with .Values.imagePullSecrets -}}
imagePullSecrets:
{{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Returns the enabled monitoring agent name
*/}}
{{- define "monitoring.agent" -}}
{{- .Values.monitoring.agent }}
{{- end }}

{{/*
Returns whether the ServiceMonitor will be labeled with custom label
*/}}
{{- define "monitoring.apply-servicemonitor-label" -}}
{{- ternary "false" "true" ( empty .Values.monitoring.serviceMonitor.labels ) -}}
{{- end }}

{{/*
Returns the ServiceMonitor labels
*/}}
{{- define "monitoring.servicemonitor-label" -}}
{{- range $key, $val := .Values.monitoring.serviceMonitor.labels }}
{{ $key }}: {{ $val }}
{{- end }}
{{- end }}

{{/*
Returns whether the NetworkPolicy should be enabled
*/}}
{{- define "security.enableNetworkPolicy" -}}
{{- ternary "true" "false" .Values.networkPolicy.enabled -}}
{{- end }}

{{/*
Returns the configured NetworkPolicy flavor.
"cilium" emits cilium.io/v2 CiliumNetworkPolicy; anything else emits the
default networking.k8s.io/v1 NetworkPolicy. The global value wins so the
flavor propagates when this chart is pulled in as a subchart.
*/}}
{{- define "security.networkPolicyFlavor" -}}
{{- $local := .Values.networkPolicy.flavor | default "kubernetes" -}}
{{- dig "networkPolicy" "flavor" $local (default dict .Values.global) -}}
{{- end }}

{{/*
Returns "true" when CiliumNetworkPolicy resources should be emitted.
*/}}
{{- define "security.useCiliumNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (eq "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}

{{/*
Returns "true" when the built-in networking.k8s.io/v1 NetworkPolicy resources
should be emitted (the default flavor).
*/}}
{{- define "security.useKubernetesNetworkPolicy" -}}
{{- and (eq "true" (include "security.enableNetworkPolicy" .)) (ne "cilium" (include "security.networkPolicyFlavor" .)) | ternary "true" "false" -}}
{{- end }}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.distro.openshift -}}
{{- end }}

{{/*
Returns if ubi images are to be used
*/}}
{{- define "operator.ubi" -}}
{{ ternary "-ubi" "" (list "operator" "all" | has .Values.distro.ubi) }}
{{- end }}

{{/*
Prepare certs
*/}}
{{- define "petset.prepare-certs" -}}
{{- if not ._caCrt }}
{{- $caCrt := "" }}
{{- $serverCrt := "" }}
{{- $serverKey := "" }}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
{{- $caCrt = "" }}
{{- $serverCrt = "" }}
{{- $serverKey = "" }}
{{- else if .Values.apiserver.servingCerts.generate }}
{{- $ca := genCA "ca" 3650 }}
{{- $cn := include "petset.fullname" . -}}
{{- $altName1 := printf "%s.%s" $cn .Release.Namespace }}
{{- $altName2 := printf "%s.%s.svc" $cn .Release.Namespace }}
{{- $server := genSignedCert $cn nil (list $altName1 $altName2) 3650 $ca }}
{{- $caCrt =  b64enc $ca.Cert }}
{{- $serverCrt = b64enc $server.Cert }}
{{- $serverKey = b64enc $server.Key }}
{{- else }}
{{- $caCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.caCrt }}
{{- $serverCrt = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverCrt }}
{{- $serverKey = required "Required when apiserver.servingCerts.generate is false" .Values.apiserver.servingCerts.serverKey }}
{{- end }}

{{ $_ := set $ "_caCrt" $caCrt }}
{{ $_ := set $ "_serverCrt" $serverCrt }}
{{ $_ := set $ "_serverKey" $serverKey }}

{{- end }}
{{- end }}

{{/*
Webhook CA bundle helper
*/}}
{{- define "petset.webhook-ca-bundle" -}}
{{- if not .Values.apiserver.servingCerts.certManager.enabled }}
caBundle: {{ $._caCrt }}
{{- end }}
{{- end }}

{{/*
Webhook CA injection annotations
*/}}
{{- define "petset.webhook-ca-inject-annotations" -}}
{{- if .Values.apiserver.servingCerts.certManager.enabled }}
cert-manager.io/inject-ca-from-secret: {{ printf "%s/%s-cert" .Release.Namespace (include "petset.fullname" .) }}
{{- end }}
{{- end }}