# Denegra Derbent Helm chart

Denegra Derbent, Denegra's AI gateway, on Red Hat OpenShift or Kubernetes: the gateway, the TLS
front (`integrations/tls-front/Caddyfile`), PostgreSQL and Valkey, and LibreChat with MongoDB
when wanted. Every pod meets OpenShift's `restricted-v2` SCC and Kubernetes' `restricted`
Pod Security level; no pod needs a custom SCC. The full guide, with what was and was not
tested, is [docs/openshift.md](../../../docs/openshift.md).

```bash
oc new-project derbent
oc create secret generic derbent-secrets --from-file=secrets/   # one file per key
helm install derbent deploy/helm/derbent -f my-values.yaml
```

| Value | Default | Meaning |
| --- | --- | --- |
| `environment` | `prod` | `DENEGRA_ENV` |
| `images.gateway` | (required) | The gateway image, by digest |
| `gateway.secretName` | (required) | The Secret holding `MASTER_KEY`, `SALT_KEY`, `DATABASE_URL`, `REDIS_URL`, `AIGATE_API_KEY`, and the databases' passwords |
| `gateway.secretFiles` | the five keys above | Keys read as `DENEGRA_<ENV>_<KEY>_FILE` |
| `licence.existingSecret` | `""` | The Secret with Denegra's licence (key `licence.jwt`); optional, without it demo mode ([docs/licensing.md](../../../docs/licensing.md)) |
| `gateway.settings` | `{}` | Non-secret `DENEGRA_<ENV>_*` settings, without the prefix |
| `gateway.environmentsToml` | `""` | Replaces `config/environments.toml` (models, providers, policies) |
| `gateway.resources` | 4 CPU, 8 Gi | `docs/system-requirements.md` |
| `gateway.egress` | TCP 443, UDP 514, any address | Where the gateway may connect |
| `front.adminCidrs` | `127.0.0.1/32 ::1/128` | Who reaches the admin listener (`oc port-forward`) |
| `front.tls` | OpenShift service CA | The front's certificate |
| `route` | on, `reencrypt` | OpenShift Route to the user listener |
| `ingress` | off | Kubernetes Ingress instead of a Route |
| `postgresql.mode`, `valkey.mode` | `internal` | `external` uses your services |
| `networkPolicy` | on | Default deny; router to front, front to gateway, gateway to databases |
| `podSecurityContext` | `{}` | Vanilla Kubernetes with the chat UI only: a non-root UID for MongoDB |
| `chat.enabled` | `false` | LibreChat and MongoDB |

`values.schema.json` refuses unknown values, images without a digest, secret-looking names
in `gateway.settings` and UID 0. `tests/test_helm_chart.py` lints and renders the chart;
`tests/helm/kind_smoke.sh` installs it on kind. `helm test <release>` checks the installed gateway.
