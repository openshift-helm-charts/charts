{{/* Names and the shared pod and container security settings. */}}

{{- define "derbent.name" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 40 | trimSuffix "-" -}}
{{- end -}}

{{- define "derbent.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}

{{/* Selector labels of one component: include "derbent.selector" (list . "gateway") */}}
{{- define "derbent.selector" -}}
{{- $root := index . 0 -}}
app.kubernetes.io/name: {{ $root.Chart.Name }}
app.kubernetes.io/instance: {{ $root.Release.Name }}
app.kubernetes.io/component: {{ index . 1 }}
{{- end -}}

{{/* No runAsUser here: OpenShift's restricted-v2 assigns one; podSecurityContext may add it
     for vanilla Kubernetes. */}}
{{- define "derbent.podSecurity" -}}
securityContext:
  {{- with .Values.podSecurityContext }}
  {{- toYaml . | nindent 2 }}
  {{- end }}
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
{{- end -}}

{{- define "derbent.containerSecurity" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop: [ALL]
{{- end -}}

{{- define "derbent.pullSecrets" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{/* The Secret the gateway and the in-chart services read; required before install. */}}
{{- define "derbent.secretName" -}}
{{- required "gateway.secretName: create the Secret first (docs/openshift.md)" .Values.gateway.secretName -}}
{{- end -}}

{{- define "derbent.envPrefix" -}}
{{- printf "DENEGRA_%s_" (upper .Values.environment) -}}
{{- end -}}
