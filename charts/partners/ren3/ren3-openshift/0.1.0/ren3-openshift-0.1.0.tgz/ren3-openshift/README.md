# ren3-openshift

ReN3 bundled with its own database and vector database, as a single Helm
release for OpenShift.

| Component | Source | Notes |
|---|---|---|
| ReN3 server / ingestor / web / workflow | adapted from `app/ren3` | same images, same service names |
| MariaDB | `charts/mariadb` (written for this chart) | in-cluster stand-in for the Aurora MySQL cluster in `terraform/aurora.tf` |
| Qdrant | `charts/qdrant` (vendored from `app/qdrant`, v1.16.0) | unchanged chart, OpenShift overrides applied from the parent `values.yaml` |

Both subcharts are vendored, so `helm install` needs no chart repository
access and the packaged `.tgz` is self-contained for a disconnected
cluster.

## Install

Published to Docker Hub as an OCI artifact, so no `helm repo add` is needed:

```sh
oc new-project ren3
helm install ren3 oci://registry-1.docker.io/qianhaoh/ren3-openshift --version 0.1.0 -n ren3 --set route.host=ren3.apps.<cluster-domain>
```

Or from this working copy:

```sh
helm install ren3 ./ren3-openshift -n ren3 --set route.host=ren3.apps.<cluster-domain>
```

Install it as `ren3` (or set `fullnameOverride`): resource names are
derived from `nameOverride: ren3`, and every route, cronjob target and
datastore hostname is computed from the release, so other release names
work too — they just produce `<release>-server`, `<release>-web` and so on.

Uninstall leaves two things behind on purpose, both annotated
`helm.sh/resource-policy: keep`: the MariaDB credentials secret and the
shared-storage PVC. Delete them by hand if you really want the data gone.

## What differs from the EKS chart (`app/ren3`)

| Area | `app/ren3` (EKS) | here |
|---|---|---|
| Ingress | Istio `Gateway` + `VirtualService`, TLS at the NLB via ACM | OpenShift `Route` per component, edge TLS (`route.*`). The Istio templates are still present but `istio.enabled: false` by default — turn them on only with OpenShift Service Mesh installed. |
| Path rewriting | VirtualService rewrites `/backend` → `/` | `haproxy.router.openshift.io/rewrite-target: /` on the path-based route, same effect |
| Security context | `runAsUser: 1002`, `runAsGroup: 1002`, `fsGroup: 1002` | empty, so the `restricted-v2` SCC assigns a UID from the project's range (`openshift.deferSecurityContextToSCC`) |
| Shared storage | AWS EFS `StorageClass` (`efs.csi.aws.com`) + RWX PVC | `sharedStorage.*` — a plain RWX PVC against any class (e.g. `ocs-storagecluster-cephfs`); no provisioner-specific StorageClass is created |
| Database | Aurora MySQL 8.0, provisioned by terraform | `charts/mariadb` StatefulSet + PVC in the same namespace |
| Qdrant / MongoDB | separate helmfile releases | Qdrant is part of this release; MongoDB is not bundled — keep deploying it separately |
| Secrets | Vault Secrets Operator (`vault.enabled: true`) | same templates, off by default; needs the `secrets.hashicorp.com/v1beta1` CRDs |
| Init containers | `busybox` | `registry.access.redhat.com/ubi9/ubi-minimal` (`vault.symlinkImage`) |

## Routes

All three routes share `route.host`; HAProxy matches the most specific
path first, so `/` (web), `/backend` (server) and `/ren3-workflow`
(workflow, only when `workflow.enabled`) coexist.

Keep `web.configMapData.env.js` in step with `route.host` — those URLs
are what the browser calls, and nothing validates them for you:

```yaml
route:
  host: ren3.apps.ocp.example.com
web:
  configMapData:
    env.js: |-
      window.__ENV__ = {
        REACT_APP_BACKEND_URL: 'https://ren3.apps.ocp.example.com/backend/',
        REACT_APP_PORTAL_URL: 'https://ren3.apps.ocp.example.com/'
      }
```

After installing, check that the rewrite actually reaches the server
rather than the web app:

```sh
curl -sS https://$(oc get route ren3-backend -n ren3 -o jsonpath='{.spec.host}')/backend/health
```

## Database

`charts/mariadb` runs the sclorg MariaDB 10.11 image
(`quay.io/sclorg/mariadb-1011-c9s`), which is built to run under an
arbitrary SCC-assigned UID. For a disconnected cluster with a Red Hat
pull secret, switch to `registry.redhat.io/rhel9/mariadb-1011` and pin a
digest or dated tag.

Parity with `terraform/aurora.tf`:

| Terraform | Here |
|---|---|
| `engine = "aurora-mysql"`, `engine_version = "8.0"` | MariaDB 10.11 — same wire protocol and client drivers |
| `master_username = "root"` + `manage_master_user_password` | `MYSQL_ROOT_PASSWORD`, generated into the release's secret |
| `instance_class = db.t3.medium` | `mariadb.resources` (2 CPU / 4Gi limit) |
| `storage_encrypted = true` | pick an encrypted `StorageClass` via `mariadb.persistence.storageClassName` — the chart cannot enforce this |
| `enabled_cloudwatch_logs_exports` | error and slow-query logs go to the pod's stderr for the cluster log collector |
| multi-AZ instances, automated backups, snapshots | **not reproduced.** One replica, no backup job. Use a storage-level snapshot schedule or a `mysqldump` CronJob if this database matters. |

Passwords left empty in values are generated on first install and read
back from the live secret on upgrade, so they stay stable. Supply your
own with `mariadb.auth.existingSecret` (keys `MYSQL_USER`,
`MYSQL_PASSWORD`, `MYSQL_DATABASE`, `MYSQL_ROOT_PASSWORD`).

```sh
oc get secret ren3-mariadb -n ren3 -o jsonpath='{.data.MYSQL_PASSWORD}' | base64 -d
```

## How the app learns where the datastores are

`datastores.enabled` (default true) injects these into the server,
ingestor and workflow containers:

```
DB_HOST  DB_PORT  DB_NAME  DB_USER  DB_PASSWORD (secretKeyRef)
QDRANT_HOST  QDRANT_PORT  QDRANT_GRPC_PORT  QDRANT_URL
```

The names are a guess at the application's interface — the EKS
deployments feed these settings in through Vault `config.json`, so
nothing in this repo states what the server actually reads. **Confirm the
names against the application before going live.** If they differ, map
them instead of restating hosts and passwords:

```yaml
datastores:
  aliases:
    MYSQL_HOST: host
    MYSQL_USER: user
    MYSQL_PASSWORD: password
    MYSQL_DATABASE: name
    VECTOR_DB_URL: qdrantUrl
```

Valid source keys: `host`, `port`, `name`, `user`, `password`, `uri`,
`qdrantHost`, `qdrantPort`, `qdrantGrpcPort`, `qdrantUrl`. An unknown key
fails the render rather than silently producing an empty variable.

To point at an external database (keeping Aurora, say), set
`mariadb.enabled: false` and fill in `datastores.database.*` including
`existingSecret` / `existingSecretPasswordKey`. Set
`datastores.enabled: false` to go back to Vault-only configuration.

## Security contexts

With `openshift.deferSecurityContextToSCC: true` (default) the chart
emits no `runAsUser`/`fsGroup` and lets `restricted-v2` assign them; the
SCC also defaults in `allowPrivilegeEscalation: false`, dropped
capabilities and the seccomp profile on admission. Set it to `false` to
write those fields out explicitly, or override per component with
`<component>.securityContext` (pod) and
`<component>.containerSecurityContext` (container).

The Qdrant overrides in `values.yaml` null out the upstream chart's
`fsGroup: 3000` / `runAsUser: 1000` / `runAsGroup: 2000`. They must stay
`null` rather than an empty map — Helm merges subchart values key by key,
so an empty map would leave the upstream UIDs in place and the pod would
be rejected. The `-unprivileged` Qdrant image is selected for the same
reason, which also removes the chart's root `chown` init container.

## Verified on a live cluster

Deployed and tested on ROSA 4.x (`api.rm3.7wse.p1.openshiftapps.com`,
project `thereentryfoundation-dev`) with
`docker.io/qianhaoh/ren3-{server:v1.15.12,ingestor:v1.15.6,web:v1.15.10}`:

```sh
helm install ren3 ./ren3-openshift -n <project>   --set route.host=ren3-<project>.apps.<cluster-domain>   --set sharedStorage.storageClassName=efs-sc
```

What the run confirmed:

- **SCC** — MariaDB and Qdrant are admitted under `restricted-v2` and run
  with the project's assigned UID (`1012400000`, `fsGroup` to match). No
  `anyuid` or custom SCC needed.
- **MariaDB** — 10.11.18 comes up on a `gp3` PVC; the `ren3` database and
  user work (`SELECT`/`CREATE TABLE`/`INSERT` all verified), and the
  generated password round-trips from the secret.
- **Qdrant** — 1.16.0 answers on `ren3-qdrant:6333`; collection create and
  list verified through the service name the app pods are given.
- **Route rewrite** — `/` returns the web app (200), HTTP redirects to
  HTTPS, and the prefix strip is exact: `/backend/health` arrives at the
  server as `/health`, `/backend/api/v1/ping` as `/api/v1/ping`.
- **App wiring** — server and ingestor both connect to the bundled
  MariaDB using the default `datastores.aliases`, and the ingestor cronjob
  completes against the ingestor service.

Two things the run exposed, both now the chart's defaults:

1. The app images cannot write `/usr/app/rn3-data` under an assigned UID,
   so `sharedStorage` is enabled by default and needs an RWX class.
2. The app reads lowercase `db_*` keys from its own `.env`, not `DB_*` —
   hence the default aliases.

### Still outstanding

- **Schema.** The bundled MariaDB starts empty and neither image ships
  migrations, so the server logs `Table 'ren3.platform_settings' doesn't
  exist` (it falls back to config defaults and keeps serving) and the
  ingestor logs the same for `background_jobs`. Load a dump from an
  existing environment, or add a post-install Job to this chart, before
  calling the deployment complete.
- **Vector database.** Both images' `.env` points `vector_host` at a
  Pinecone endpoint, so they do not read the chart's `QDRANT_*`
  variables. Confirm whether these builds speak the Qdrant API; if they
  do, map `vector_host: qdrantUrl` under `datastores.aliases` and set
  `vector_dbname` / `vector_apikey` yourself.
- **Image contents.** Those `.env` files ship inside the public Docker Hub
  images with real-looking credentials in them (database password,
  Pinecone API key, Azure AD client secret). Anyone who can pull the image
  can read them. Worth rotating and moving to Vault or a Secret.

## Publishing a new version

```sh
helm lint .
helm package . --destination /tmp
HELM_REGISTRY_CONFIG="$HOME/.docker/config.json" helm push /tmp/ren3-openshift-<version>.tgz oci://registry-1.docker.io/qianhaoh
```

`HELM_REGISTRY_CONFIG` reuses the existing `docker login` credentials
(including a credential helper) instead of writing a second plaintext copy
into `~/.config/helm/registry/config.json`.

Bump `version` in `Chart.yaml` for every push — Docker Hub will happily
overwrite an existing tag, which silently changes the digest under anyone
who already pulled it. Bump `appVersion` when the default image tags in
`values.yaml` move.

Check what is live:

```sh
helm show chart oci://registry-1.docker.io/qianhaoh/ren3-openshift --version <version>
```

## Verify before shipping

```sh
helm lint ren3-openshift
helm template ren3 ren3-openshift -n ren3 --set route.host=ren3.apps.example.com

# on the cluster, dry run against the live API (catches SCC and CRD problems)
helm install ren3 ./ren3-openshift -n ren3 --dry-run=server
```

First install is worth watching: the two StatefulSets need their PVCs
bound by a default StorageClass, and the app images come from a private
ECR registry, so set `imagePullSecrets` unless they have been mirrored
into the cluster's registry.
