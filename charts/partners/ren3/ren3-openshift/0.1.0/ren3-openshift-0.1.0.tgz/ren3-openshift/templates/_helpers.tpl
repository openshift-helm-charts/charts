{{/*
Expand the name of the chart.
*/}}
{{- define "ren3.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ren3.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ren3.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ren3.labels" -}}
helm.sh/chart: {{ include "ren3.chart" . }}
{{ include "ren3.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ren3.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ren3.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ren3.serviceAccountName" -}}
{{- default (include "ren3.fullname" .) .Values.serviceAccount.name }}
{{- end }}

{{/*
ConfigMaps data
*/}}
{{- define "ren3.configMapData" -}}
{{- range $envKey, $envVal := .Values.env.normal }}
  {{ $envKey | upper }}: {{ $envVal | quote }}
{{- end }}
{{- end }}

{{/*
Secrets data
*/}}
{{- define "ren3.secretData" -}}
{{- range $envKey, $envVal := .Values.env.secret }}
  {{ $envKey | upper }}: {{ $envVal | b64enc | quote }}
{{- end }}
{{- end }}

{{/*
Name of the bundled MariaDB release, mirroring charts/mariadb/templates/_helpers.tpl.
Kept in step with that helper so the parent can address the subchart's
Service and Secret without reaching into the subchart's scope.
*/}}
{{- define "ren3.mariadb.fullname" -}}
{{- $mariadb := .Values.mariadb | default dict }}
{{- if $mariadb.fullnameOverride }}
{{- $mariadb.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (default "mariadb" $mariadb.nameOverride) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Name of the bundled Qdrant release, mirroring charts/qdrant/templates/_helpers.tpl
(the upstream chart's "if release name contains chart name" rule).
*/}}
{{- define "ren3.qdrant.fullname" -}}
{{- $qdrant := .Values.qdrant | default dict }}
{{- if $qdrant.fullnameOverride }}
{{- $qdrant.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default "qdrant" $qdrant.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Resolved datastore coordinates, as a JSON dict, so every consumer agrees
on them. Explicit values under .Values.datastores win; otherwise the
bundled subcharts' in-cluster services are used.

Keys: host port name user uri qdrantHost qdrantPort qdrantGrpcPort qdrantUrl
*/}}
{{- define "ren3.datastore.values" -}}
{{- $ds := .Values.datastores | default dict }}
{{- $db := $ds.database | default dict }}
{{- $qd := $ds.qdrant | default dict }}
{{- $mariadbAuth := (.Values.mariadb | default dict).auth | default dict }}
{{- $host := $db.host | default (include "ren3.mariadb.fullname" .) }}
{{- $port := ($db.port | default 3306) | toString }}
{{- $name := $db.name | default ($mariadbAuth.database | default "ren3") }}
{{- $user := $db.user | default ($mariadbAuth.username | default "ren3") }}
{{- $qdrantHost := $qd.host | default (include "ren3.qdrant.fullname" .) }}
{{- $qdrantPort := ($qd.httpPort | default 6333) | toString }}
{{- $qdrantGrpcPort := ($qd.grpcPort | default 6334) | toString }}
{{- dict
      "host" $host
      "port" $port
      "name" $name
      "user" $user
      "uri" (printf "mysql://%s:%s/%s" $host $port $name)
      "qdrantHost" $qdrantHost
      "qdrantPort" $qdrantPort
      "qdrantGrpcPort" $qdrantGrpcPort
      "qdrantUrl" (printf "http://%s:%s" $qdrantHost $qdrantPort)
    | toJson }}
{{- end }}

{{/*
Secret holding the database password, as "name/key". Empty when no
secret is in play (external database with no existingSecret, and the
bundled MariaDB disabled) -- callers then omit DB_PASSWORD.
*/}}
{{- define "ren3.datastore.passwordRef" -}}
{{- $db := (.Values.datastores | default dict).database | default dict }}
{{- $mariadb := .Values.mariadb | default dict }}
{{- if $db.existingSecret }}
{{- printf "%s/%s" $db.existingSecret ($db.existingSecretPasswordKey | default "MYSQL_PASSWORD") }}
{{- else if $mariadb.enabled }}
{{- $auth := $mariadb.auth | default dict }}
{{- printf "%s/%s" ($auth.existingSecret | default (include "ren3.mariadb.fullname" .)) "MYSQL_PASSWORD" }}
{{- end }}
{{- end }}

{{/*
Datastore environment variables for the app containers: the canonical
DB_* / QDRANT_* names plus anything mapped through datastores.aliases.
Renders nothing when datastores.enabled is false.
*/}}
{{- define "ren3.datastoreEnv" -}}
{{- if (.Values.datastores | default dict).enabled }}
{{- $v := include "ren3.datastore.values" . | fromJson }}
{{- $passwordRef := include "ren3.datastore.passwordRef" . }}
{{- $secretName := "" }}
{{- $secretKey := "" }}
{{- if $passwordRef }}
{{- $parts := splitList "/" $passwordRef }}
{{- $secretName = index $parts 0 }}
{{- $secretKey = index $parts 1 }}
{{- end }}
- name: DB_HOST
  value: {{ $v.host | quote }}
- name: DB_PORT
  value: {{ $v.port | quote }}
- name: DB_NAME
  value: {{ $v.name | quote }}
- name: DB_USER
  value: {{ $v.user | quote }}
{{- if $secretName }}
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ $secretKey }}
{{- end }}
- name: QDRANT_HOST
  value: {{ $v.qdrantHost | quote }}
- name: QDRANT_PORT
  value: {{ $v.qdrantPort | quote }}
- name: QDRANT_GRPC_PORT
  value: {{ $v.qdrantGrpcPort | quote }}
- name: QDRANT_URL
  value: {{ $v.qdrantUrl | quote }}
{{- range $alias, $source := (.Values.datastores.aliases | default dict) }}
{{- if eq $source "password" }}
{{- if $secretName }}
- name: {{ $alias }}
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ $secretKey }}
{{- end }}
{{- else if hasKey $v $source }}
- name: {{ $alias }}
  value: {{ get $v $source | quote }}
{{- else }}
{{- fail (printf "datastores.aliases.%s: unknown source key %q (expected one of: host, port, name, user, password, uri, qdrantHost, qdrantPort, qdrantGrpcPort, qdrantUrl)" $alias $source) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Plain environment variables declared under <component>.env.normal.
Usage: include "ren3.normalEnv" .Values.server
*/}}
{{- define "ren3.normalEnv" -}}
{{- range $key, $value := ((.env | default dict).normal | default dict) }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Pod-level securityContext. The component's own securityContext wins when
set. Otherwise nothing is emitted while openshift.deferSecurityContextToSCC
is true, so the restricted-v2 SCC can assign a UID from the project's range.

Usage: include "ren3.podSecurityContext" (dict "root" $ "component" .Values.server)
*/}}
{{- define "ren3.podSecurityContext" -}}
{{- $component := .component | default dict }}
{{- if $component.securityContext }}
securityContext:
  {{- toYaml $component.securityContext | nindent 2 }}
{{- else if not (.root.Values.openshift | default dict).deferSecurityContextToSCC }}
securityContext:
  runAsNonRoot: true
{{- end }}
{{- end }}

{{/*
Container-level securityContext. The component's own
containerSecurityContext wins when set; otherwise the restricted-v2
hardening fields are emitted only when not deferring to the SCC (the SCC
defaults them in on admission).

Usage: include "ren3.containerSecurityContext" (dict "root" $ "component" .Values.server)
*/}}
{{- define "ren3.containerSecurityContext" -}}
{{- $component := .component | default dict }}
{{- if $component.containerSecurityContext }}
securityContext:
  {{- toYaml $component.containerSecurityContext | nindent 2 }}
{{- else if not (.root.Values.openshift | default dict).deferSecurityContextToSCC }}
securityContext:
  runAsNonRoot: true
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL
  seccompProfile:
    type: RuntimeDefault
{{- end }}
{{- end }}

{{/*
Name of the shared RWX claim mounted by the server and ingestor.
*/}}
{{- define "ren3.sharedStorage.claimName" -}}
{{- $shared := .Values.sharedStorage | default dict }}
{{- $shared.existingClaim | default $shared.pvcName }}
{{- end }}
