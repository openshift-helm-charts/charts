{{/*
Chart name.
*/}}
{{- define "mariadb.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified name.

Deliberately simple -- always "<release>-mariadb" unless overridden -- so
the parent chart can address this chart's Service and Secret from
"ren3.mariadb.fullname" without duplicating a naming rule. Keep the two
helpers in step if this changes.
*/}}
{{- define "mariadb.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "mariadb.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "mariadb.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "mariadb.labels" -}}
helm.sh/chart: {{ include "mariadb.chart" . }}
{{ include "mariadb.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: database
{{- end }}

{{- define "mariadb.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mariadb.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
The Secret the credentials are read from: the caller's existingSecret
when given, otherwise the one this chart creates.
*/}}
{{- define "mariadb.secretName" -}}
{{- .Values.auth.existingSecret | default (include "mariadb.fullname" .) }}
{{- end }}

{{- define "mariadb.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- .Values.serviceAccount.name | default (include "mariadb.fullname" .) }}
{{- else }}
{{- .Values.serviceAccount.name | default "default" }}
{{- end }}
{{- end }}

{{/*
Password for a given key, resolved once so the Secret and anything else
that needs it agree:
  1. an explicit value from values.yaml, else
  2. the value already stored in the live Secret (so upgrades keep it), else
  3. a freshly generated one.

Usage: include "mariadb.resolvePassword" (dict "root" . "key" "MYSQL_PASSWORD" "value" .Values.auth.password)
*/}}
{{- define "mariadb.resolvePassword" -}}
{{- if .value }}
{{- .value }}
{{- else }}
{{- $existing := lookup "v1" "Secret" .root.Release.Namespace (include "mariadb.fullname" .root) }}
{{- $current := "" }}
{{- if and $existing $existing.data (hasKey $existing.data .key) }}
{{- $current = index $existing.data .key | b64dec }}
{{- end }}
{{- $current | default (randAlphaNum 24) }}
{{- end }}
{{- end }}
