# aidaptiv-mw-console

aiDAPTIV-MW-Console is a web UI for the models that Red Hat OpenShift AI serves with KServe
(`LLMInferenceService`, `serving.kserve.io`). In the console you can:

- list the models and their state, and send a test chat completion,
- deploy a model with a short form (model URI, GPUs, vLLM arguments) on upstream vLLM,
- view and edit a model's YAML,
- see a model's performance (latency, throughput, KV cache use) from OpenShift monitoring.

Users log in with their OpenShift account through oauth-proxy. The console makes every call with the user's
own token, so cluster RBAC decides what each user can see and change. The console's ServiceAccount can only
list namespace names.

With the default values, the chart deploys:

- a Deployment with two containers: the console (`cacheebo-console`) and `ose-oauth-proxy` (Red Hat),
- a Service, whose TLS certificate the OpenShift service CA issues,
- a reencrypt Route,
- a NetworkPolicy that admits the router and the chart's test only,
- the oauth-proxy cookie Secret (generated once, kept on upgrade),
- a ClusterRole that lists namespaces,
- for `helm test` only: a pod that checks `/healthz` and that the API requires a login.

## Cluster requirements

- Red Hat OpenShift 4.12 to 4.22 (`kubeVersion`: Helm refuses newer clusters). Tested on 4.22.18 with
  OpenShift AI 3.5.2.
- Red Hat OpenShift AI with KServe, for the models. See the `phison-vllm-stack` chart for the full list.
- For the performance report: user workload monitoring
  (`enableUserWorkload: true` in `openshift-monitoring/cluster-monitoring-config`).
- A pull secret for `registry.redhat.io` (the OpenShift global pull secret has one), for oauth-proxy.

## Install

```bash
helm repo add openshift-helm-charts https://charts.openshift.io/
helm install console openshift-helm-charts/aidaptiv-mw-console -n aidaptiv-mw-console --create-namespace
helm test console -n aidaptiv-mw-console
echo https://$(oc -n aidaptiv-mw-console get route console -o jsonpath='{.spec.host}')
```

## Values

| Key | Default | Meaning |
|---|---|---|
| `image.repository` / `tag` / `digest` | `quay.io/aidaptiv-mw/console` / appVersion / `""` | console image (`images/aidaptiv-mw-console`; the chart runs `/usr/local/bin/cacheebo-console`) |
| `oauthProxy.image` | `registry.redhat.io/openshift4/ose-oauth-proxy-rhel9:v4.16` | oauth-proxy image |
| `oauthProxy.cookieSecret.existingSecret` | `""` | Secret with key `cookie-secret`; empty: generated |
| `servingImage` | `quay.io/aidaptiv-mw/vllm:0.32.0-3` | default image of models the deploy form creates |
| `namespaces` | `[]` | namespaces the console serves; empty: all but `excludeNamespaces` |
| `excludeNamespaces` | `kube-system`, `kube-public`, `kube-node-lease` | never served |
| `prometheus.url` | `https://thanos-querier.openshift-monitoring.svc:9092` | Thanos querier tenancy port; empty turns the report off |
| `route.enabled` / `route.host` | `true` / `""` | Route; empty host lets OpenShift pick one |
| `networkPolicy.enabled` | `true` | admit only the router and the test |
| `resources`, `nodeSelector`, `tolerations`, `affinity`, `priorityClassName`, `podLabels`, `podAnnotations`, `imagePullSecrets` | | console pod settings |
| `test.image` | `ubi9/ubi-minimal` by digest | `helm test` image |
