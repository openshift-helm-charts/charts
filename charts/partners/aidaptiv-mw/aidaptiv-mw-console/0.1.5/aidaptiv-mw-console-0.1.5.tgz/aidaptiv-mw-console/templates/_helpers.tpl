{{- /* <release>-aidaptiv-mw-console unless the release name holds the chart name: a bare "console" would clash
       with OpenShift's own objects. */ -}}
{{- define "console.name" -}}
{{- if contains .Chart.Name .Release.Name }}{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}{{ printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}{{ end }}
{{- end }}

{{- /* Cluster-scoped objects: one per installation, so the namespace is part of the name. */ -}}
{{- define "console.clusterName" -}}
{{- printf "%s-%s" (include "console.name" .) .Release.Namespace | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "console.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "console.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "console.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "console.imageRef" -}}
{{- if .digest }}{{ .repository }}@{{ .digest }}{{ else }}{{ .repository }}:{{ .tag }}{{ end }}
{{- end }}

{{- define "console.image" -}}
{{- $i := .Values.image }}
{{- include "console.imageRef" (dict "repository" $i.repository "tag" ($i.tag | default .Chart.AppVersion) "digest" $i.digest) }}
{{- end }}

{{- /* Keep a generated secret value across upgrades: reuse the stored one, else a new random string. */ -}}
{{- define "console.keptSecretValue" -}}
{{- $s := lookup "v1" "Secret" .root.Release.Namespace .secret }}
{{- if and $s $s.data (hasKey $s.data .key) }}{{ index $s.data .key | b64dec }}{{ else }}{{ randAlphaNum .length }}{{ end }}
{{- end }}
