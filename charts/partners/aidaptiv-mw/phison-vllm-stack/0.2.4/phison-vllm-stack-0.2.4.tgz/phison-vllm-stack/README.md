# phison-vllm-stack

This chart serves one model on upstream [vLLM](https://github.com/vllm-project/vllm) through Red Hat
OpenShift AI. It creates one `LLMInferenceService` (`serving.kserve.io/v1alpha2`). OpenShift AI's KServe
then runs the vLLM pods and adds the rest of the serving path:

- the router and scheduler (llm-d endpoint picker),
- the HTTPRoute on the inference Gateway,
- token authentication (Red Hat Connectivity Link).

The chart only sets the model, the vLLM image, vLLM's arguments and the resources. The router, KV cache
and LoRA features come from OpenShift AI; this chart installs none of them.

With the default values, the chart deploys:

- `LLMInferenceService <release>`: `Qwen/Qwen3-0.6B` from Hugging Face on one NVIDIA GPU. The image is
  `quay.io/aidaptiv-mw/vllm:0.32.0-3`, upstream vLLM 0.32.0 on UBI 9 (`images/vllm-ubi9`).
- For `helm test` only: a ServiceAccount allowed to `get` that LLMInferenceService, and a pod on UBI 9
  minimal. The pod reads the service's URL from its status and sends one chat completion through the
  Gateway with the ServiceAccount's token.

## Cluster requirements

Supported on Red Hat OpenShift 4.12 to 4.22 (`kubeVersion`: Helm refuses newer clusters). Tested on 4.22.18
with OpenShift AI 3.5.2.

- **Red Hat OpenShift AI 3.x** with a `DataScienceCluster` where `kserve` is `Managed`.
- The two operators that OpenShift AI requires for LLMInferenceService:
  - cert-manager Operator for Red Hat OpenShift,
  - Red Hat Connectivity Link, with a `Kuadrant` instance in `kuadrant-system`.

  The DataScienceCluster condition `KserveLLMInferenceServiceDependencies` turns `True` when both are in place.
- The inference Gateway `openshift-ingress/openshift-ai-inference`, which the OpenShift AI documentation has you
  create. To use another Gateway, set `router.gatewayRefs`.
- The NVIDIA GPU Operator, with nodes that advertise `nvidia.com/gpu`.
- Egress to `huggingface.co` for `hf://` models. On a disconnected cluster, use `oci://` (a modelcar image)
  or `pvc://`.

## Install

```bash
helm repo add openshift-helm-charts https://charts.openshift.io/
helm install qwen3 openshift-helm-charts/phison-vllm-stack -n my-models --create-namespace
oc -n my-models get llminferenceservice qwen3 -w        # READY True once the model is loaded
helm test qwen3 -n my-models
```

When the controllers of OpenShift AI were started before Connectivity Link was installed, the service reports
`AuthPolicy CRD is not available`. Restart `llmisvc-controller-manager` and `odh-model-controller` in
`redhat-ods-applications` to clear it.

## Values

| Key | Default | Meaning |
|---|---|---|
| `image.repository` / `tag` / `digest` | `quay.io/aidaptiv-mw/vllm` / `0.32.0-3` / `""` | vLLM image; with `digest` the image is pulled by digest |
| `model.uri` | `hf://Qwen/Qwen3-0.6B` | `hf://`, `oci://` (modelcar), `s3://`, `pvc://` |
| `model.name` | `Qwen/Qwen3-0.6B` | served model name, the `model` field of requests |
| `replicas` | `1` | vLLM replicas |
| `vllmArgs` | `[--max-model-len=8192]` | extra `vllm serve` arguments (`VLLM_ADDITIONAL_ARGS`) |
| `env` | `[]` | extra environment variables of the vLLM container |
| `resources` | 1 GPU, 2–8 CPU, 8–24 Gi | vLLM container resources |
| `nodeSelector`, `tolerations` | empty | vLLM pod placement |
| `annotations` | `{}` | LLMInferenceService annotations; `security.opendatahub.io/enable-auth: "false"` turns off token checks |
| `router.gatewayRefs` | `[]` | Gateways for the route; empty = OpenShift AI's default |
| `test.image` | `ubi9/ubi-minimal` by digest | `helm test` image |
| `test.timeoutSeconds` | `1800` | how long the test waits for an answer, model download included |

## Calling the model

The URL is in the service's status:

```bash
URL=$(oc -n my-models get llminferenceservice qwen3 -o jsonpath='{.status.url}')
curl -H "Authorization: Bearer $(oc whoami -t)" -H 'Content-Type: application/json' "$URL/v1/chat/completions" \
  -d '{"model": "Qwen/Qwen3-0.6B", "messages": [{"role": "user", "content": "Hello"}]}'
```

The Gateway allows a token when its user or ServiceAccount can `get` the LLMInferenceService.
