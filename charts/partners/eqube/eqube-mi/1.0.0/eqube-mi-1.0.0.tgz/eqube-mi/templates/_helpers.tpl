{{/* ============================================================
  eqube-mi _helpers.tpl
  Red Hat Certified — namespaced helpers for all three phases.
  ============================================================ */}}

{{/* -------------------------------------------------------
  SHARED HELPERS
  ------------------------------------------------------- */}}

{{- define "eqube-mi.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "eqube-mi.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "eqube-mi.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Standard Red Hat / OpenShift recommended labels (common to all resources).
Includes required app.kubernetes.io/* labels for certification.
*/}}
{{- define "eqube-mi.labels" -}}
helm.sh/chart: {{ include "eqube-mi.chart" . }}
{{ include "eqube-mi.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "eqube-mi.name" . }}
{{- end }}

{{- define "eqube-mi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eqube-mi.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{/* -------------------------------------------------------
  PHASE 1 — USER CREATION HELPERS
  ------------------------------------------------------- */}}

{{- define "uc.fullname" -}}
{{- printf "%s-uc" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "uc.labels" -}}
helm.sh/chart: {{ include "eqube-mi.chart" . }}
app.kubernetes.io/name: {{ include "eqube-mi.name" . }}-user-creation
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: user-creation
app.kubernetes.io/part-of: {{ include "eqube-mi.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}


{{/* -------------------------------------------------------
  PHASE 2 — METADATA CREATION HELPERS
  ------------------------------------------------------- */}}

{{- define "mc.fullname" -}}
{{- printf "%s-mc" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "mc.labels" -}}
helm.sh/chart: {{ include "eqube-mi.chart" . }}
app.kubernetes.io/name: {{ include "eqube-mi.name" . }}-metadata-creation
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: metadata-creation
app.kubernetes.io/part-of: {{ include "eqube-mi.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{- define "mc.flatten-env-vars" -}}
{{- range $key, $val := .dict }}
  {{- if kindIs "map" $val }}
    {{- include "mc.flatten-env-vars" (dict "dict" $val) }}
  {{- else }}
    {{- $strVal := toString $val }}
    {{- if and (ne $val nil) (ne $strVal "null") (ne $strVal "") }}
- name: {{ $key }}
  value: {{ $strVal | quote }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "mc.list-env-variables" -}}
{{- include "mc.flatten-env-vars" (dict "dict" .Values.metadataCreation.environmentVariables) }}
{{- end }}

{{- define "mc.flattenMap" -}}
{{- $dict := .dict -}}
{{- $result := dict -}}
{{- range $key, $val := $dict }}
  {{- if kindIs "map" $val }}
    {{- $nested := include "mc.flattenMap" (dict "dict" $val) | fromYaml -}}
    {{- range $k, $v := $nested }}
      {{- $_ := set $result $k $v }}
    {{- end }}
  {{- else }}
    {{- if and (ne $val nil) (ne (toString $val) "") (ne (toString $val) "null") }}
      {{- $_ := set $result $key ($val | toString | b64enc) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toYaml $result | nindent 0 }}
{{- end }}

{{- define "mc.env._find" -}}
{{- $data := index . 0 -}}
{{- $key := index . 1 -}}
{{- $result := index . 2 -}}
{{- if kindIs "map" $data -}}
  {{- range $k, $v := $data -}}
    {{- if eq $k $key -}}
      {{- $_ := set $result "value" $v -}}
    {{- else if kindIs "map" $v -}}
      {{- include "mc.env._find" (list $v $key $result) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "mc.env.get" -}}
{{- $root := index . 0 -}}
{{- $key := index . 1 -}}
{{- $default := index . 2 | default "" -}}
{{- $result := dict "value" $default -}}
{{- if $root.Values.metadataCreation.environmentVariables -}}
  {{- include "mc.env._find" (list $root.Values.metadataCreation.environmentVariables $key $result) -}}
{{- end -}}
{{- get $result "value" -}}
{{- end -}}


{{/* -------------------------------------------------------
  PHASE 3 — EXECUTE WAR HELPERS
  ------------------------------------------------------- */}}

{{- define "ew.fullname" -}}
{{- printf "%s-ew" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ew.labels" -}}
helm.sh/chart: {{ include "eqube-mi.chart" . }}
app.kubernetes.io/name: {{ include "eqube-mi.name" . }}-execute-war
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: execute-war
app.kubernetes.io/part-of: {{ include "eqube-mi.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{- define "ew.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eqube-mi.name" . }}-execute-war
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "ew.flatten-env-vars" -}}
{{- range $key, $val := .dict }}
  {{- if kindIs "map" $val }}
    {{- include "ew.flatten-env-vars" (dict "dict" $val) }}
  {{- else }}
    {{- $strVal := toString $val }}
    {{- if and (ne $val nil) (ne $strVal "null") (ne $strVal "") }}
- name: {{ $key }}
  value: {{ $strVal | quote }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "ew.list-env-variables" -}}
{{- include "ew.flatten-env-vars" (dict "dict" .Values.executeWar.environmentVariables) }}
{{- end }}

{{- define "ew.flattenMap" -}}
{{- $dict := .dict -}}
{{- $result := dict -}}
{{- range $key, $val := $dict }}
  {{- if kindIs "map" $val }}
    {{- $nested := include "ew.flattenMap" (dict "dict" $val) | fromYaml -}}
    {{- range $k, $v := $nested }}
      {{- $_ := set $result $k $v }}
    {{- end }}
  {{- else }}
    {{- if and (ne $val nil) (ne (toString $val) "") (ne (toString $val) "null") }}
      {{- $_ := set $result $key ($val | toString | b64enc) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toYaml $result | nindent 0 }}
{{- end }}

{{- define "ew.env._find" -}}
{{- $data := index . 0 -}}
{{- $key := index . 1 -}}
{{- $result := index . 2 -}}
{{- if kindIs "map" $data -}}
  {{- range $k, $v := $data -}}
    {{- if eq $k $key -}}
      {{- $_ := set $result "value" $v -}}
    {{- else if kindIs "map" $v -}}
      {{- include "ew.env._find" (list $v $key $result) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "ew.env.get" -}}
{{- $root := index . 0 -}}
{{- $key := index . 1 -}}
{{- $default := index . 2 | default "" -}}
{{- $result := dict "value" $default -}}
{{- if $root.Values.executeWar.environmentVariables -}}
  {{- include "ew.env._find" (list $root.Values.executeWar.environmentVariables $key $result) -}}
{{- end -}}
{{- get $result "value" -}}
{{- end -}}

{{/*
Red Hat / OpenShift: container-level security context (non-root, drop ALL caps).
Applied to every container and initContainer.
*/}}
{{- define "eqube-mi.containerSecurityContext" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: false
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  capabilities:
    drop:
      - ALL
{{- end }}

{{/*
Red Hat / OpenShift: initContainer security context (kubectl wait containers).
*/}}
{{- define "eqube-mi.initContainerSecurityContext" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  capabilities:
    drop:
      - ALL
{{- end }}
