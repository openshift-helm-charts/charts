# eqube-mi Helm Chart

A single unified Helm chart that combines three eQube deployment phases into one release.

## Execution Sequence

| Phase | Name | Kind | Hook Weight |
|-------|------|------|-------------|
| 1 | Oracle User Creation | Job (pre-install/pre-upgrade hook) | `-20` |
| 2 | Metadata Creation | Job (pre-install/pre-upgrade hook) | `-10` |
| 3 | Execute WAR Component | StatefulSet / Deployment (normal install) | — |

Phases 1 and 2 run as Helm **pre-install / pre-upgrade hooks**, so Kubernetes guarantees they complete before Phase 3 is deployed. Hook weights ensure Phase 1 always finishes before Phase 2 starts.

## Enable / Disable Each Phase

Open `values.yaml` and toggle the `phases` flags:

```yaml
phases:
  userCreation:
    enabled: true    # Phase 1: Oracle user & schema creation

  metadataCreation:
    enabled: true    # Phase 2: eQube metadata creation

  executeWar:
    enabled: true    # Phase 3: Deploy the WAR application
```

Setting any flag to `false` completely skips that phase — no resources for it are rendered or applied.

## Quick Start

```bash
# Full install (all phases)
helm install my-release ./eqube-mi -n my-namespace

# Only run Phase 1 & 2 (skip WAR deploy)
helm install my-release ./eqube-mi \
  --set phases.executeWar.enabled=false \
  -n my-namespace

# Skip user creation (e.g. DB users already exist)
helm install my-release ./eqube-mi \
  --set phases.userCreation.enabled=false \
  -n my-namespace

# Only Phase 3 (DB already set up)
helm install my-release ./eqube-mi \
  --set phases.userCreation.enabled=false \
  --set phases.metadataCreation.enabled=false \
  -n my-namespace
```

## values.yaml Structure

All phase-specific values live under their phase key:

```
phases.*            → enable/disable flags
userCreation.*      → Phase 1 config (DB admin creds, Oracle params)
metadataCreation.*  → Phase 2 config (image, env vars, secrets, affinity)
executeWar.*        → Phase 3 config (StatefulSet/Deployment, ingress, HPA, etc.)
```

## Files

```
eqube-mi/
├── Chart.yaml
├── values.yaml
├── .helmignore
├── README.md
├── sql-scripts/
│   └── sql-script.sql            ← Oracle DDL (Phase 1)
├── config/
│   ├── server/
│   │   └── server.xml            ← Tomcat SSL config (Phase 3, SSL mode)
│   └── metadata/                 ← DB cert files (Phase 3, optional)
└── templates/
    ├── _helpers.tpl              ← All helper functions (namespaced per phase)
    │
    ├── uc-db-admin-creds.yaml    ← Phase 1: Secret
    ├── uc-sql-scripts-cm.yaml    ← Phase 1: ConfigMap (SQL)
    ├── uc-job.yaml               ← Phase 1: Job
    │
    ├── mc-secret.yaml            ← Phase 2: Secret
    ├── mc-certificate-config.yaml← Phase 2: ConfigMap (SSL)
    ├── mc-job.yaml               ← Phase 2: Job
    │
    ├── ew-dbsecret.yaml          ← Phase 3: Secret
    ├── ew-serverxml-config.yaml  ← Phase 3: ConfigMap (server.xml)
    ├── ew-certificate-config.yaml← Phase 3: ConfigMap (certs)
    ├── ew-statefulset.yaml       ← Phase 3: StatefulSet (default)
    ├── ew-deployment.yaml        ← Phase 3: Deployment (intelligent scaling)
    ├── ew-service.yaml           ← Phase 3: Service
    ├── ew-ingress.yaml           ← Phase 3: Ingress
    ├── ew-hpa.yaml               ← Phase 3: HPA
    ├── ew-servicemonitor.yaml    ← Phase 3: ServiceMonitor (Prometheus)
    └── ew-route.yaml             ← Phase 3: OpenShift Route
```
