{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "cmf.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cmf.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*
Common labels
*/}}
{{- define "cmf.labels" -}}
{{ include "cmf.selectorLabels" . }}
{{- include "cmf.versionLabels" . }}
{{- end }}

{{- define "cmf.versionLabels" -}}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "cmf.chart" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cmf.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cmf.name" . }}
{{- end }}

{{/*
Labels of the compile worker pod. They must differ from cmf.selectorLabels, or cmf-service would
also select the worker pod.
*/}}
{{- define "cmf.workerSelectorLabels" -}}
app.kubernetes.io/name: {{ printf "%s-compile-worker" (include "cmf.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "cmf.workerLabels" -}}
{{ include "cmf.workerSelectorLabels" . }}
{{- include "cmf.versionLabels" . }}
{{- end }}

{{/*
Name of the ServiceAccount the CMF pod runs as.

The RBAC bindings MUST resolve the name through this template too. Binding the Role to
the chart's own name while the pod runs as a customer-supplied ServiceAccount leaves CMF
with no Kubernetes permissions at all, and the pod starts happily before failing every
API call.
*/}}
{{- define "cmf.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- include "cmf.name" . -}}
{{- else -}}
{{- required "serviceAccount.name is required when serviceAccount.create is false: the CMF pod and its RBAC bindings both need the name of the ServiceAccount you created." .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/*
Checksum of another rendered template, used as a pod annotation so CMF restarts only when that
template's content changes. Labels are left out because they carry the chart version.

Usage:
  {{ include "cmf.checksum" (dict "context" $ "path" "/configmap.yaml") }}
*/}}
{{- define "cmf.checksum" -}}
{{- $rendered := include (print .context.Template.BasePath .path) .context | fromYaml -}}
{{- if $rendered.metadata -}}
{{- $_ := unset $rendered.metadata "labels" -}}
{{- end -}}
{{- $rendered | toYaml | sha256sum -}}
{{- end -}}

{{/*
Validate mountedVolumes: fail on duplicate volume names and duplicate mount paths.
Call this template from deployment.yaml to run the checks at render time.
*/}}
{{- define "cmf.validateMountedVolumes" -}}
{{- $reservedVolNames := list "cmf-config" "cmf-storage" }}
{{- $reservedMountPaths := list "/opt/config" "/app/local" }}
{{- $sharedCompilers := include "cmf.sharedCompilers" . | fromJsonArray }}
{{- if gt (int (include "cmf.workers" . | fromJson).count) 0 }}
  {{- $reservedVolNames = append $reservedVolNames "cmf-compile-tls" }}
  {{- $reservedMountPaths = append $reservedMountPaths "/etc/cmf/compile-tls" }}
{{- end }}
{{- if .Values.mountedVolumes.volumes }}
  {{- $volNames := list }}
  {{- range .Values.mountedVolumes.volumes }}
    {{- if or (has .name $reservedVolNames) (and $sharedCompilers (regexMatch "^compiler-[0-9]+-(tmp|no-token)$" .name)) }}
      {{- fail (printf "Volume name '%s' is reserved by the CMF chart and cannot be used in mountedVolumes.volumes." .name) }}
    {{- end }}
    {{- if has .name $volNames }}
      {{- fail (printf "Duplicate volume name '%s' in mountedVolumes.volumes. Each volume name must be unique." .name) }}
    {{- end }}
    {{- $volNames = append $volNames .name }}
  {{- end }}
{{- end }}
{{- if .Values.mountedVolumes.volumeMounts }}
  {{- $mountPaths := list }}
  {{- range .Values.mountedVolumes.volumeMounts }}
    {{- if has .mountPath $reservedMountPaths }}
      {{- fail (printf "Mount path '%s' is reserved by the CMF chart and cannot be used in mountedVolumes.volumeMounts." .mountPath) }}
    {{- end }}
    {{- if has .mountPath $mountPaths }}
      {{- fail (printf "Duplicate mount path '%s' in mountedVolumes.volumeMounts. Each mountPath must be unique to avoid one mount shadowing another." .mountPath) }}
    {{- end }}
    {{- $mountPaths = append $mountPaths .mountPath }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "cmf.internalPort" -}}
{{- $cmf := .Values.cmf | default dict }}
{{- if and (hasKey $cmf "internalPort") (hasKey $cmf "internal-port") }}
  {{- fail "Set either cmf.internalPort or cmf.internal-port, not both." }}
{{- end }}
{{- dig "internalPort" (dig "internal-port" 8081 $cmf) $cmf -}}
{{- end -}}

{{/*
The CMF minor version of this chart, from appVersion: 2.5-SNAPSHOT and 2.5.1 give 2.5.
*/}}
{{- define "cmf.compilerCmfMinor" -}}
{{- $release := regexReplaceAll "-.*$" (toString .Chart.AppVersion) "" }}
{{- if not (regexMatch "^[0-9]+\\.[0-9]+(\\.[0-9]+)?$" $release) }}
  {{- fail (printf "Cannot read the CMF version from the chart's appVersion '%s', which cmf.statementService.sharedCompilers and workers need: expected <major>.<minor>[.<patch>], optionally followed by -<suffix>." (toString .Chart.AppVersion)) }}
{{- end }}
{{- regexFind "^[0-9]+\\.[0-9]+" $release -}}
{{- end -}}

{{/*
cmf.statementService.sharedCompilers, spelled in camelCase or kebab-case like the other cmf keys,
with each entry's keys in camelCase and its version, a Flink line, turned into the CP Flink SQL
version of this CMF's minor version: 1.19 gives 1.19-cmf2.5. A key set to null is left out, as
if unset. Unset in both spellings, a 1.19 compiler on port 8095 and a 2.3 compiler on port 8096;
it is not in values.yaml itself, as a default under statementService would clash with values that
spell it statement-service. Returns JSON; read it with fromJsonArray.
*/}}
{{- define "cmf.sharedCompilers" -}}
{{- $cmf := .Values.cmf | default dict }}
{{- if and (hasKey $cmf "statementService") (hasKey $cmf "statement-service") }}
  {{- fail "Set either cmf.statementService or cmf.statement-service, not both." }}
{{- end }}
{{- $block := get $cmf "statementService" | default (get $cmf "statement-service") | default dict }}
{{- if and (hasKey $block "sharedCompilers") (hasKey $block "shared-compilers") }}
  {{- fail "Set either sharedCompilers or shared-compilers in cmf.statementService, not both." }}
{{- end }}
{{- $camelCase := dict "max-concurrent-compiles" "maxConcurrentCompiles" "jvm-args" "jvmArgs" "extra-env" "extraEnv" "volume-mounts" "volumeMounts" }}
{{- $configured := list }}
{{- if hasKey $block "sharedCompilers" }}
  {{- $configured = get $block "sharedCompilers" | default list }}
{{- else if hasKey $block "shared-compilers" }}
  {{- $configured = get $block "shared-compilers" | default list }}
{{- else }}
  {{- $configured = list (dict "version" "1.19" "port" 8095) (dict "version" "2.3" "port" 8096) }}
{{- end }}
{{- $compilers := list }}
{{- range $configured }}
  {{- $entry := dict }}
  {{- range $key, $value := . }}
    {{- $name := get $camelCase $key | default $key }}
    {{- if hasKey $entry $name }}
      {{- fail (printf "A shared compiler in cmf.statementService.sharedCompilers sets %s in both camelCase and kebab-case. Set it once." $name) }}
    {{- end }}
    {{- if not (kindIs "invalid" $value) }}
      {{- $_ := set $entry $name $value }}
    {{- end }}
  {{- end }}
  {{- $line := toString (get $entry "version") }}
  {{- if not (regexMatch "^[0-9]+\\.[0-9]+$" $line) }}
    {{- fail (printf "Shared compiler version '%s' in cmf.statementService.sharedCompilers is not a Flink line. Give only the Flink line, for example \"1.19\" or \"2.3\": the chart adds the CMF version itself." $line) }}
  {{- end }}
  {{- $_ := set $entry "version" (printf "%s-cmf%s" $line (include "cmf.compilerCmfMinor" $)) }}
  {{- $compilers = append $compilers $entry }}
{{- end }}
{{- toJson $compilers }}
{{- end -}}

{{/*
The resources of a shared compiler whose entry sets none. A quota on CPU refuses a pod in which one
container sets no CPU, so compilers take the CPU request and limit of the cmf container. Returns
JSON.
*/}}
{{- define "cmf.compilerDefaultResources" -}}
{{- $resources := dict "requests" (dict "memory" "2Gi") "limits" (dict "memory" "2Gi") }}
{{- include "cmf.withCmfCpu" (dict "resources" $resources "context" .) }}
{{- end -}}

{{/*
.resources with the CPU request and limit of the cmf container, where it sets them. Returns JSON.
*/}}
{{- define "cmf.withCmfCpu" -}}
{{- $cmfResources := .context.Values.resources | default dict }}
{{- $resources := deepCopy .resources }}
{{- with dig "requests" "cpu" "" $cmfResources }}
  {{- $_ := set $resources.requests "cpu" . }}
{{- end }}
{{- with dig "limits" "cpu" "" $cmfResources }}
  {{- $_ := set $resources.limits "cpu" . }}
{{- end }}
{{- toJson $resources }}
{{- end -}}

{{/*
The JVM options for agents, debugging and JMX, which can open ports that all containers of the pod
share, as alternatives of a regular expression.
*/}}
{{- define "cmf.portJvmOptions" -}}
javaagent:|agentlib:|agentpath:|Xrun|Xdebug|Dcom\.sun\.management\.
{{- end -}}

{{/*
The environment variables that the JVM reads options from. Returns JSON; read it with fromJsonArray.
*/}}
{{- define "cmf.jvmOptionVariables" -}}
{{- toJson (list "JAVA_TOOL_OPTIONS" "JDK_JAVA_OPTIONS" "_JAVA_OPTIONS" "OPENJ9_JAVA_OPTIONS" "IBM_JAVA_OPTIONS") }}
{{- end -}}

{{/*
The top-level jvmArgs as CMF gets them. Charts before CMF 2.5 wrote jvmArgs into a YAML
double-quoted string, which reads its escapes, so they are read here too; a value with an unescaped
", which did not render then, is taken as written.
*/}}
{{- define "cmf.jvmArgs" -}}
{{- $value := toString (.Values.jvmArgs | default "") }}
{{- $read := dict }}
{{- if not (regexMatch `(^|[^\\])(\\\\)*"` $value) }}
  {{- $read = printf "v: \"%s\"" $value | fromYaml }}
{{- end }}
{{- ternary $read.v $value (hasKey $read "v") -}}
{{- end -}}

{{/*
The JVM options of string .value split into those for CMF only, "cmf", and the others, "kept": the
heap, as an -Xms above a compiler's -Xmx stops it, cmf.portJvmOptions, and turning off
-XX:+ExitOnOutOfMemoryError, which a compiler needs to be restarted. With .quotes, .value is split
as the JVM splits its option variables, and only where HotSpot and OpenJ9 split it alike, as the
image runs either JVM; otherwise "unchecked" is set, as it is when the JVM reads options from a file
or Kubernetes replaces a $(...) after the chart split .value. Returns JSON; read it with fromJson.
*/}}
{{- define "cmf.splitJvmOptions" -}}
{{- $value := toString (.value | default "") }}
{{- $cmfOnly := printf `^-(Xm[sx][0-9]|Xm[no][sx]?[0-9]|Xsoftmx[0-9]|XX:((Initial|Max|Min|SoftMax)HeapSize|(Initial|Max|Min)RAM(Percentage|Fraction)|MaxRAM|(Max)?NewSize)=|XX:-ExitOnOutOfMemoryError$|%s)` (include "cmf.portJvmOptions" .) }}
{{- $option := `[^ "'\t\n\r\v\f]*("[^"'\t\n\r\v\f]*")?[^ "'\t\n\r\v\f]*` }}
{{- $options := dict "kept" list "cmf" list "unchecked" false }}
{{- if and .quotes (or (not (regexMatch (printf `^ *(%[1]s( +%[1]s)*)? *$` $option) $value)) (contains `\"` $value) (contains `""` $value)) }}
  {{- $_ := set $options "kept" (list $value) }}
  {{- $_ := set $options "unchecked" true }}
{{- else }}
  {{- range regexFindAll (ternary `([^ "]|"[^"]*")+` `[^ \t\n]+` (eq .quotes true)) $value -1 }}
    {{- $key := ternary "cmf" "kept" (regexMatch $cmfOnly (ternary (replace `"` "" .) . (eq $.quotes true))) }}
    {{- $_ := set $options $key (append (get $options $key) .) }}
  {{- end }}
{{- end }}
{{- if or (contains "$(" $value) (regexMatch `(^|[ \t\n"])(-XX:(VMOptionsFile|Flags)=|-Xoptionsfile=|@)` $value) }}
  {{- $_ := set $options "unchecked" true }}
{{- end }}
{{- toJson $options }}
{{- end -}}

{{- define "cmf.withoutCmfJvmOptions" -}}
{{- (include "cmf.splitJvmOptions" . | fromJson).kept | join " " -}}
{{- end -}}

{{/*
The extraEnv a shared compiler gets when its entry sets none: the top-level extraEnv, with the
options for CMF only left out of the JVM option variables, and without those that are then empty.
A variable from valueFrom is kept as it is, also next to an empty value. Returns JSON; read it with
fromJsonArray.
*/}}
{{- define "cmf.compilerInheritedEnv" -}}
{{- $jvmOptionVariables := include "cmf.jvmOptionVariables" . | fromJsonArray }}
{{- $env := list }}
{{- range (.Values.extraEnv | default list) }}
  {{- if and (has .name $jvmOptionVariables) (hasKey . "value") (not .valueFrom) }}
    {{- $value := include "cmf.withoutCmfJvmOptions" (dict "value" .value "quotes" true) }}
    {{- if $value }}
      {{- $env = append $env (set (deepCopy .) "value" $value) }}
    {{- end }}
  {{- else }}
    {{- $env = append $env . }}
  {{- end }}
{{- end }}
{{- toJson $env }}
{{- end -}}

{{/*
Only the cmf.portJvmOptions that shared compilers leave out of the jvmArgs and extraEnv they
inherit, without quotes and values: cut at the first = and, for -X options such as -Xrunjdwp:, at
the first :. Returns JSON; read it with fromJsonArray.
*/}}
{{- define "cmf.compilerLeftOutPortOptions" -}}
{{- $jvmOptionVariables := include "cmf.jvmOptionVariables" . | fromJsonArray }}
{{- $sources := list }}
{{- range (include "cmf.sharedCompilers" . | fromJsonArray) }}
  {{- if not (hasKey . "jvmArgs") }}
    {{- $sources = append $sources (dict "value" (include "cmf.jvmArgs" $)) }}
  {{- end }}
  {{- if not (hasKey . "extraEnv") }}
    {{- range ($.Values.extraEnv | default list) }}
      {{- if and (has .name $jvmOptionVariables) (hasKey . "value") }}
        {{- $sources = append $sources (dict "value" .value "quotes" true) }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- $options := list }}
{{- range $sources }}
  {{- range (include "cmf.splitJvmOptions" . | fromJson).cmf }}
    {{- $option := . | replace "\"" "" | replace "'" "" }}
    {{- if regexMatch (printf "^-(%s)" (include "cmf.portJvmOptions" $)) $option }}
      {{- $options = append $options (regexReplaceAll "^(-X[^X:=][^:=]*|[^=]*).*" $option "${1}") }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toJson (uniq $options) }}
{{- end -}}

{{/*
The top-level jvmArgs and JVM option variables of extraEnv that shared compilers inherit
unchecked: set with valueFrom, or with a value that cmf.splitJvmOptions marks "unchecked". Returns
JSON; read it with fromJsonArray.
*/}}
{{- define "cmf.compilerUncheckedJvmOptions" -}}
{{- $jvmOptionVariables := include "cmf.jvmOptionVariables" . | fromJsonArray }}
{{- $names := list }}
{{- range (include "cmf.sharedCompilers" . | fromJsonArray) }}
  {{- if and (not (hasKey . "jvmArgs")) (include "cmf.splitJvmOptions" (dict "value" (include "cmf.jvmArgs" $)) | fromJson).unchecked }}
    {{- $names = append $names "jvmArgs" }}
  {{- end }}
  {{- if not (hasKey . "extraEnv") }}
    {{- range ($.Values.extraEnv | default list) }}
      {{- if and (has .name $jvmOptionVariables) (or (hasKey . "valueFrom") (include "cmf.splitJvmOptions" (dict "value" .value "quotes" true) | fromJson).unchecked) }}
        {{- $names = append $names .name }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toJson (uniq $names) }}
{{- end -}}

{{/*
The keys of map .map in camelCase, without those set to null, as if unset; .path names the map in
the error for a key set in both spellings. Returns JSON.
*/}}
{{- define "cmf.camelCaseKeys" -}}
{{- $camelCase := dict "jvm-args" "jvmArgs" "compiler-jvm-args" "compilerJvmArgs" "tmp-size-limit" "tmpSizeLimit" "volume-size-limit" "volumeSizeLimit" "existing-secret-prefix" "existingSecretPrefix" "compile-timeout" "compileTimeout" "extra-env" "extraEnv" "mounted-volumes" "mountedVolumes" "require-ptrace-protection" "requirePtraceProtection" }}
{{- $out := dict }}
{{- range $key, $value := .map }}
  {{- $name := get $camelCase $key | default $key }}
  {{- if hasKey $out $name }}
    {{- fail (printf "%s sets %s in both camelCase and kebab-case. Set it once." $.path $name) }}
  {{- end }}
  {{- if not (kindIs "invalid" $value) }}
    {{- $_ := set $out $name $value }}
  {{- end }}
{{- end }}
{{- toJson $out }}
{{- end -}}

{{/*
cmf.statementService.workers in camelCase with its defaults; compilers default to the version of
each shared compiler, and a version the values give, a Flink line, is turned into the CP Flink SQL
version of this CMF's minor version as for shared compilers. Returns JSON; read it with fromJson.
*/}}
{{- define "cmf.workers" -}}
{{- $sharedCompilers := include "cmf.sharedCompilers" . | fromJsonArray }}
{{- $cmf := .Values.cmf | default dict }}
{{- $block := get $cmf "statementService" | default (get $cmf "statement-service") | default dict }}
{{- $path := "cmf.statementService.workers" }}
{{- $workers := include "cmf.camelCaseKeys" (dict "map" (get $block "workers" | default dict) "path" $path) | fromJson }}
{{- $tls := include "cmf.camelCaseKeys" (dict "map" (get $workers "tls" | default dict) "path" (printf "%s.tls" $path)) | fromJson }}
{{- $compilers := list }}
{{- range $i, $compiler := (get $workers "compilers" | default list) }}
  {{- $entry := include "cmf.camelCaseKeys" (dict "map" $compiler "path" (printf "%s.compilers[%d]" $path $i)) | fromJson }}
  {{- $line := toString (get $entry "version") }}
  {{- if not (regexMatch "^[0-9]+\\.[0-9]+$" $line) }}
    {{- fail (printf "Compile worker version '%s' in cmf.statementService.workers.compilers is not a Flink line. Give only the Flink line, for example \"1.19\" or \"2.3\": the chart adds the CMF version itself." $line) }}
  {{- end }}
  {{- $_ := set $entry "version" (printf "%s-cmf%s" $line (include "cmf.compilerCmfMinor" $)) }}
  {{- $compilers = append $compilers $entry }}
{{- end }}
{{- if not $compilers }}
  {{- range $sharedCompilers }}
    {{- $compilers = append $compilers (pick . "version") }}
  {{- end }}
{{- end }}
{{- /* Statements that use artifacts compile only on workers, so with both features on and
compilers to serve, one worker unless count is set. */}}
{{- if not (hasKey $workers "count") }}
  {{- $environmentCatalog := or (dig "sql" "environmentCatalog" "enabled" false $cmf) (dig "sql" "environment-catalog" "enabled" false $cmf) }}
  {{- $_ := set $workers "count" (ternary 1 0 (and (dig "artifacts" "enabled" false $cmf) $environmentCatalog (gt (len $compilers) 0))) }}
{{- end }}
{{- /* Fixed, not a value: worker i listens on port 8090 + i. */}}
{{- $_ := set $workers "basePort" 8090 }}
{{- $_ = set $workers "tmpSizeLimit" (get $workers "tmpSizeLimit" | default "256Mi") }}
{{- $_ = set $workers "volumeSizeLimit" (get $workers "volumeSizeLimit" | default "512Mi") }}
{{- $_ = set $workers "requirePtraceProtection" (get $workers "requirePtraceProtection" | default false) }}
{{- /* A quota on CPU refuses a pod in which a container sets no CPU, so workers take the CPU of the
cmf container when it sets CPU. */}}
{{- if not (hasKey $workers "resources") }}
  {{- $resources := include "cmf.withCmfCpu" (dict "resources" (dict "requests" (dict "memory" "3Gi") "limits" (dict "memory" "3Gi")) "context" $) | fromJson }}
  {{- if not (or (hasKey $resources.requests "cpu") (hasKey $resources.limits "cpu")) }}
    {{- $_ = set $resources.requests "cpu" "500m" }}
  {{- end }}
  {{- $_ = set $workers "resources" $resources }}
{{- end }}
{{- /* Fixed heaps, so that the default memory limit holds both, the JVMs' other memory and the
in-memory volumes. */}}
{{- if not (hasKey $workers "jvmArgs") }}
  {{- $_ = set $workers "jvmArgs" "-Xmx384m" }}
{{- end }}
{{- if not (hasKey $workers "compilerJvmArgs") }}
  {{- $_ = set $workers "compilerJvmArgs" "-Xmx1g" }}
{{- end }}
{{- $_ = set $workers "compilers" $compilers }}
{{- $_ = set $workers "tls" (dict "existingSecretPrefix" (get $tls "existingSecretPrefix" | default "")) }}
{{- toJson $workers }}
{{- end -}}

{{/*
Name of the Secret with the TLS files of .identity: "cmf", or "worker" for the Secret that holds
the key pairs of all workers.
*/}}
{{- define "cmf.workerTlsSecret" -}}
{{- $prefix := (include "cmf.workers" .context | fromJson).tls.existingSecretPrefix }}
{{- printf "%s-%s" ($prefix | default "cmf-compile-tls") .identity -}}
{{- end -}}

{{- define "cmf.validateWorkers" -}}
{{- $workers := include "cmf.workers" . | fromJson }}
{{- $count := int $workers.count }}
{{- if gt $count 0 }}
  {{- if not $workers.compilers }}
    {{- fail (printf "cmf.statementService.workers.count is %d, but the workers have no compilers. Set cmf.statementService.workers.compilers, or cmf.statementService.sharedCompilers for the workers to serve the same versions." $count) }}
  {{- end }}
  {{- $versions := list }}
  {{- range $workers.compilers }}
    {{- if has .version $versions }}
      {{- fail (printf "Duplicate version '%s' in cmf.statementService.workers.compilers. Each compiler version must be unique." .version) }}
    {{- end }}
    {{- $versions = append $versions .version }}
  {{- end }}
  {{- $tlsSecrets := "^cmf-compile-(ca|tls-.*)$" }}
  {{- with $workers.tls.existingSecretPrefix }}
    {{- $tlsSecrets = printf "^(cmf-compile-(ca|tls-.*)|%s-(cmf|worker))$" (regexQuoteMeta .) }}
  {{- end }}
  {{- range ($workers.extraEnv | default list) }}
    {{- with dig "valueFrom" "secretKeyRef" "name" "" . }}
      {{- if regexMatch $tlsSecrets (toString .) }}
        {{- fail (printf "cmf.statementService.workers.extraEnv takes a value from the Secret '%s', which holds a private key of the compile TLS certificates, so code that statements run on the workers could read it. Remove the variable." .) }}
      {{- end }}
    {{- end }}
    {{- if hasPrefix "SP_" (toString .name) }}
      {{- fail (printf "cmf.statementService.workers.extraEnv sets %s, but the chart sets the SP_* variables of the workers itself. Remove it; set JVM arguments with cmf.statementService.workers.jvmArgs and cmf.statementService.workers.compilerJvmArgs." .name) }}
    {{- end }}
    {{- /* These reach the worker's own JVM too: _JAVA_OPTIONS comes after its command line and could
    turn the attach mechanism back on, and an agent's port would be shared by all workers of the pod. */}}
    {{- if has (toString .name) (include "cmf.jvmOptionVariables" $ | fromJsonArray) }}
      {{- fail (printf "cmf.statementService.workers.extraEnv sets %s, which would apply to every JVM of the workers. Remove it; set JVM arguments with cmf.statementService.workers.jvmArgs and cmf.statementService.workers.compilerJvmArgs." .name) }}
    {{- end }}
    {{- if eq (toString .name) "LD_PRELOAD" }}
      {{- fail "cmf.statementService.workers.extraEnv sets LD_PRELOAD, which would load a library into every process of the workers, their supervisors too. Remove it." }}
    {{- end }}
  {{- end }}
  {{- $mounted := $workers.mountedVolumes | default dict }}
  {{- $volNames := list }}
  {{- range (dig "volumes" list $mounted) }}
    {{- if regexMatch "^worker-([0-9]+-(tmp|shm|artifacts|tls)|passwd)$" (toString .name) }}
      {{- fail (printf "Volume name '%s' is reserved by the CMF chart and cannot be used in cmf.statementService.workers.mountedVolumes.volumes." .name) }}
    {{- end }}
    {{- $volName := .name }}
    {{- $secretNames := list (dig "secret" "secretName" "" .) }}
    {{- range (dig "projected" "sources" list .) }}
      {{- $secretNames = append $secretNames (dig "secret" "name" "" .) }}
      {{- if hasKey . "serviceAccountToken" }}
        {{- fail (printf "Volume '%s' in cmf.statementService.workers.mountedVolumes.volumes has a serviceAccountToken source, which would give code that statements run on the workers a Kubernetes API token. Remove the source." $volName) }}
      {{- end }}
    {{- end }}
    {{- range $secretNames }}
      {{- if regexMatch $tlsSecrets (toString .) }}
        {{- fail (printf "Volume '%s' in cmf.statementService.workers.mountedVolumes.volumes uses the Secret '%s', which holds a private key of the compile TLS certificates, so code that statements run on the workers could read it. Remove the volume." $volName .) }}
      {{- end }}
    {{- end }}
    {{- if has .name $volNames }}
      {{- fail (printf "Duplicate volume name '%s' in cmf.statementService.workers.mountedVolumes.volumes. Each volume name must be unique." .name) }}
    {{- end }}
    {{- $volNames = append $volNames .name }}
  {{- end }}
  {{- $mountPaths := list }}
  {{- range (dig "volumeMounts" list $mounted) }}
    {{- if regexMatch "^worker-([0-9]+-(tmp|shm|artifacts|tls)|passwd)$" (toString .name) }}
      {{- fail (printf "Volume name '%s' is reserved by the CMF chart and cannot be used in cmf.statementService.workers.mountedVolumes.volumeMounts." .name) }}
    {{- end }}
    {{- if not (eq (.readOnly | toString) "true") }}
      {{- fail (printf "Volume mount '%s' in cmf.statementService.workers.mountedVolumes.volumeMounts must set readOnly: true. Statements of different environments compile on the same workers, so a writable mount would let the code of one environment change files that the statements of another read." .name) }}
    {{- end }}
    {{- $mountPath := toString .mountPath }}
    {{- $path := clean $mountPath }}
    {{- if not (isAbs $path) }}
      {{- fail (printf "Mount path '%s' in cmf.statementService.workers.mountedVolumes.volumeMounts must be an absolute path." .mountPath) }}
    {{- end }}
    {{- $pathDir := ternary $path (printf "%s/" $path) (eq $path "/") }}
    {{- range $reserved := list "/tmp" "/dev/shm" "/var/cache/artifacts" "/etc/cmf/compile-tls" "/etc/passwd" }}
      {{- if or (eq $path $reserved) (hasPrefix (printf "%s/" $reserved) $path) (hasPrefix $pathDir $reserved) }}
        {{- fail (printf "Mount path '%s' is at, under or above %s, which the CMF chart mounts itself, so it cannot be used in cmf.statementService.workers.mountedVolumes.volumeMounts." $mountPath $reserved) }}
      {{- end }}
    {{- end }}
    {{- if has $path $mountPaths }}
      {{- fail (printf "Duplicate mount path '%s' in cmf.statementService.workers.mountedVolumes.volumeMounts. Each mountPath must be unique to avoid one mount shadowing another." .mountPath) }}
    {{- end }}
    {{- $mountPaths = append $mountPaths $path }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
The directory CMF reads multi-cluster kubeconfigs from, cmf.k8s.kubeconfigDirectory.
*/}}
{{- define "cmf.kubeconfigDirectory" -}}
{{- $k8s := dig "k8s" dict (.Values.cmf | default dict) }}
{{- dig "kubeconfigDirectory" (dig "kubeconfig-directory" "/etc/cmf/kubeconfig" $k8s) $k8s | trimSuffix "/" -}}
{{- end -}}

{{/*
Arguments of every compiler and compile worker container: the class allowlist and examples catalog
CMF applies to in-process compiles. The kebab-case allowlist key wins, as the ConfigMap then leaves
out the chart's default classAllowlist.
*/}}
{{- define "cmf.compilerArgs" -}}
{{- $sql := dig "sql" dict .Values.cmf }}
{{- $allowlist := ternary (get $sql "class-allowlist") (dig "classAllowlist" list $sql) (hasKey $sql "class-allowlist") | default list }}
{{- $examples := or (dig "examplesCatalog" "enabled" false $sql) (dig "examples-catalog" "enabled" false $sql) }}
{{- range $allowlist }}
- {{ printf "--class-allowlist=%s" . | quote }}
{{- end }}
{{- if $examples }}
- "--examples-catalog"
{{- end }}
{{- end -}}

{{/*
JVM option of every compiler JVM: CMF's Kafka OAuth token endpoint allowlist. CMF sets this
property in its own JVM only.
*/}}
{{- define "cmf.compilerKafkaJvmOption" -}}
{{- $kafka := dig "kafka" dict .Values.cmf }}
{{- with or (dig "oauthbearerAllowedUrls" "" $kafka) (dig "oauthbearer-allowed-urls" "" $kafka) | toString | nospace -}}
-Dorg.apache.kafka.sasl.oauthbearer.allowed.urls={{ . }}
{{- end }}
{{- end -}}

{{/*
Fail on the control characters U+007F to U+009F, and U+FFFE and U+FFFF, in any value, naming its
top-level key. Helm's toYaml cannot write them and renders nothing instead of failing, and it writes
U+0085 as a space, after the chart has split the JVM options at spaces.
*/}}
{{- define "cmf.validateControlCharacters" -}}
{{- range $key, $value := .Values }}
  {{- if regexMatch `[\x{7f}-\x{9f}\x{fffe}\x{ffff}]` (toJson $value) }}
    {{- fail (printf "CMF chart: a value under '%s' holds a control character from U+007F to U+009F, or U+FFFE or U+FFFF, which the chart cannot render. Remove it." $key) }}
  {{- end }}
{{- end }}
{{- end -}}

{{/*
Validate cmf.statementService.sharedCompilers. Each compiler is a container in the CMF pod,
so versions (container names) and ports must be unique and must not take a port CMF uses,
and CMF's internal port, added with the first compiler or worker, must not either. A compiler's
own /tmp mount, its empty ServiceAccount token directory and its SP_* variables must not be set
twice.
*/}}
{{- define "cmf.validateSharedCompilers" -}}
{{- $cmf := .Values.cmf }}
{{- $compilers := include "cmf.sharedCompilers" . | fromJsonArray }}
{{- $internalPort := include "cmf.internalPort" . }}
{{- $usedPorts := dict "8080" "the API port" }}
{{- if dig "metrics" "enabled" false $cmf }}
  {{- $_ := set $usedPorts (toString (dig "metrics" "port" 9404 $cmf)) "cmf.metrics.port" }}
{{- end }}
{{- if dig "mds" "enabled" false $cmf }}
  {{- $_ := set $usedPorts (toString (dig "mds" "port" 8090 $cmf)) "cmf.mds.port" }}
{{- end }}
{{- if or $compilers (gt (int (include "cmf.workers" . | fromJson).count) 0) }}
  {{- if hasKey $usedPorts $internalPort }}
    {{- fail (printf "cmf.internalPort %s is already used by %s. Each port in the CMF pod must be unique." $internalPort (get $usedPorts $internalPort)) }}
  {{- end }}
  {{- $_ := set $usedPorts $internalPort "cmf.internalPort" }}
{{- end }}
{{- $versions := list }}
{{- range $compiler := $compilers }}
  {{- if has .version $versions }}
    {{- fail (printf "Duplicate version '%s' in cmf.statementService.sharedCompilers. Each compiler version must be unique." .version) }}
  {{- end }}
  {{- $versions = append $versions .version }}
  {{- $port := toString .port }}
  {{- if hasKey $usedPorts $port }}
    {{- fail (printf "Port %s of shared compiler '%s' is already used by %s. Each port in the CMF pod must be unique." $port .version (get $usedPorts $port)) }}
  {{- end }}
  {{- $_ := set $usedPorts $port (printf "shared compiler '%s'" .version) }}
  {{- range .volumeMounts }}
    {{- if eq .mountPath "/tmp" }}
      {{- fail (printf "Shared compiler '%s' mounts /tmp in its volumeMounts. Each compiler has its own /tmp, so remove that mount." $compiler.version) }}
    {{- end }}
    {{- $tokenDirectory := "/var/run/secrets/kubernetes.io/serviceaccount" }}
    {{- if or (eq (trimSuffix "/" .mountPath) $tokenDirectory) (hasPrefix (printf "%s/" $tokenDirectory) .mountPath) }}
      {{- fail (printf "Shared compiler '%s' mounts %s in its volumeMounts. Compilers get no ServiceAccount token, so remove that mount." $compiler.version .mountPath) }}
    {{- end }}
  {{- end }}
  {{- $fix := ternary "Remove it from the compiler's extraEnv." "Remove it from the top-level extraEnv, which the compiler inherits, or set extraEnv on the compiler." (hasKey . "extraEnv") }}
  {{- range (ternary .extraEnv $.Values.extraEnv (hasKey . "extraEnv")) }}
    {{- if has .name (list "SP_PORT" "SP_COMPILER_VERSION" "SP_JVM_OPTS" "SP_MAX_CONCURRENT_COMPILES") }}
      {{- fail (printf "Shared compiler '%s' gets the environment variable %s, which the chart sets itself. %s" $compiler.version .name $fix) }}
    {{- end }}
    {{- if eq (toString .name) "SP_WORKER_INDEX" }}
      {{- fail (printf "Shared compiler '%s' gets the environment variable SP_WORKER_INDEX, which would start it as a compile worker. %s" $compiler.version $fix) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Deep-merge a user-supplied override map onto a rendered manifest.

Helm has no strategic-merge patch, so mergeOverwrite replaces lists wholesale. For a
Deployment that would drop the chart's own container, so containers and initContainers
are merged entry-by-entry on `name` (the Kubernetes strategic-merge key) and removed
from the overlay before the object-wide merge. Entries whose name is not in the base
are appended. Every other list is replaced, not merged.

An empty (or null) containers/initContainers override is refused: merging by name can
only add to or patch the chart's entries, never clear them, so the only thing such a
list could mean is a pod with no containers.

Usage:
  {{ include "cmf.applyOverrides" (dict "base" (include "cmf.service.base" .) "overrides" .Values.serviceOverrides) }}
A Deployment other than CMF's passes "key", the name of its overrides value, for the messages.
*/}}
{{- define "cmf.applyOverrides" -}}
{{- $base := fromYaml .base -}}
{{- if $base.Error }}
  {{- fail (printf "CMF chart: rendered manifest is not valid YAML: %s" $base.Error) }}
{{- end }}
{{- $overrides := deepCopy (.overrides | default dict) -}}
{{- $isDeployment := eq ($base.kind | default "") "Deployment" -}}
{{- $overridesKey := .key | default "deploymentOverrides" -}}
{{- /* The chart references each manifest by name AND namespace across manifests -- the
       Deployment's volume claimName and serviceAccountName resolve within the pod's own
       namespace, and the RBAC binding subjects name one explicitly. Moving or renaming a
       single manifest produces a release that installs and then does not work, so refuse
       instead and point at the thing that changes every manifest at once. */ -}}
{{- $overMeta := dig "metadata" dict $overrides }}
{{- if kindIs "map" $overMeta }}
  {{- if hasKey $overMeta "name" }}
    {{- fail (printf "CMF chart: metadata.name cannot be overridden (%s). Other manifests reference this name and would still point at the old one. Use nameOverride to rename every manifest at once." ($base.kind | default "manifest")) }}
  {{- end }}
  {{- if hasKey $overMeta "namespace" }}
    {{- fail (printf "CMF chart: metadata.namespace cannot be overridden (%s). The other manifests would stay in the release namespace and reference a %s that is not there. Use 'helm install --namespace' to place the whole release." ($base.kind | default "manifest") ($base.kind | default "manifest")) }}
  {{- end }}
{{- end }}
{{- if $isDeployment }}
  {{- $basePod := $base.spec.template.spec }}
  {{- $overPod := dig "spec" "template" "spec" dict $overrides }}
  {{- if and (eq $overridesKey "deploymentOverrides") (hasKey $overPod "serviceAccountName") }}
    {{- fail "CMF chart: set serviceAccount.name instead of deploymentOverrides.spec.template.spec.serviceAccountName. The chart binds its Role/ClusterRole to serviceAccount.name, so overriding only the pod would leave CMF running as a ServiceAccount that has no permissions." }}
  {{- end }}
  {{- range $key := list "containers" "initContainers" }}
    {{- /* Gated on hasKey, not on the value being truthy: an empty or null list is falsy,
           and skipping it here would leave it in the overlay for the mergeOverwrite below,
           which replaces the chart's list and renders a pod with no containers at all. */ -}}
    {{- if hasKey $overPod $key }}
      {{- $overList := index $overPod $key }}
      {{- if or (kindIs "invalid" $overList) (and (kindIs "slice" $overList) (eq (len $overList) 0)) }}
        {{- fail (printf "CMF chart: %s.spec.template.spec.%s is empty. Entries here are merged onto the chart's own by name, so this list cannot be cleared -- for containers, an empty list would leave the pod without the chart's containers. Remove the key to keep what the chart renders, or list only the entries you want to patch or add." $overridesKey $key) }}
      {{- end }}
      {{- if not (kindIs "slice" $overList) }}
        {{- fail (printf "CMF chart: %s.spec.template.spec.%s must be a list of entries, each with a 'name', but is a %s." $overridesKey $key (kindOf $overList)) }}
      {{- end }}
      {{- $byName := dict }}
      {{- range $c := $overList }}
        {{- if not (kindIs "map" $c) }}
          {{- fail (printf "CMF chart: every entry in %s.spec.template.spec.%s must be a map, but one is a %s." $overridesKey $key (kindOf $c)) }}
        {{- end }}
        {{- if not $c.name }}
          {{- fail (printf "CMF chart: every entry in %s.spec.template.spec.%s needs a 'name' to be matched against the chart's own entries." $overridesKey $key) }}
        {{- end }}
        {{- if hasKey $byName $c.name }}
          {{- fail (printf "CMF chart: %s.spec.template.spec.%s has two entries named '%s'. Names must be unique; merge them into one entry." $overridesKey $key $c.name) }}
        {{- end }}
        {{- $_ := set $byName $c.name $c }}
      {{- end }}
      {{- $mergedList := list }}
      {{- $patched := dict }}
      {{- range $c := (index $basePod $key | default list) }}
        {{- $patch := index $byName $c.name | default dict }}
        {{- $_ := set $patched $c.name true }}
        {{- $mergedList = append $mergedList (mergeOverwrite (deepCopy $c) (deepCopy $patch)) }}
      {{- end }}
      {{- /* Entries the base does not have are appended in the order the user wrote
             them, not sorted: initContainers run sequentially, so their order is part
             of the spec. */ -}}
      {{- range $c := $overList }}
        {{- if not (hasKey $patched $c.name) }}
          {{- $mergedList = append $mergedList $c }}
        {{- end }}
      {{- end }}
      {{- $_ := set $basePod $key $mergedList }}
      {{- $_ = unset $overPod $key }}
    {{- end }}
  {{- end }}
{{- end }}
{{- $merged := mergeOverwrite $base $overrides -}}
{{- if $isDeployment }}
  {{- if gt (int (dig "spec" "replicas" 1 $merged)) 1 }}
    {{- fail (printf "CMF chart: replicas > 1 is not supported in %s, %s." $overridesKey (ternary "CMF runs as a single instance" "set cmf.statementService.workers.count to add compile workers" (eq $overridesKey "deploymentOverrides"))) }}
  {{- end }}
{{- end }}
{{- $yaml := toYaml $merged }}
{{- if not $yaml }}
  {{- fail (printf "CMF chart: the %s cannot be rendered as YAML." ($base.kind | default "manifest")) }}
{{- end }}
{{- $yaml -}}
{{- end -}}

{{/*
Common RBAC rules shared between ClusterRole and namespace-scoped Role.
Kept in one place so changes to permissions are never missed in either template.

These grants are trimmed to what CMF uses, except that "apps/deployments"
("deployments/finalizers" included), "configmaps" and "pods" below stay at the
"*" verb. CMF creates a per-environment Role that grants exactly those resources
and verbs to each environment's own ServiceAccount (used by the Flink Kubernetes
Operator); Kubernetes' RBAC escalation-prevention rule requires CMF to already
hold every permission it grants, so narrowing these here would make that
provisioning fail with 403 errors.
*/}}
{{- define "cmf.rbacRules" -}}
- apiGroups: [ "apps" ]
  resources: [ "deployments", "deployments/finalizers" ]
  verbs: [ "*" ]
- apiGroups: ["flink.apache.org"]
  resources: ["flinkdeployments", "flinksessionjobs", "flinkstatesnapshots"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
- apiGroups: [""]
  resources: ["services"]
  verbs: ["get"]
- apiGroups: [ "" ]
  resources: [ "configmaps", "pods" ]
  verbs: [ "*" ]
- apiGroups: [ "" ]
  resources: [ "pods/log" ]
  verbs: [ "get" ]
## Carry-over offsets: CMF runs a short-lived reader Job in the environment namespace.
- apiGroups: [ "batch" ]
  resources: [ "jobs" ]
  verbs: [ "create", "get", "delete" ]
- apiGroups: [ "" ]
  resources: [ "events" ]
  verbs: [ "get", "list", "watch" ]
- apiGroups: [ "" ]
  resources: [ "secrets" ]
  verbs: [ "create", "get", "delete", "update"]
{{- /* A missing key means the default (true): `helm upgrade --reuse-values` from a chart
       that predates it keeps the old values, and read-only here breaks environment create/delete. */}}
{{- if or (not (hasKey .Values "manageEnvironmentRbac")) .Values.manageEnvironmentRbac }}
- apiGroups: [ "" ]
  resources: [ "serviceaccounts" ]
  verbs: [ "create", "get", "delete"]
- apiGroups: [ "rbac.authorization.k8s.io" ]
  resources: [ "roles", "rolebindings" ]
  verbs: [ "create", "get", "delete" ]
{{- else }}
- apiGroups: [ "" ]
  resources: [ "serviceaccounts" ]
  verbs: [ "get" ]
- apiGroups: [ "rbac.authorization.k8s.io" ]
  resources: [ "roles", "rolebindings" ]
  verbs: [ "get" ]
{{- end }}
{{- end -}}

{{/*
The cmf.sql.batchRestartStrategy block CMF runs with, as YAML. A missing block, enabled or
flinkConfiguration gets the default: `helm upgrade --reuse-values` from a chart that predates the
block keeps the old values, and CMF would then add no restart strategy. Keep the default in sync
with values.yaml; render_test.sh compares the two.
*/}}
{{- define "cmf.batchRestartStrategy" -}}
{{- $block := deepCopy (dig "sql" "batchRestartStrategy" (dict) (.Values.cmf | default dict)) }}
{{- if not (hasKey $block "enabled") }}
{{- $_ := set $block "enabled" true }}
{{- end }}
{{- if not $block.flinkConfiguration }}
{{- $_ := set $block "flinkConfiguration" (dict
      "restart-strategy.type" "exponential-delay"
      "restart-strategy.exponential-delay.attempts-before-reset-backoff" "10") }}
{{- end }}
{{- toYaml $block }}
{{- end -}}
