{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "cmf.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "cmf.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cmf.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*
Common labels
*/}}
{{- define "cmf.labels" -}}
{{ include "cmf.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "cmf.chart" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cmf.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cmf.name" . }}
{{- end }}

{{/*
Validate mountedVolumes: fail on duplicate volume names and duplicate mount paths.
Call this template from deployment.yaml to run the checks at render time.
*/}}
{{- define "cmf.validateMountedVolumes" -}}
{{- $reservedVolNames := list "cmf-config" "cmf-storage" }}
{{- $reservedMountPaths := list "/opt/config" "/app/local" }}
{{- if .Values.mountedVolumes.volumes }}
  {{- $volNames := list }}
  {{- range .Values.mountedVolumes.volumes }}
    {{- if has .name $reservedVolNames }}
      {{- fail (printf "Volume name '%s' is reserved by the CMF chart and cannot be used in mountedVolumes.volumes." .name) }}
    {{- end }}
    {{- if has .name $volNames }}
      {{- fail (printf "Duplicate volume name '%s' in mountedVolumes.volumes. Each volume name must be unique." .name) }}
    {{- end }}
    {{- $volNames = append $volNames .name }}
  {{- end }}
{{- end }}
{{- if .Values.mountedVolumes.volumeMounts }}
  {{- $mountPaths := list }}
  {{- range .Values.mountedVolumes.volumeMounts }}
    {{- if has .mountPath $reservedMountPaths }}
      {{- fail (printf "Mount path '%s' is reserved by the CMF chart and cannot be used in mountedVolumes.volumeMounts." .mountPath) }}
    {{- end }}
    {{- if has .mountPath $mountPaths }}
      {{- fail (printf "Duplicate mount path '%s' in mountedVolumes.volumeMounts. Each mountPath must be unique to avoid one mount shadowing another." .mountPath) }}
    {{- end }}
    {{- $mountPaths = append $mountPaths .mountPath }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Common RBAC rules shared between ClusterRole and namespace-scoped Role.
Kept in one place so changes to permissions are never missed in either template.
*/}}
{{- define "cmf.rbacRules" -}}
- apiGroups: [ "apps" ]
  resources: [ "deployments", "deployments/finalizers" ]
  verbs: [ "*" ]
- apiGroups: ["flink.apache.org"]
  resources: ["flinkdeployments", "flinkdeployments/status", "flinksessionjobs", "flinksessionjobs/status", "flinkstatesnapshots", "flinkstatesnapshots/status"]
  verbs: ["*"]
- apiGroups: [""]
  resources: ["services"]
  verbs: ["get", "list", "watch"]
- apiGroups: [ "" ]
  resources: [ "configmaps", "pods" ]
  verbs: [ "*" ]
- apiGroups: [ "" ]
  resources: [ "pods/log" ]
  verbs: [ "get" ]
- apiGroups: [ "" ]
  resources: [ "events" ]
  verbs: [ "get", "list", "watch" ]
- apiGroups: [ "" ]
  resources: [ "secrets" ]
  verbs: [ "create", "get", "list", "watch", "delete", "update"]
{{- if .Values.manageEnvironmentRbac }}
- apiGroups: [ "" ]
  resources: [ "serviceaccounts" ]
  verbs: [ "create", "get", "list", "watch", "delete", "update"]
- apiGroups: [ "rbac.authorization.k8s.io" ]
  resources: [ "roles", "rolebindings" ]
  verbs: [ "create", "get", "list", "watch", "delete", "update", "patch" ]
{{- else }}
- apiGroups: [ "" ]
  resources: [ "serviceaccounts" ]
  verbs: [ "get", "list", "watch" ]
- apiGroups: [ "rbac.authorization.k8s.io" ]
  resources: [ "roles", "rolebindings" ]
  verbs: [ "get", "list", "watch" ]
{{- end }}
{{- end -}}
