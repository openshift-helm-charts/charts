{{/*
Chart-wide helpers. Mostly trivial wrappers around the standard Helm
patterns — extracted so templates don't repeat the boilerplate.
*/}}

{{- define "spatiumddi.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "spatiumddi.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels applied to every resource.
*/}}
{{- define "spatiumddi.labels" -}}
helm.sh/chart: {{ include "spatiumddi.chart" . }}
{{ include "spatiumddi.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "spatiumddi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "spatiumddi.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Per-component labels — include via:
  {{- include "spatiumddi.componentLabels" (merge (dict "component" "api") .) | nindent 4 }}
so the helper sees all root context plus the component name.
*/}}
{{- define "spatiumddi.componentLabels" -}}
helm.sh/chart: {{ include "spatiumddi.chart" . }}
app.kubernetes.io/name: {{ include "spatiumddi.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "spatiumddi.componentSelectorLabels" -}}
app.kubernetes.io/name: {{ include "spatiumddi.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{/*
Control-plane image — pass `imageName` (e.g. "spatiumddi-api") via merge:
  {{ include "spatiumddi.image" (merge (dict "imageName" "spatiumddi-api") .) }}
*/}}
{{- define "spatiumddi.image" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- /* #3913 — ``image.tagSuffix`` ("-ubi") selects the Red Hat UBI variant of
       the same version; empty (the default) leaves every tag as it was. */ -}}
{{- printf "%s/%s/%s:%s%s" .Values.image.registry .Values.image.repository .imageName $tag (.Values.image.tagSuffix | default "") -}}
{{- end -}}

{{/*
Control-plane nodeSelector block. Issue #272 Phase 1 — emits a
``nodeSelector:`` stanza when either ``.Values.global.controlPlane
NodeSelector`` or the component-level override is non-empty, so the
six umbrella control-plane workloads (api / frontend / worker / beat
/ postgres / redis) share one selector path.

Pass the per-component override via merge:
  {{- include "spatiumddi.controlPlaneNodeSelector" (merge (dict "componentNodeSelector" .Values.api.nodeSelector) .) | nindent 6 }}

The helper returns nothing on empty merged map, so plain K8s
installs that haven't opted into the per-role label still let the
scheduler pick.
*/}}
{{- define "spatiumddi.controlPlaneNodeSelector" -}}
{{- $globalSel := default (dict) (.Values.global).controlPlaneNodeSelector -}}
{{- $componentSel := default (dict) .componentNodeSelector -}}
{{- $merged := merge (dict) $componentSel $globalSel -}}
{{- if $merged }}
nodeSelector:
  {{- toYaml $merged | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
Emit the ``affinity:`` block for a replicated control-plane workload
(#590). Spreads a component's replicas one-per-node so a single node
loss costs at most one replica.

  {{- include "spatiumddi.podAntiAffinity" (merge (dict
        "component" "api"
        "mode" .Values.api.podAntiAffinity
        "replicas" .Values.api.replicas
        "override" .Values.api.affinity) .) | nindent 6 }}

``mode`` is one of:
  hard  — requiredDuringScheduling. The replica stays Pending until a
          distinct node is available. Correct on the appliance, where
          replicas tracks the control-plane node count exactly.
  soft  — preferredDuringScheduling. Best effort; the chart default so
          a BYO-Kubernetes install with more replicas than nodes still
          schedules.
  none  — emit no podAntiAffinity.

The default spread is MERGED into an operator-supplied
``<component>.affinity`` rather than replacing it: an operator who sets
``nodeAffinity`` (say, to keep a workload off spot/tainted nodes) must
not silently lose the cross-node spread that keeps a single node loss
survivable. Only an override that declares its OWN ``podAntiAffinity``
key wins — that one is an explicit opt-out, and merging the two would
render a duplicate key.

Nothing is spread below 2 replicas (nothing to spread), unless the pods run
on the host network (below).

``hostNetwork`` (optional, the frontend's) renders the spread at ONE replica
too (#2450). A host-network pod binds its ports on the node itself, so a
second pod of the component can never share its node anyway, and the term
changes nothing about where a lone replica can run. What it changes is the
first promotion: the supervisor raises the replicas from 1 to the node count
and nothing else, and a term that appeared only above one replica changed the
pod template there, so the frontend rolled, and it retires its old pod first.
The seed's one frontend pod, holding the node's ports 80 and 443, went before
its replacement could bind them, and the seed refused connections while the
browser that drives the promotion was on it. With the term in place at one
replica the promotion is a scale-up: the seed's pod keeps serving and the new
pods start on the new nodes. (A demote is the same scale, the other way.)

#590 — api/worker/frontend previously defaulted to no affinity at all,
so a 3-node cluster could (and did) land 3 of 4 api pods on the seed.
Losing that node meant no ready api pod anywhere, and rescheduling off
a NotReady node waits out ``node.kubernetes.io/not-ready`` first — see
the matching tolerations on the appliance paths. Redis goes through the
same helper: its replicas are the ones whose mis-placement (two on the
seed, pinned there by local-path PVs) caused the outage.
*/}}
{{/*
Emit the ``strategy:`` block for a Deployment that may carry REQUIRED pod
anti-affinity (#590).

  {{- include "spatiumddi.deploymentStrategy" (dict
        "mode" .Values.api.podAntiAffinity
        "replicas" .Values.api.replicas
        "root" $ "deployment" (printf "%s-api" (include "spatiumddi.fullname" $))
        "container" "api") | nindent 2 }}

Required anti-affinity + ``replicas == number of eligible nodes`` makes the
default surge pod UNSCHEDULABLE, and the default ``maxUnavailable: 0`` then
forbids freeing a node by retiring an old pod first. The rollout wedges
permanently: the anti-affinity labelSelector matches on ``component``, which
the OUTGOING ReplicaSet's pods carry too, so the incoming surge pod sees
every node already occupied by one of its own.

Observed live on a 1→3 promote: two new api pods landed on the freshly
promoted members, the third sat Pending forever with "3 node(s) didn't match
pod anti-affinity rules" while the old pod held the seed.

So under ``hard`` we invert the knobs — retire one old pod, then schedule its
replacement onto the node it just freed. Costs one replica of capacity during
a rollout instead of deadlocking. (frontend's hostNetwork path uses Recreate
for the same underlying reason: an exclusive per-node resource.)

#1541 — under ``hard`` this holds at ONE replica too, although a one-replica
render carries no anti-affinity of its own. The pods a rollout replaces were
rendered by the PREVIOUS values, and required anti-affinity is symmetric: an
existing pod's term keeps an incoming pod that matches it off its node just
as the incoming pod's own term would. A demote from three nodes to one
renders ``replicas: 1``, and the one surviving old pod still carries the
3-node spec's required term. Surge-first then puts the new pod beside it on
the only node, where it is refused ("didn't satisfy existing pods
anti-affinity rules"), ``maxUnavailable: 0`` forbids retiring the old pod
first, and the rollout wedges for good with the old 3-node pods serving
(observed on the #1659 walk). The chart cannot see the previous render
offline, so ``hard`` at one replica retires first unconditionally.

The cost: a one-node control plane takes a brief api / worker outage on
every rollout, the time a fresh pod takes to become ready. A one-node
cluster has no second node to surge onto in the shape that matters, and the
frontend's hostNetwork path already accepts the same trade with Recreate.
The opposite direction (1 → 3) is the ``replicas > 1`` case above and is
unchanged.

#3780 — except on a ROLLBACK at one replica. Retiring first there deletes
the newer release's only pod, and when the older release cannot run on the
schema the newer one migrated (#1227), its pod waits in ``wait-for-migrate``
forever: no api, no web UI, and so no way to re-apply the newer release from
the API, which is the documented recovery. Surge-first keeps the newer pod
serving until the older one is ready, which is never in that case, and only
a moment in the ordinary one. The release rolled back TO decides this, so it
has to be in the chart being installed, not the one being left.

So pass ``root`` (the chart root), ``deployment`` (the Deployment's name) and
``container`` (its main container) as well, and at one replica under ``hard``
the helper surges first when the live ReplicaSets (``lookup``) say:

  * a pod of this Deployment runs a SemVer release NEWER than this
    render's image tag: this render is a rollback. Ready or not: after the
    reboot onto the older slot, firstboot releases the control chart once
    k3s and the CNPG webhook answer, which is routinely before the newer
    pod has passed its readiness probe again, and a render that required
    it ready would retire it first after all. It stays true on every later
    render of the same release while the newer pod exists (the template
    already carries the older tag by then), and stops being true once the
    older pod is ready and the newer ReplicaSet scaled to 0; and
  * no ReplicaSet of it with pods carries a required anti-affinity term,
    so the #1541 wedge (a surviving 3-node pod) still retires first.

Anything it cannot read (``helm template``, a tag that is not a 1.x+ SemVer
release, a CalVer or nightly build, an image pinned by digest, no live
Deployment) retires first, as
before. An ordinary upgrade is never a rollback, so it keeps #1659's
strategy, and ``replicas > 1`` is untouched. ``replicaSets`` replaces the
lookup with a given list (the chart tests, which have no cluster).
*/}}
{{- define "spatiumddi.deploymentStrategy" -}}
{{- $mode := default "soft" .mode -}}
{{- $keepServing := and (eq $mode "hard") (eq (int .replicas) 1) .root
      (eq (include "spatiumddi.newerReleaseServing" .) "true") -}}
strategy:
  type: RollingUpdate
  rollingUpdate:
  {{- if and (eq $mode "hard") (not $keepServing) }}
    maxSurge: 0
    maxUnavailable: 1
  {{- else }}
    maxSurge: 1
    maxUnavailable: 0
  {{- end }}
{{- end -}}

{{/*
"true" when this render rolls ``deployment`` back from a newer release that
still serves (#3780; see spatiumddi.deploymentStrategy). Only 1.x and later
SemVer tags count: a CalVer tag (YYYY.MM.DD-N), a nightly (0.0.0-...), "dev"
or "latest" is an unknown version, never an older one (core/versions.py).
*/}}
{{- define "spatiumddi.newerReleaseServing" -}}
{{- $root := .root -}}
{{- $release := `^[1-9][0-9]{0,2}\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$` -}}
{{- $ours := toString ($root.Values.image.tag | default $root.Chart.AppVersion) -}}
{{- $newer := false -}}
{{- $blocked := false -}}
{{- if regexMatch $release $ours -}}
  {{- $items := .replicaSets -}}
  {{- if not (hasKey . "replicaSets") -}}
    {{- $items = get (default (dict) (lookup "apps/v1" "ReplicaSet" $root.Release.Namespace "")) "items" -}}
  {{- end -}}
  {{- range $rs := (default (list) $items) -}}
    {{- $owned := false -}}
    {{- range $ref := (default (list) (dig "metadata" "ownerReferences" (list) $rs)) -}}
      {{- if and (eq (toString $ref.kind) "Deployment") (eq (toString $ref.name) (toString $.deployment)) -}}
        {{- $owned = true -}}
      {{- end -}}
    {{- end -}}
    {{- if and $owned (gt (int (dig "status" "replicas" 0 $rs)) 0) -}}
      {{- $podSpec := dig "spec" "template" "spec" (dict) $rs -}}
      {{- if dig "affinity" "podAntiAffinity" "requiredDuringSchedulingIgnoredDuringExecution" (list) $podSpec -}}
        {{- $blocked = true -}}
      {{- end -}}
      {{- range $c := (default (list) $podSpec.containers) -}}
        {{- if eq (toString $c.name) (toString $.container) -}}
          {{- $tag := last (splitList ":" (last (splitList "/" (toString $c.image)))) -}}
          {{- if and (regexMatch $release $tag) (gt ((semver $tag).Compare (semver $ours)) 0) -}}
            {{- $newer = true -}}
          {{- end -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if and $newer (not $blocked) }}true{{ end -}}
{{- end -}}

{{- define "spatiumddi.podAntiAffinity" -}}
{{- $mode := default "soft" .mode -}}
{{- $affinity := deepCopy (default (dict) .override) -}}
{{- $spread := or (gt (int .replicas) 1) (get . "hostNetwork") -}}
{{- if and $spread (ne $mode "none") (not (hasKey $affinity "podAntiAffinity")) -}}
  {{- $selector := dict "matchLabels" (include "spatiumddi.componentSelectorLabels" . | fromYaml) -}}
  {{- $term := dict "labelSelector" $selector "topologyKey" "kubernetes.io/hostname" -}}
  {{- if eq $mode "hard" -}}
    {{- $_ := set $affinity "podAntiAffinity" (dict "requiredDuringSchedulingIgnoredDuringExecution" (list $term)) -}}
  {{- else -}}
    {{- $weighted := dict "weight" 100 "podAffinityTerm" $term -}}
    {{- $_ := set $affinity "podAntiAffinity" (dict "preferredDuringSchedulingIgnoredDuringExecution" (list $weighted)) -}}
  {{- end -}}
{{- end -}}
{{- if $affinity }}
affinity:
  {{- toYaml $affinity | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
Object name of one agent server's StatefulSet / Service / headless Service
(#3209). Pass ``root`` (the chart root), ``instance`` (``dns-bind9-ns1``) and
``prefix`` (``<kind>Agents.prefixWithFullname``).

Off (the default) it is ``instance`` unchanged: renaming a StatefulSet
recreates it, and through the claim-template names its PVCs, so the new
naming is opt-in for an existing install. On, it is prefixed with the release
fullname like every other object in the chart (which honours
``fullnameOverride``). Capped at 52 characters: the longest suffix added
to it is ``-headless`` (9) and Kubernetes caps a Service name at 63; a
StatefulSet's pods and ControllerRevision labels need the same headroom.

A name over 52 is NOT plainly truncated: two servers that differ only past
the cut (``...-ns1`` / ``...-ns2``), or every agent under a long
``fullnameOverride``, would come out identical and Helm would apply one
object over the other. It keeps the first 43 characters and appends ``-``
plus 8 hex characters of the full name's sha256, so distinct full names stay
distinct and the result is stable across renders. A name that fits is used
as is.

The Service must be a DNS-1035 label, which starts with a letter. The
fullname follows the release name, and Helm accepts a release named
``1dev``, so a prefixed name starting with anything else fails the render
here, naming the fix, instead of at the API server on the first Service.
*/}}
{{- define "spatiumddi.agentObjectName" -}}
{{- if .prefix -}}
{{- $full := printf "%s-%s" (include "spatiumddi.fullname" .root) .instance -}}
{{- if not (regexMatch "^[a-z]" $full) -}}
{{- fail (printf "agent object name %q (dnsAgents/dhcpAgents.prefixWithFullname) must start with a lowercase letter to be a valid Service name (DNS-1035); use a release name or fullnameOverride that starts with one, or leave prefixWithFullname false" $full) -}}
{{- end -}}
{{- if le (len $full) 52 -}}
{{- $full -}}
{{- else -}}
{{- printf "%s-%s" ($full | trunc 43 | trimSuffix "-") ($full | sha256sum | trunc 8) -}}
{{- end -}}
{{- else -}}
{{- .instance -}}
{{- end -}}
{{- end -}}

{{/*
#3209 — refuse two agent servers that would render the same object name.
Helm does not: the later StatefulSet and Services silently replace the
earlier ones, so one configured server never runs. Covers both agent kinds,
since a fullname-prefixed DNS and DHCP name share one namespace of objects.
Called from dns-agent.yaml and dhcp-agent.yaml; ``.`` is the chart root.
*/}}
{{- define "spatiumddi.agentNamesUnique" -}}
{{- $seen := dict -}}
{{- if .Values.dnsAgents.enabled -}}
{{- range .Values.dnsAgents.servers -}}
{{- $n := include "spatiumddi.agentObjectName" (dict "root" $ "instance" (printf "dns-%s-%s" (.flavor | default "bind9") .name) "prefix" $.Values.dnsAgents.prefixWithFullname) -}}
{{- $sname := .name -}}
{{- range $obj := list $n (printf "%s-headless" $n) -}}
{{- if hasKey $seen $obj -}}
{{- fail (printf "dnsAgents server %q renders object name %q, already used by server %q; server names must be unique (each server owns <name> and <name>-headless)" $sname $obj (get $seen $obj)) -}}
{{- end -}}
{{- $_ := set $seen $obj $sname -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if .Values.dhcpAgents.enabled -}}
{{- range .Values.dhcpAgents.servers -}}
{{- $n := include "spatiumddi.agentObjectName" (dict "root" $ "instance" (printf "dhcp-%s-%s" (.flavor | default "kea") .name) "prefix" $.Values.dhcpAgents.prefixWithFullname) -}}
{{- $sname := .name -}}
{{- range $obj := list $n (printf "%s-headless" $n) -}}
{{- if hasKey $seen $obj -}}
{{- fail (printf "dhcpAgents server %q renders object name %q, already used by server %q; server names must be unique (each server owns <name> and <name>-headless)" $sname $obj (get $seen $obj)) -}}
{{- end -}}
{{- $_ := set $seen $obj $sname -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
``affinity:`` block of a DNS / DHCP agent pod (#3206). The chart's own
preferred one-agent-per-node anti-affinity is MERGED into the per-server
``affinity`` rather than replaced by it, so an operator who adds
``nodeAffinity`` keeps the spread; only a ``podAntiAffinity`` of their own
wins (an explicit opt-out). With no per-server ``affinity`` the block is the
literal the templates always rendered.

  {{- include "spatiumddi.agentAffinity" (dict "root" $root "component" "dns-agent" "override" $server.affinity) | nindent 6 }}
*/}}
{{- define "spatiumddi.agentAffinity" -}}
{{- $override := default (dict) .override -}}
{{- $label := dict "app.kubernetes.io/name" (include "spatiumddi.name" .root) "app.kubernetes.io/component" .component -}}
affinity:
{{- if $override }}
  {{- $merged := deepCopy $override -}}
  {{- if not (hasKey $merged "podAntiAffinity") -}}
    {{- $term := dict "labelSelector" (dict "matchLabels" $label) "topologyKey" "kubernetes.io/hostname" -}}
    {{- $_ := set $merged "podAntiAffinity" (dict "preferredDuringSchedulingIgnoredDuringExecution" (list (dict "weight" 100 "podAffinityTerm" $term))) -}}
  {{- end }}
  {{- toYaml $merged | nindent 2 }}
{{- else }}
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        podAffinityTerm:
          labelSelector:
            matchLabels:
              app.kubernetes.io/name: {{ include "spatiumddi.name" .root }}
              app.kubernetes.io/component: {{ .component }}
          topologyKey: kubernetes.io/hostname
{{- end }}
{{- end -}}

{{/*
Name of the chart-owned secret carrying SECRET_KEY.
*/}}
{{- define "spatiumddi.appSecretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- .Values.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-app" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Postgres connection parameters. Hostname + port + user + database come from
either the in-chart Postgres StatefulSet (templates/postgres.yaml) or the
externalDatabase block; the password is always referenced via a Secret
keyRef — never inlined.
*/}}
{{- define "spatiumddi.postgresHost" -}}
{{- if .Values.postgresql.enabled -}}
{{- if eq (.Values.postgresql.kind | default "standalone") "cnpg" -}}
{{/* CNPG auto-creates ``<cluster>-rw`` for the primary read/write
     service. The cluster object's name is the chart's fullname
     (see templates/cnpg-cluster.yaml). */}}
{{- printf "%s-postgresql-rw" (include "spatiumddi.fullname" .) -}}
{{- else -}}
{{- printf "%s-postgresql" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- else -}}
{{- required "externalDatabase.host is required when postgresql.enabled=false" .Values.externalDatabase.host -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.postgresPort" -}}
{{- if .Values.postgresql.enabled -}}5432{{- else -}}{{ .Values.externalDatabase.port }}{{- end -}}
{{- end -}}

{{- define "spatiumddi.postgresUser" -}}
{{- if .Values.postgresql.enabled -}}{{ .Values.postgresql.auth.username }}{{- else -}}{{ .Values.externalDatabase.username }}{{- end -}}
{{- end -}}

{{- define "spatiumddi.postgresDatabase" -}}
{{- if .Values.postgresql.enabled -}}{{ .Values.postgresql.auth.database }}{{- else -}}{{ .Values.externalDatabase.database }}{{- end -}}
{{- end -}}

{{/*
Name of the secret carrying the Postgres user password. For the in-
chart Postgres this is the chart-owned ``<fullname>-postgresql`` Secret
(key ``password``) — generated on first install via lookup() and
preserved across upgrades. ``postgresql.auth.existingSecret`` overrides
to a BYO secret. For external DB it's whatever the user set in
externalDatabase.existingSecret.
*/}}
{{- define "spatiumddi.postgresSecretName" -}}
{{- if .Values.postgresql.enabled -}}
{{- if .Values.postgresql.auth.existingSecret -}}
{{- .Values.postgresql.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-postgresql" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- else if .Values.externalDatabase.existingSecret -}}
{{- .Values.externalDatabase.existingSecret -}}
{{- else -}}
{{- printf "%s-external-db" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.postgresSecretPasswordKey" -}}
{{- if .Values.postgresql.enabled -}}password{{- else -}}{{ .Values.externalDatabase.existingSecretPasswordKey | default "password" }}{{- end -}}
{{- end -}}

{{/*
Redis connection. Hostname + port from either the bundled subchart or
externalRedis.
*/}}
{{- define "spatiumddi.redisHost" -}}
{{- if .Values.redis.enabled -}}
{{- printf "%s-redis-master" (include "spatiumddi.fullname" .) -}}
{{- else -}}
{{- required "externalRedis.host is required when redis.enabled=false" .Values.externalRedis.host -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.redisPort" -}}
{{- if .Values.redis.enabled -}}6379{{- else -}}{{ .Values.externalRedis.port }}{{- end -}}
{{- end -}}

{{/*
True when the chart-owned Redis runs in Sentinel mode (#272 Phase 3).
Drives the sentinel:// URL branch in commonEnv + the master-name env.
*/}}
{{- define "spatiumddi.redisIsSentinel" -}}
{{- if and .Values.redis.enabled (eq (.Values.redis.kind | default "standalone") "sentinel") -}}true{{- end -}}
{{- end -}}

{{/*
Comma-separated sentinel host:port list for the redis-py-style
sentinel:// URL. Points at the per-pod headless DNS so the client can
reach every sentinel even mid-failover; the sentinel Service fronts
the same set for kombu.
*/}}
{{- define "spatiumddi.redisSentinelHosts" -}}
{{- $fullname := include "spatiumddi.fullname" . -}}
{{- $sts := printf "%s-redis" $fullname -}}
{{- $headless := printf "%s-redis-headless" $fullname -}}
{{- $n := int .Values.redis.sentinel.replicas -}}
{{- $hosts := list -}}
{{- range $i := until $n -}}
{{- $hosts = append $hosts (printf "%s-%d.%s.%s.svc.cluster.local:26379" $sts $i $headless $.Release.Namespace) -}}
{{- end -}}
{{- join "," $hosts -}}
{{- end -}}

{{- define "spatiumddi.redisAuthEnabled" -}}
{{- if .Values.redis.enabled -}}
{{- if .Values.redis.auth.enabled -}}true{{- end -}}
{{- else -}}
{{- if or .Values.externalRedis.password .Values.externalRedis.existingSecret -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.redisSecretName" -}}
{{- if .Values.redis.enabled -}}
{{- if .Values.redis.auth.existingSecret -}}
{{- .Values.redis.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-redis" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- else if .Values.externalRedis.existingSecret -}}
{{- .Values.externalRedis.existingSecret -}}
{{- else -}}
{{- printf "%s-external-redis" (include "spatiumddi.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "spatiumddi.redisSecretPasswordKey" -}}
{{- if .Values.redis.enabled -}}redis-password{{- else -}}{{ .Values.externalRedis.existingSecretPasswordKey | default "password" }}{{- end -}}
{{- end -}}

{{/*
Env shared by the api, worker AND beat — and deliberately NOT by the migrate
Job or the slot-image mirror, which also include commonEnv. (#1826) The three
run the same image and read the same ``settings``, but their env used to be
written three times with the api getting the appliance block: the worker and
beat ran with ``APPLIANCE_MODE`` unset, so every ``appliance_mode`` gate
(``node_pressure``, ``cluster_dns_degraded``, the rolling-upgrade
orchestrator, ...) evaluated as off in the one process that runs alert
evaluation. Put anything the Celery side reads in ``sharedEnv`` (values.yaml),
not in ``api.env``. ``.github/scripts/chart-shared-env.py`` fails a render
where one of the three lacks a variable another carries from this list.

``applianceVersion`` (#2004, #2176) is appended to the same list as
APPLIANCE_VERSION. It is a value of its own so that a cluster Rolling Upgrade
can hold it with ``image.tag``: a HelmChartConfig can pin a scalar, never one
entry of a list.

The slot-image mirror client env is a separate helper
(``spatiumddi.slotImageMirrorClientEnv``) because beat never talks to the
mirror and has no use for its shared secret.
*/}}
{{- define "spatiumddi.sharedEnv" -}}
{{- $env := .Values.sharedEnv | default list }}
{{- with .Values.applianceVersion }}
{{- $env = append $env (dict "name" "APPLIANCE_VERSION" "value" (toString .)) }}
{{- end }}
{{- with $env }}
{{- toYaml . }}
{{- end }}
{{- end -}}

{{/*
Slot-image mirror client env, for the api AND the worker (#1826). The api
proxies upgrade-image byte ops to the mirror; the worker runs the
rolling-upgrade preflight, whose mirror disk-headroom check needs the URL and
signs its request with the secret. Before #1826 only the api had them, so the
worker's preflight reported "no mirror configured". Not beat: it only
enqueues, so it gets no copy of the secret.
*/}}
{{- define "spatiumddi.slotImageMirrorClientEnv" -}}
{{- if .Values.slotImageMirror.enabled }}
- name: SLOT_IMAGE_MIRROR_URL
  value: "http://{{ include "spatiumddi.fullname" . }}-slot-image-mirror.{{ .Release.Namespace }}.svc:8000"
- name: SLOT_IMAGE_MIRROR_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.fullname" . }}-slot-image-mirror-auth
      key: secret
{{- end }}
{{- end -}}

{{/*
Common env block for api / worker / beat. Only $(POSTGRES_PASSWORD) and
$(REDIS_PASSWORD) reference secrets; everything else is inline.
*/}}
{{- define "spatiumddi.commonEnv" -}}
{{/* Issue #274 — running version, surfaced by the api as
     ``settings.version`` and rendered in the sidebar's lower-
     left "v…" chip. Mirrors the docker-compose ``VERSION:
     ${SPATIUMDDI_VERSION:-dev}`` wiring on the helm path.
     Precedence: operator-pinned ``image.tag`` wins (e.g. for a
     manual rollback) → chart-packaged ``.Chart.AppVersion`` (the
     release tag the release workflow stamps via
     ``helm package --app-version``) → falls through to the
     api's own ``"dev"`` fallback in ``app/config.py``. Same
     resolution chain as the existing ``spatiumddi.image``
     helper so the env value tracks the running image tag. */}}
- name: VERSION
  value: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
- name: POSTGRES_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.postgresSecretName" . }}
      key: {{ include "spatiumddi.postgresSecretPasswordKey" . }}
- name: SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.appSecretName" . }}
      key: secret-key
# #1358 — the dedicated key stored credentials are encrypted under. Optional:
# a Secret supplied through auth.existingSecret may not carry it, and the api
# then derives the key from SECRET_KEY as before.
- name: CREDENTIAL_ENCRYPTION_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.appSecretName" . }}
      key: credential-key
      optional: true
# #1358 — the release whose rollout added credential-key to a running
# install; while the api runs that release it reads the key but does not
# write with it (see templates/secret.yaml). Optional, like the key.
- name: CREDENTIAL_KEY_SINCE
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.appSecretName" . }}
      key: credential-key-since
      optional: true
# #1159 — the /metrics scrape token. Optional: a Secret supplied through
# auth.existingSecret may not carry it, and then only API tokens can scrape.
- name: PROMETHEUS_METRICS_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.appSecretName" . }}
      key: metrics-token
      optional: true
# #4548 — bcrypt hash the very first `admin` user is created with, instead of
# admin / admin (and without a forced password change). Optional: absent on
# every install that did not choose one, which keeps the old default account.
- name: INITIAL_ADMIN_PASSWORD_HASH
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.appSecretName" . }}
      key: initial-admin-password-hash
      optional: true
- name: DATABASE_URL
  value: "postgresql+asyncpg://{{ include "spatiumddi.postgresUser" . }}:$(POSTGRES_PASSWORD)@{{ include "spatiumddi.postgresHost" . }}:{{ include "spatiumddi.postgresPort" . }}/{{ include "spatiumddi.postgresDatabase" . }}"
{{- if eq (include "spatiumddi.redisIsSentinel" .) "true" }}
{{- $sentinelHosts := include "spatiumddi.redisSentinelHosts" . }}
{{- $sentinelSvc := printf "%s-redis-sentinel" (include "spatiumddi.fullname" .) }}
{{- /* #272 Phase 3 — Redis Sentinel. The app's redis-py helper parses
       the comma-separated host list in REDIS_URL; Celery/kombu reaches
       the sentinels through the Service VIP + the master_name set in
       celery_app.py's broker_transport_options. */}}
- name: REDIS_SENTINEL_MASTER
  value: {{ .Values.redis.sentinel.masterName | quote }}
{{- if .Values.redis.auth.enabled }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.redisSecretName" . }}
      key: {{ include "spatiumddi.redisSecretPasswordKey" . }}
- name: REDIS_SENTINEL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.redisSecretName" . }}
      key: {{ include "spatiumddi.redisSecretPasswordKey" . }}
- name: REDIS_URL
  value: "sentinel://:$(REDIS_PASSWORD)@{{ $sentinelHosts }}/0"
- name: CELERY_BROKER_URL
  value: "sentinel://:$(REDIS_PASSWORD)@{{ $sentinelSvc }}:26379/1"
- name: CELERY_RESULT_BACKEND
  value: "sentinel://:$(REDIS_PASSWORD)@{{ $sentinelSvc }}:26379/2"
{{- else }}
- name: REDIS_URL
  value: "sentinel://{{ $sentinelHosts }}/0"
- name: CELERY_BROKER_URL
  value: "sentinel://{{ $sentinelSvc }}:26379/1"
- name: CELERY_RESULT_BACKEND
  value: "sentinel://{{ $sentinelSvc }}:26379/2"
{{- end }}
{{- else if eq (include "spatiumddi.redisAuthEnabled" .) "true" }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "spatiumddi.redisSecretName" . }}
      key: {{ include "spatiumddi.redisSecretPasswordKey" . }}
- name: REDIS_URL
  value: "redis://:$(REDIS_PASSWORD)@{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/0"
- name: CELERY_BROKER_URL
  value: "redis://:$(REDIS_PASSWORD)@{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/1"
- name: CELERY_RESULT_BACKEND
  value: "redis://:$(REDIS_PASSWORD)@{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/2"
{{- else }}
- name: REDIS_URL
  value: "redis://{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/0"
- name: CELERY_BROKER_URL
  value: "redis://{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/1"
- name: CELERY_RESULT_BACKEND
  value: "redis://{{ include "spatiumddi.redisHost" . }}:{{ include "spatiumddi.redisPort" . }}/2"
{{- end }}
{{- if .Values.dnsAgents.enabled }}
{{/* DNS agent PSK — agents bootstrap-register against the api with
     this key, so the api / worker pods need it to verify the
     incoming registration handshake. The Secret is rendered by
     templates/dns-agent.yaml under the same name + key. */}}
- name: DNS_AGENT_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.dnsAgents.agentKey.existingSecret | default (printf "%s-dns-agent-key" (include "spatiumddi.fullname" .)) }}
      key: DNS_AGENT_KEY
{{- end }}
{{- if .Values.dhcpAgents.enabled }}
{{/* DHCP agent PSK. Agent side env var is SPATIUM_AGENT_KEY, but the
     control plane reads DHCP_AGENT_KEY (see backend/app/api/v1/dhcp/
     agents.py). The dhcp-agent Secret stores under SPATIUM_AGENT_KEY
     so we name the env var differently while pointing at the same
     value. */}}
- name: DHCP_AGENT_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.dhcpAgents.agentKey.existingSecret | default (printf "%s-dhcp-agent-key" (include "spatiumddi.fullname" .)) }}
      key: SPATIUM_AGENT_KEY
{{- end -}}
{{- end -}}

{{/*
#3208 — resources of the ``wait-for-*`` init containers (``initContainers.
resources``). ``alembic`` in the wait-for-migrate loop imports the whole app's
model tree, so the memory limit leaves room for that.
*/}}
{{- define "spatiumddi.initContainerResources" -}}
{{- toYaml (default (dict "requests" (dict "cpu" "10m" "memory" "32Mi") "limits" (dict "memory" "256Mi")) (.Values.initContainers).resources) -}}
{{- end -}}

{{/*
Init container that blocks until the bundled / external Postgres is
accepting connections. Used by the migrate Job. ``pg_isready`` ships in
the api image (postgresql-client-16, see backend/Dockerfile).
*/}}
{{- define "spatiumddi.waitForPostgresInit" -}}
- name: wait-for-postgres
  image: {{ include "spatiumddi.image" (merge (dict "imageName" "spatiumddi-api") .) }}
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command:
    - sh
    - -c
    - |
      until pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" -t 3 >/dev/null 2>&1; do
        echo "waiting for postgres at $PGHOST:$PGPORT..."
        sleep 3
      done
      echo "postgres is accepting connections"
  env:
    - name: PGHOST
      value: {{ include "spatiumddi.postgresHost" . | quote }}
    - name: PGPORT
      value: {{ include "spatiumddi.postgresPort" . | quote }}
    - name: PGUSER
      value: {{ include "spatiumddi.postgresUser" . | quote }}
    - name: PGDATABASE
      value: {{ include "spatiumddi.postgresDatabase" . | quote }}
  resources:
    {{- include "spatiumddi.initContainerResources" . | nindent 4 }}
{{- end -}}

{{/*
Init container that blocks until the DB schema reaches the alembic
head(s) baked into THIS image. Used by api / worker / beat.

Why "reach head" and not just "any alembic row exists" (#272 Phase 4 /
Phase 8 — rolling-upgrade ordering): during a chart upgrade the new
api/worker/beat Pods carry a newer image whose alembic head has moved.
If we only waited for *some* alembic_version row, a new Pod could start
against the OLD schema and hit UndefinedColumnError on the first request
touching a new column. By comparing this image's ``alembic heads``
against the live DB's ``alembic current`` we guarantee the migrate Job
(same new image) has finished applying the new migration before any new
app Pod accepts traffic.

Uses ``alembic`` from the api image (same binary + DATABASE_URL the
migrate Job uses), so no psql / secret plumbing is needed here — the
URL comes from commonEnv.
*/}}
{{- define "spatiumddi.waitForMigrateInit" -}}
- name: wait-for-migrate
  image: {{ include "spatiumddi.image" (merge (dict "imageName" "spatiumddi-api") .) }}
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command:
    - sh
    - -c
    - |
      # Head(s) compiled into this image's migration tree. ``$1`` drops
      # the trailing "(head)" annotation; sort makes the comparison
      # order-independent across branched heads.
      HEADS=$(alembic heads 2>/dev/null | awk '{print $1}' | sort | tr '\n' ',')
      echo "this image's alembic head(s): ${HEADS:-<none>}"
      EXPLAINED=
      while :; do
        OUT=$(alembic current 2>/dev/null)
        # Revision lines only: a failure prints a multi-line explanation.
        CUR=$(printf '%s\n' "$OUT" | awk '$1 ~ /^[0-9a-f]+$/ {print $1}' | sort | tr '\n' ',')
        if [ -n "$CUR" ] && [ "$CUR" = "$HEADS" ]; then
          # #4678 — a restore replays the archive's head before it migrates
          # up, so head alone is not enough while one is running. Exit 3
          # means it is; anything else (no module, no database, an error)
          # passes, so this can only ever add waiting.
          GATE=0
          python -m app.core.restore_gate || GATE=$?
          if [ "$GATE" -ne 3 ]; then
            echo "alembic at head ($CUR)"
            break
          fi
          echo "alembic at head ($CUR), but a backup restore is running; waiting"
          sleep 3
          continue
        fi
        # #1227 — a database a NEWER release migrated never reaches this
        # image's head, so this loop cannot end on its own. env.py names the
        # cause; say it here too, once, where the operator is looking.
        # (The migrate Job that also says it is deleted by its TTL.)
        if [ -z "$EXPLAINED" ] && printf '%s' "$OUT" | grep -q "NEWER SpatiumDDI release"; then
          printf '%s\n' "$OUT"
          EXPLAINED=1
        fi
        LABEL=${CUR:-<unreachable/empty>}
        [ -n "$EXPLAINED" ] && LABEL="<written by a newer release, see above>"
        echo "waiting for alembic to reach head; current=$LABEL"
        sleep 3
      done
  env:
    {{- include "spatiumddi.commonEnv" . | nindent 4 }}
  resources:
    {{- include "spatiumddi.initContainerResources" . | nindent 4 }}
{{- end -}}

{{/*
#983 — the pod-level seccomp profile applied to every workload this chart
renders.

Kubernetes runs a container ``Unconfined`` unless a profile is asked for,
while docker-compose applies the runtime's default profile to every
service. So without this the SAME container images run with FEWER syscall
restrictions under Kubernetes than under Compose — a regression, not a
gap. ``RuntimeDefault`` under containerd is the same profile family
Compose gets from Docker, which is also why it is low-risk: the raw
sockets Kea needs, the api's pcap capture (#59) and nmap (#58) all
already run under it on a Compose install.

Returns the bare type string (or nothing when disabled) so a caller can
place it inside an existing ``securityContext:`` block or open its own:

    {{- with (include "spatiumddi.seccompProfileType" .) }}
    securityContext:
      seccompProfile:
        type: {{ . }}
    {{- end }}

``Localhost`` is rejected rather than passed through: it needs a
``localhostProfile`` path relative to the kubelet's seccomp root, which
this chart has no way to place on the node. Set the value to ``""`` to
omit the block entirely (an exotic runtime whose default profile breaks a
workload) — that restores the pre-#983 behaviour, it does not harden
anything.
*/}}
{{- define "spatiumddi.seccompProfileType" -}}
{{- $t := default "" (.Values.global).seccompProfile -}}
{{- if and $t (not (has $t (list "RuntimeDefault" "Unconfined"))) -}}
{{- fail (printf "global.seccompProfile must be \"RuntimeDefault\", \"Unconfined\" or \"\" — got %q. Localhost profiles need a localhostProfile path this chart cannot place on the node." $t) -}}
{{- end -}}
{{- $t -}}
{{- end -}}

{{/*
#983 — resolve a workload's PriorityClass name.

Every pod this chart renders is Burstable at priority 0 by default, which
makes them indistinguishable to two schedulers' worth of ranking:
kubelet eviction under memory / ephemeral-storage pressure orders victims
by priority THEN usage-over-request, and scheduler preemption gives a
pending pod no claim on a full node. With every priority equal, the
likeliest eviction victim is whichever pod grew the most — on an
appliance, BIND with a warm cache.

Defaults to empty: a bring-your-own cluster has its own priority policy,
and naming a PriorityClass that does not exist makes the apiserver
REJECT the pod outright, so this must never be set speculatively. The
appliance overlay (spatiumddi-firstboot's spatium-control valuesContent)
sets ``global.priorityClassName`` to the class the appliance chart
renders.

Args: ``component`` (the per-workload override) and ``fallback`` (the
chart-wide default). Returns the resolved name, or nothing.

UNSET and EMPTY are different, deliberately: a per-workload key left unset
(the shipped default, YAML null) INHERITS the chart-wide value, while
setting it to ``""`` means "no class for this one" and overrides a
non-empty chart-wide value. Sprig's ``default`` cannot express that — it
treats null and "" alike — so the nil test is explicit. Without it
``priorityClassName: ""`` would silently inherit, which is the opposite of
what a key documented as an override should do, and there would be no way
to leave a single workload unranked on a cluster that has a global policy.
*/}}
{{- define "spatiumddi.priorityClassName" -}}
{{- if kindIs "invalid" .component -}}
{{- default "" .fallback -}}
{{- else -}}
{{- .component -}}
{{- end -}}
{{- end -}}

{{/*
#983 Phase 2 item 8 — topology spread for a replicated control-plane
workload, umbrella chart only.

Only meaningful in ``soft`` anti-affinity mode. ``preferred`` anti-affinity
is a *preference*: the scheduler weighs it against everything else and can
still land three api replicas on one node, which is the whole failure the
replica count exists to avoid. ``maxSkew: 1`` with
``whenUnsatisfiable: ScheduleAnyway`` is a second, differently-shaped push
toward one-per-node that still degrades to "schedule it somewhere" rather
than leaving a replica Pending.

Emitted for NEITHER of the other two modes, on purpose:

  * ``hard`` already pins one replica per node with required anti-affinity —
    the appliance's shape (#590), where replicas track the control-plane node
    count exactly. A spread constraint there is inert at best.
  * ``none`` means the operator has taken placement into their own hands.

Also skipped at ``replicas: 1``, where there is nothing to spread, and
whenever the operator supplied their own ``topologySpreadConstraints`` —
this augments a default, it never overrides an explicit choice.

``ScheduleAnyway`` rather than ``DoNotSchedule`` is the load-bearing part:
DoNotSchedule on a cluster with fewer ready nodes than replicas leaves the
surplus permanently Pending, which converts a placement preference into an
outage. Operators who want the strict form set ``hard``.
*/}}
{{- define "spatiumddi.topologySpreadConstraints" -}}
{{- $mode := default "soft" .mode -}}
{{- if .override -}}
topologySpreadConstraints:
  {{- toYaml .override | nindent 2 }}
{{- else if and (gt (int .replicas) 1) (eq $mode "soft") -}}
{{- $selector := dict "matchLabels" (include "spatiumddi.componentSelectorLabels" . | fromYaml) -}}
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      {{- toYaml $selector | nindent 6 }}
{{- end -}}
{{- end -}}

{{/*
#983 Phase 2 item 5 — user namespaces (``hostUsers: false``, GA in
Kubernetes 1.36). Container root maps to an unprivileged host uid, so an
escape from the pod is not root on the node.

Default UNSET everywhere and it must stay that way in this chart: a
bring-your-own cluster may run a runtime without idmapped-mount support, and
there the pod does not start. Failing to start with a clear event is the
right failure — but it is still a failure, so it has to be the operator's
choice, not a chart default.

THE ELIGIBILITY LIST IN #983 IS WRONG ABOUT THE APPLIANCE, and this helper
is where that gets enforced rather than commented. The issue reasoned that
``api`` and ``worker`` neither hostNetwork nor hostPath-mount, which is true
of a plain Kubernetes install and false of an appliance: with
``api.applianceHostMounts.enabled`` the api bind-mounts five host
directories (and WRITES the slot-upgrade triggers and the maintenance flag),
and the worker bind-mounts the shared pcap store. spatiumddi-firstboot
chowns those 1000:1000 to match the image's uid — a mapping that a user
namespace changes by definition. That is the same "a wrong uid map corrupts
data rather than failing to start" hazard the issue reserved for Postgres,
so the combination is refused outright instead of being left to discover.

A PVC carries a quieter version of the same hazard on the appliance, where
the StorageClass is local-path and a PVC is a host directory underneath.
That one is documented at each knob rather than refused: the runtime may
idmap it correctly, and refusing would leave redis with no way to opt in on
a cluster where it works.

Args: ``value`` (bool or nil), ``conflict`` (bool), ``workload``, ``why``.
*/}}
{{- define "spatiumddi.hostUsers" -}}
{{- if not (kindIs "invalid" .value) -}}
{{- if and (not .value) .conflict -}}
{{- fail (printf "%s.hostUsers=false is refused: %s. A user namespace remaps every uid in the pod, so host files chowned to the image's uid stop being readable — and for a directory the pod WRITES that corrupts state rather than failing to start. Either leave hostUsers unset here, or turn off the host mounts." .workload .why) -}}
{{- end -}}
hostUsers: {{ .value }}
{{- end -}}
{{- end -}}

{{/*
#2955 — the Postgres ``max_connections`` the configured pools can hold, the
same rule the appliance applies (``k8s_api.postgres_connection_budget``):

  api pods   x (pool size + maxOverflow + 2 hooks + 1 readiness probe)
  workers    x (concurrency x (1 + 2 hooks) + 1)
  celery-beat  2 hooks + 1
  WAL senders  one per CNPG replica
  reserve      10 (superuser_reserved_connections' 3, a migrate Job, psql)

The api count is the HPA's maxReplicas while autoscaling is on (the replica
count the HPA can reach), else ``api.replicas``. An unset
``api.databasePool`` is the application's own 10 + 20. Used by the standalone
Postgres StatefulSet and by the CNPG Cluster whenever the operator leaves
``max_connections`` empty; the appliance sets its own explicitly.
*/}}
{{- define "spatiumddi.postgresMaxConnections" -}}
{{- $pool := .Values.api.databasePool | default dict -}}
{{- $size := 10 -}}
{{- if not (kindIs "invalid" $pool.size) }}{{ $size = int $pool.size }}{{ end -}}
{{- $overflow := 20 -}}
{{- if not (kindIs "invalid" $pool.maxOverflow) }}{{ $overflow = int $pool.maxOverflow }}{{ end -}}
{{- $apiPods := int .Values.api.replicas -}}
{{- if .Values.api.autoscaling.enabled }}{{ $apiPods = max (int .Values.api.autoscaling.maxReplicas) (int .Values.api.autoscaling.minReplicas) }}{{ end -}}
{{- $api := mul $apiPods (add $size $overflow 2 1) -}}
{{- $worker := mul (int .Values.worker.replicas) (add (mul (int .Values.worker.concurrency) 3) 1) -}}
{{- $senders := 0 -}}
{{- if eq (.Values.postgresql.kind | default "standalone") "cnpg" }}{{ $senders = sub (int .Values.postgresql.cnpg.instances) 1 }}{{ end -}}
{{- add $api $worker 3 $senders 10 -}}
{{- end }}

{{/*
#2955 — Postgres ``shared_buffers`` in MiB: the CNPG parameter (kB / MB / GB /
TB, or a bare count of 8 kB pages, as Postgres reads it), else the image's
own 128MB, which the standalone StatefulSet does not override.
*/}}
{{- define "spatiumddi.postgresSharedBuffersMiB" -}}
{{- $sb := 128 -}}
{{- if eq (.Values.postgresql.kind | default "standalone") "cnpg" -}}
{{- $raw := toString ((.Values.postgresql.cnpg.parameters | default dict).shared_buffers | default "128MB") | trim -}}
{{- $n := regexFind "^[0-9]+" $raw | int -}}
{{- $unit := regexFind "[A-Za-z]+$" $raw -}}
{{- if eq $unit "kB" }}{{ $sb = div $n 1024 }}
{{- else if eq $unit "MB" }}{{ $sb = $n }}
{{- else if eq $unit "GB" }}{{ $sb = mul $n 1024 }}
{{- else if eq $unit "TB" }}{{ $sb = mul $n 1048576 }}
{{- else if eq $unit "" }}{{ $sb = div (mul $n 8) 1024 }}
{{- else }}{{ fail (printf "postgresql.cnpg.parameters.shared_buffers %q: use kB, MB, GB or TB" $raw) }}
{{- end -}}
{{- end -}}
{{- $sb -}}
{{- end }}

{{/*
#2955 — a Kubernetes memory quantity in MiB (rounded down), or -1 when it is
not one this helper reads (an exponent form, say), in which case the caller
leaves the operator's value alone.
*/}}
{{- define "spatiumddi.quantityMiB" -}}
{{- $q := toString . | trim -}}
{{- $n := regexFind "^[0-9]+" $q | int64 -}}
{{- $unit := trimPrefix (regexFind "^[0-9]+" $q) $q -}}
{{- $mib := -1 -}}
{{- if eq $unit "Ki" }}{{ $mib = div $n 1024 }}
{{- else if eq $unit "Mi" }}{{ $mib = $n }}
{{- else if eq $unit "Gi" }}{{ $mib = mul $n 1024 }}
{{- else if eq $unit "Ti" }}{{ $mib = mul $n 1048576 }}
{{- else if eq $unit "k" }}{{ $mib = div (mul $n 1000) 1048576 }}
{{- else if eq $unit "M" }}{{ $mib = div (mul $n 1000000) 1048576 }}
{{- else if eq $unit "G" }}{{ $mib = div (mul $n 1000000000) 1048576 }}
{{- else if eq $unit "" }}{{ $mib = div $n 1048576 }}
{{- end -}}
{{- $mib -}}
{{- end }}

{{/*
#2955 — ``postgresql.resources`` with the memory LIMIT raised, when needed, to
hold the connections the chart derived. Postgres' shared memory per slot is
small; what a limit has to carry is the backends themselves, ~14 MiB of
private memory each under load (measured, #2156, with transparent huge pages)
plus the page tables mapping shared_buffers (shared_buffers / 512). So the
limit is never below shared_buffers + 256 MiB + max_connections x
(14 + shared_buffers / 512) MiB: the rule the appliance's supervisor applies
(``k8s_api.control_plane_sizing``). Only RAISED, only when the chart derived
max_connections (an operator or the appliance that sets max_connections owns
the memory too), never added where no limit is set, and the request is left
alone (scheduling is unchanged: a limit is a ceiling, not a reservation).
Args: the root context.
*/}}
{{- define "spatiumddi.postgresResources" -}}
{{- $res := deepCopy (.Values.postgresql.resources | default dict) -}}
{{- $derived := false -}}
{{- if eq (.Values.postgresql.kind | default "standalone") "cnpg" -}}
{{- $derived = not (.Values.postgresql.cnpg.parameters | default dict).max_connections -}}
{{- else -}}
{{- $derived = not .Values.postgresql.maxConnections -}}
{{- end -}}
{{- $limits := $res.limits | default dict -}}
{{- if and $derived $limits.memory -}}
{{- $sb := include "spatiumddi.postgresSharedBuffersMiB" . | int -}}
{{- $conns := include "spatiumddi.postgresMaxConnections" . | int -}}
{{- $need := add $sb 256 (mul $conns (add 14 (div (add $sb 511) 512))) -}}
{{- $have := include "spatiumddi.quantityMiB" $limits.memory | int -}}
{{- if and (ge $have 0) (lt $have $need) -}}
{{- $_ := set $limits "memory" (printf "%dMi" $need) -}}
{{- $_ := set $res "limits" $limits -}}
{{- end -}}
{{- end -}}
{{- toYaml $res -}}
{{- end }}

{{/*
#3206 follow-up — refuse an in-place storageClass adoption on a live agent
StatefulSet with the fix in the message, instead of the API server's
"updates to statefulset spec for fields other than ... are forbidden".
volumeClaimTemplates are immutable, so setting dnsAgents/dhcpAgents
.storageClass (or servers[].storageClass) on an existing install can only be
applied after the StatefulSet is deleted with --cascade=orphan.

Takes (dict "root" $ "name" <statefulset name> "class" <class this render sets>).
Fires only when this render SETS a class and the live object has a claim
template whose class is absent or different. An install that never set a
class renders no storageClassName and never reaches the comparison. `lookup`
returns an empty map under `helm template` and in Argo CD's render, so this
only ever fires for a real `helm install/upgrade` against a cluster; those
render paths get the static NOTES.txt pointer instead. A storage SIZE change
is the same immutability but is not checked here: the API server normalises
quantities (1024Mi reads back as 1Gi), so a string compare could refuse a
render that changes nothing.
*/}}
{{- define "spatiumddi.checkAgentClaimClass" -}}
{{- if .class -}}
{{- $live := lookup "apps/v1" "StatefulSet" .root.Release.Namespace .name -}}
{{- range $t := (dig "spec" "volumeClaimTemplates" (list) $live) -}}
{{- $old := dig "spec" "storageClassName" "" $t -}}
{{- if ne $old $.class -}}
{{- fail (printf "StatefulSet %q has a %q claim template with storageClassName %s, and this render sets %q. Kubernetes forbids updating a StatefulSet's volumeClaimTemplates, so this upgrade would be refused. Delete the StatefulSet without deleting its pod or PVCs, then upgrade again:\n  kubectl delete sts %s -n %s --cascade=orphan\nExisting PVCs keep their old class; only new claims get %q. See the chart README, \"Adopting storageClass on an existing install\"." $.name (dig "metadata" "name" "?" $t) (ternary "unset" (quote $old) (eq $old "")) $.class $.name $.root.Release.Namespace $.class) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
#3852 — are we installing onto OpenShift?

``global.platform`` is ``auto`` (the default), ``kubernetes`` or ``openshift``.
``auto`` asks the cluster: OpenShift serves ``security.openshift.io/v1``
(SecurityContextConstraints), which no other distribution does. Without a
cluster — ``helm template``, Argo CD, a CI render — nothing answers, so those
pass ``--api-versions security.openshift.io/v1`` or set the value outright.

Renders ``true`` or nothing, so call sites read
``{{ if include "spatiumddi.isOpenShift" . }}``. Pass the ROOT context (``$``
inside a ``range``).

Everything OpenShift-specific hangs off this one answer, and every branch it
opens is additive or removes a pinned uid / gid / fsGroup: with it false the
render is byte-identical to a chart that never heard of OpenShift.
*/}}
{{- define "spatiumddi.isOpenShift" -}}
{{- $p := default "auto" (.Values.global).platform -}}
{{- if not (has $p (list "auto" "kubernetes" "openshift")) -}}
{{- fail (printf "global.platform=%q is not valid: use auto, kubernetes or openshift" $p) -}}
{{- end -}}
{{- if or (eq $p "openshift") (and (eq $p "auto") (.Capabilities.APIVersions.Has "security.openshift.io/v1")) -}}
true
{{- end -}}
{{- end -}}

{{/*
#3852 — the port the frontend's nginx listens on. :80 everywhere except
OpenShift, where the pod runs as a random unprivileged uid and cannot bind it.
The Service keeps its own port and reaches this one by the container port's
name (``http``), so nothing else has to know.
*/}}
{{- define "spatiumddi.frontendHttpPort" -}}
{{- if include "spatiumddi.isOpenShift" . -}}8080{{- else -}}80{{- end -}}
{{- end -}}

{{/*
#3852 — one SecurityContextConstraints + the Role / RoleBinding that lets a
fixed set of ServiceAccounts ``use`` it, and nobody else.

Args: ``root``, ``name`` (the SCC's name; also the Role / RoleBinding's),
``component``, ``serviceAccounts`` (list of names), ``capabilities`` (list),
``hostNetwork`` (bool), ``why`` (text, rendered as the SCC's description
annotation).

It is the ``restricted-v2`` SCC with exactly three differences, each of which
the workload needs and cannot get from any built-in SCC:

  * ``allowedCapabilities`` — the file capabilities on the daemon binaries
    (``named``, ``kea-dhcp4`` ...) only work when the capability is in the
    container's bounding set, so the pod has to be allowed to add it.
  * ``allowPrivilegeEscalation: true`` — the kernel ignores file capabilities
    for a process with ``no_new_privs`` set, and ``restricted-v2``'s ``false``
    sets it. The pod does not escalate to root: it stays a non-root uid.
  * ``allowHostNetwork`` / ``allowHostPorts`` — only when a server asks for
    ``hostNetwork: true``.

Everything else is kept at ``restricted-v2``'s values: a uid from the
namespace's range, an SELinux level from the namespace, an fsGroup from its
range, ``runtime/default`` seccomp, no privileged containers, and the
volume types the workload uses. ``anyuid`` is NOT a substitute: it has no
``seccompProfiles``, so it rejects every pod this chart gives a seccomp
profile.
*/}}
{{- define "spatiumddi.openshiftScc" -}}
{{- $root := .root -}}
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: {{ .name }}
  labels:
    {{- include "spatiumddi.componentLabels" (merge (dict "component" .component) $root) | nindent 4 }}
  annotations:
    kubernetes.io/description: {{ .why | quote }}
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: {{ .hostNetwork | default false }}
allowHostPID: false
allowHostPorts: {{ .hostNetwork | default false }}
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities:
  {{- range .capabilities }}
  - {{ . }}
  {{- end }}
defaultAddCapabilities: null
requiredDropCapabilities:
  - ALL
readOnlyRootFilesystem: false
fsGroup:
  type: MustRunAs
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: MustRunAs
seccompProfiles:
  - runtime/default
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - ephemeral
  - persistentVolumeClaim
  - projected
  - secret
users: []
groups: []
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ .name }}-scc
  namespace: {{ $root.Release.Namespace }}
  labels:
    {{- include "spatiumddi.componentLabels" (merge (dict "component" .component) $root) | nindent 4 }}
rules:
  - apiGroups: ["security.openshift.io"]
    resources: ["securitycontextconstraints"]
    resourceNames: [{{ .name | quote }}]
    verbs: ["use"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ .name }}-scc
  namespace: {{ $root.Release.Namespace }}
  labels:
    {{- include "spatiumddi.componentLabels" (merge (dict "component" .component) $root) | nindent 4 }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ .name }}-scc
subjects:
  {{- range .serviceAccounts }}
  - kind: ServiceAccount
    name: {{ . }}
    namespace: {{ $root.Release.Namespace }}
  {{- end }}
{{- end -}}
