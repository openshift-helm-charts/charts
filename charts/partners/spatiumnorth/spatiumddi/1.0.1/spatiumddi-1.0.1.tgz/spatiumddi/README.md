# SpatiumDDI Helm chart

Umbrella chart that deploys the full SpatiumDDI control plane (API +
frontend + Celery worker + Celery beat + migrate Job) plus PostgreSQL
and Redis via Bitnami subcharts, with optional DNS and DHCP agent
StatefulSets.

- **Chart type:** application
- **Registry:** `oci://ghcr.io/spatiumnorth/charts/spatiumddi`
- **Versioning:** Each SpatiumDDI release tag publishes a chart version.
  A CalVer tag (`YYYY.MM.DD-N`, up to the bridge release) has its
  leading zeroes stripped so it's a valid SemVer 2 identifier — e.g. tag
  `2026.04.20-1` → chart version `2026.4.20-1`. A SemVer tag (from
  1.0.0) is the chart version unchanged. Every CalVer chart is a SemVer
  pre-release, so Helm finds it only with an explicit `--version`.

## TL;DR

```bash
helm install ddi oci://ghcr.io/spatiumnorth/charts/spatiumddi \
  --version 2026.4.20-1 \
  --namespace spatiumddi --create-namespace
```

> **Chart versions up to and including `2026.9.4-1` default to the old
> image path.** They were published before the project moved to the
> `spatiumnorth` organization (#1100), so their values name
> `ghcr.io/spatiumddi/*`, which now answers `denied`. The same image tags
> are published under `ghcr.io/spatiumnorth/`; add these to install or
> upgrade one of those versions:
>
> ```bash
>   --set image.repository=spatiumnorth \
>   --set dnsAgents.image.repository=ghcr.io/spatiumnorth/dns-bind9 \
>   --set dnsAgents.flavors.powerdns.repository=ghcr.io/spatiumnorth/dns-powerdns \
>   --set dnsAgents.flavors.technitium.repository=ghcr.io/spatiumnorth/dns-technitium \
>   --set dhcpAgents.image.repository=ghcr.io/spatiumnorth/dhcp-kea
> ```

Default login: **`admin` / `admin`** (forced password change on first login).

## Prerequisites

- Kubernetes 1.31+
- Helm 3.8+ (needed for OCI)
- A StorageClass supporting `ReadWriteOnce` (Postgres, Redis, and
  agent state all use PVCs)
- Ingress controller or LoadBalancer for external access (optional)

## Install

```bash
# Default install — all-in-one with bundled Postgres + Redis
helm install ddi oci://ghcr.io/spatiumnorth/charts/spatiumddi \
  --version <CHART_VERSION> \
  --namespace spatiumddi --create-namespace
```

### Exposing the UI

```yaml
# values.yaml
ingress:
  enabled: true
  className: nginx
  hosts:
    - host: ddi.example.com
      paths:
        - { path: /, pathType: Prefix }
  tls:
    - secretName: ddi-tls
      hosts: [ddi.example.com]
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
```

Behind an Ingress, also set `frontend.trustedProxyCidrs` to the ingress
controller's pod network (so the login throttle and audit log see the real
client, and the api sees `https`) and turn off response buffering for the
streaming endpoints (`nginx.ingress.kubernetes.io/proxy-buffering: "off"`,
`proxy-read-timeout: "3600"`). See
[`docs/deployment/REVERSE_PROXY.md`](../../docs/deployment/REVERSE_PROXY.md).

Or, without an Ingress, flip the frontend service to `LoadBalancer`:

```yaml
frontend:
  service:
    type: LoadBalancer
```

The frontend Pod's embedded nginx proxies `/api/` (plus `/health` and
`/metrics`) to the api Service — same shape as Docker Compose. `/metrics`
answers only a bearer token: the scrape token the chart generates into its
app Secret as `metrics-token`, or any API token (#1159). The
upstream host + port come from values; the cluster DNS resolver is
auto-detected from `/etc/resolv.conf` at container start. Defaults
work out of the box (`{{ fullname }}-api` on `api.service.port`).

Override only for non-default topologies — separate namespace, custom
api Service name, pinned external resolver:

```yaml
frontend:
  apiUpstream:
    host: my-api.shared-ns.svc.cluster.local
    port: 8000
  nginxLocalResolvers: "10.96.0.10"   # optional; auto-detected if empty
```

If you'd rather skip the frontend's proxy and split routing at the
ingress controller (`/` → frontend, `/api/` → api Service), the
existing `ingress.hosts[].paths` list accepts both — just declare the
`/api/` path with a manual `backend.service.name = "<release>-api"`
override via a strategic-merge patch or a separate Ingress.

### Using an external Postgres

Point the chart at an existing database and skip the bundled subchart:

```yaml
postgresql:
  enabled: false

externalDatabase:
  host: pg.internal
  port: 5432
  username: spatiumddi
  database: spatiumddi
  existingSecret: my-db-secret       # must carry key `password`
  existingSecretPasswordKey: password
```

### Using an external Redis

```yaml
redis:
  enabled: false

externalRedis:
  host: redis.internal
  port: 6379
  existingSecret: my-redis-secret    # optional; remove for unauth'd redis
```

### Exposing DNS and DHCP to clients

The DNS and DHCP agent Services are `ClusterIP` unless a server sets
`service.type`. A `ClusterIP` Service is reachable from inside the cluster
only, which is enough for the control plane but not for clients on your LAN.

Do not point a default k3s at `type: LoadBalancer` for port 53. k3s ships
**servicelb** (klipper-lb), which runs an `svclb-*` pod with `hostPort: 53`
on every node. The CNI hostPort DNAT then also captures the node's own
resolver stub at `127.0.0.53:53`, so the node stops resolving: image pulls
fail with `lookup ghcr.io: Try again`, the `svclb` image itself cannot pull,
local-path provisioning times out, and the install never converges (#3229).
UDP 67 for DHCP uses the same hostPort mechanism.

Pick one of these instead:

- **MetalLB** (or a cloud load balancer). Install MetalLB, start k3s with
  `--disable servicelb` so the two do not both claim the Service, and set
  `service: { type: LoadBalancer }` with the pool / address annotations shown
  in `values.yaml`. MetalLB announces a dedicated VIP, so nothing binds :53 on
  the node. The DNS Service takes `service.annotations`,
  `service.loadBalancerIP`, `service.loadBalancerSourceRanges`,
  `service.externalTrafficPolicy` (default `Local` on a LoadBalancer),
  `service.ipFamilyPolicy` and `service.ipFamilies`; the DHCP Service takes
  `service.type` and `service.nodePort` only.
- **Another LoadBalancer implementation** with `--disable servicelb` (kube-vip,
  Cilium LB-IPAM, ...). The same rule applies: whatever implements the
  Service must not use hostPort 53.
- **`NodePort`**, for a resolver you reach through a forwarder or an external
  load balancer. Port 53 is not in the NodePort range, so clients cannot use
  it directly.
- **`hostNetwork`** (DHCP only in this chart). It binds the node's own port, so
  never run it on a node where something else, such as `systemd-resolved`, owns
  that port. DNS agents do not offer it here for exactly that reason.

On a node where only the resolver stub is the problem, never expose :53 with
servicelb; if you already did, delete the Service and the `svclb-*` DaemonSet,
then `iptables -t nat -S CNI-HOSTPORT-DNAT | grep 'dports 53'` should come back
empty.

A `LoadBalancer` Service is enough for DNS. It is not enough for DHCP: client
broadcasts do not reach a pod behind a Service, so DHCP needs a relay pointed
at the Service address, or `hostNetwork`. Ports and protocols, a values
example for each, and how to check the result are in the deployment guide:
[Exposing DNS to clients](https://github.com/spatiumnorth/spatiumddi/blob/main/docs/deployment/KUBERNETES.md#exposing-dns-to-clients)
and
[Exposing DHCP to clients](https://github.com/spatiumnorth/spatiumddi/blob/main/docs/deployment/KUBERNETES.md#exposing-dhcp-to-clients).

### Running managed DNS agents

```yaml
dnsAgents:
  enabled: true
  agentKey:
    existingSecret: spatium-dns-agent-key   # must carry key DNS_AGENT_KEY
  servers:
    # BIND9 (default flavor — RPZ blocklists, full views support)
    - name: ns1
      role: primary
      group: internal-resolvers
      service: { type: LoadBalancer }   # opt-in, see "Exposing DNS and DHCP to clients"
    - name: ns2
      role: secondary
      group: internal-resolvers
      service: { type: LoadBalancer }   # opt-in, see "Exposing DNS and DHCP to clients"
    # PowerDNS (issue #127 — online DNSSEC, ALIAS, LUA, catalog zones).
    # Lives in its own group so PowerDNS-only features can engage; the
    # control plane rejects mixed-driver groups for those features.
    - name: pdns1
      flavor: powerdns
      role: primary
      group: powerdns-edge
      service: { type: LoadBalancer }   # opt-in, see "Exposing DNS and DHCP to clients"
    # Technitium (third DNS driver — native DoT/DoH/DoQ listeners plus
    # encrypted upstream forwarding with no dnsdist-style sidecar; no
    # DNSSEC or catalog zones in 1.0). Own group, same rule.
    - name: tdx1
      flavor: technitium
      role: primary
      group: technitium-edge
      service: { type: LoadBalancer }   # opt-in, see "Exposing DNS and DHCP to clients"
```

The agent Services default to `ClusterIP` (#3229). The `LoadBalancer` lines
above are opt-in and need a load balancer that does not bind port 53 on the
node itself; read [Exposing DNS and DHCP to clients](#exposing-dns-and-dhcp-to-clients)
before copying them onto k3s.

Each server picks its image from `dnsAgents.image` (default,
configures BIND9) or `dnsAgents.flavors.<flavor>` per-driver
override (`powerdns` and `technitium` are both pre-set out of the
box). The `dns-state` volume mounts under `/var/cache/bind` for
BIND9, `/var/lib/powerdns` for PowerDNS LMDB, and `/etc/dns` for
Technitium's own config + zone store — same volume claim, the
template picks the path based on `flavor`.

Pre-create the PSK secret (or use `agentKey.value` inline for lab use only):

```bash
kubectl -n spatiumddi create secret generic spatium-dns-agent-key \
  --from-literal=DNS_AGENT_KEY="$(openssl rand -hex 32)"
```

### Running managed DHCP agents

Same shape as DNS but `SPATIUM_AGENT_KEY`:

```yaml
dhcpAgents:
  enabled: true
  agentKey:
    existingSecret: spatium-dhcp-agent-key  # must carry key SPATIUM_AGENT_KEY
  servers:
    - name: dhcp1
      role: primary
      # Behind a DHCP relay (ip helper-address pointed at the Service):
      service: { type: LoadBalancer }
      # Or, on a node attached to the client VLAN, with no relay:
      # hostNetwork: true
```

Pick one of the two; see
[Exposing DHCP to clients](https://github.com/spatiumnorth/spatiumddi/blob/main/docs/deployment/KUBERNETES.md#exposing-dhcp-to-clients).

### GitOps with `helm template` (Argo CD)

Controllers that render the chart with `helm template` instead of
installing it, such as Argo CD, need two adjustments. Flux's
`HelmRelease` performs a real Helm install, so it needs neither.

**The migrate Job.** Its name carries `.Release.Revision` so each
`helm upgrade` creates a fresh Job, since a Job's pod template is
immutable. Under `helm template` the revision is always `1`, so the Job is
`<release>-migrate-r1` on every sync, and the first image bump fails with
`spec.template: field is immutable` until the old Job is deleted by hand.
Make it a sync hook instead, so it is deleted and recreated on every sync:

```yaml
migrate:
  annotations:
    argocd.argoproj.io/hook: Sync
    argocd.argoproj.io/hook-delete-policy: BeforeHookCreation
```

Alembic is idempotent, so re-running it on every sync is safe, and a hook
no longer counts towards the application's sync status. Plain
`helm install` / `helm upgrade` ignore these annotations.

**Generated secrets.** The chart generates its secrets on first install
and keeps them across upgrades with `lookup()`. `helm template` has no
cluster to look in, so `lookup()` returns nothing and every render
generates new values. The controller then sees a changed Secret on every
sync, and applying it rotates the application key and database password
under a running install. Pre-create the secrets and point the chart at
them:

| Value | Secret must carry |
|-------|-------------------|
| `auth.existingSecret` | `secret-key` (and optionally `metrics-token`) |
| `postgresql.auth.existingSecret` | `password`. With `postgresql.kind: cnpg`, the Secret must be type `kubernetes.io/basic-auth` with both `username` and `password`, because CNPG bootstraps the database user from it |
| `redis.auth.existingSecret` | `redis-password` (only when `redis.auth.enabled=true`) |
| `dnsAgents.agentKey.existingSecret` | `DNS_AGENT_KEY` (when `dnsAgents.enabled`) |
| `dhcpAgents.agentKey.existingSecret` | `SPATIUM_AGENT_KEY` (when `dhcpAgents.enabled`) |

## Values reference

### Top-level

| Key | Default | Description |
|-----|---------|-------------|
| `image.registry` | `ghcr.io` | Image registry for control-plane images |
| `image.repository` | `spatiumddi` | Repo prefix (images are `<registry>/<repo>/<name>`) |
| `image.tag` | `""` → `Chart.appVersion` | Control-plane image tag |
| `image.pullPolicy` | `IfNotPresent` |  |
| `image.pullSecrets` | `[]` |  |
| `auth.secretKey` | `""` | Fernet key; auto-generated on first install if empty |
| `auth.existingSecret` | `""` | BYO secret with key `secret-key` |
| `fullnameOverride` | `""` |  |
| `nameOverride` | `""` |  |
| `global.controlPlaneNodeSelector` | `{}` | Merged into every control-plane workload's `nodeSelector` |
| `global.seccompProfile` | `RuntimeDefault` | Pod-level seccomp for every workload. `Unconfined` or `""` (omit) also accepted; `Localhost` is rejected |
| `global.priorityClassName` | `""` | PriorityClass for the control-plane workloads. **Leave empty unless the class exists** — the apiserver refuses a pod naming one that does not |
| `global.servicePriorityClassName` | `""` | Same, for the DNS / DHCP agent StatefulSets |
| `<component>.priorityClassName` | unset | Per-workload override. Unset inherits the chart-wide key above; `""` means *no class for this workload*, even when the chart-wide key is set |
| `<component>.hostUsers` | unset | #983 — `false` runs the pod in a user namespace (K8s 1.36+). Refused on `api`/`worker` while `api.applianceHostMounts.enabled` is on |
| `api.topologySpreadConstraints` / `worker.…` | `[]` | #983 — replaces the default `maxSkew: 1` spread rendered in `soft` anti-affinity mode |
| `api.upgradeOrchestratorRBAC.kubeletProxyFallback` | `true` | #983 — also grant the broad `nodes/proxy` read as a fallback transport, on both api and worker. Set false once Cluster → Overview's `kubelet:` chip is green (every node direct) |
| `api.kubeletCA.enabled` / `.hostPath` / `.mountPath` | `false` | #983 — mount the CA that signs kubelet *serving* certs (k3s signs them with its own `server-ca`, not the ServiceAccount CA) and set `SPATIUM_KUBELET_CA_PATH` from it. Needed only if a node reports a CA failure |
| `worker.serviceAccount.enabled` | `false` | #983 — mount a narrow ServiceAccount (`nodes` read + `nodes/stats`) on the worker. **Required for the `node_pressure` PSI alert**: alert evaluation runs in the worker, not the api |

### Control plane

| Key | Default | Description |
|-----|---------|-------------|
| `api.replicas` | `2` | The api's count while `api.autoscaling.enabled` is `false`. With the autoscaler on (the default) the chart renders no count and the HPA alone sets it (#3111) |
| `api.service.type` | `ClusterIP` |  |
| `api.service.port` | `8000` |  |
| `api.service.trafficDistribution` | `""` | #1805 — `""` renders no field (kube-proxy spreads every caller over every api pod). `PreferSameNode` keeps each node's in-cluster callers (the supervisor, the DNS/DHCP agents, the frontend's `/api` proxy) on the api pod on their own node while it is ready, so a lost node's api pod cannot hold their requests. The appliance sets it (firstboot's `spatium-control` values and the supervisor's HelmChartConfig), where every control-plane node runs one api pod. Elsewhere it pins a node's callers to the one api pod on that node, which can leave the others idle and the HPA reacting late. Rendered on Kubernetes 1.34+ |
| `api.service.nodeLocal` | `false` | #3645 — `true` adds a second Service, `<release>-api-local`, with `internalTrafficPolicy: Local` (answers only from an api pod on the caller's node) for the member supervisors' heartbeat, so that plain-http hop never crosses the node LAN (a supervisor with no ready api pod on its node falls back to its pinned https URL, or the cluster Service when it has none, as the seed does). The frontend keeps the cluster `-api` Service, so a node whose api pod is down or rolling still serves the UI. Appliance only: firstboot and the supervisor set it |
| `api.autoscaling.enabled` | `true` | HPA on CPU (memory is opt-in). It needs a metrics-server; without one it holds the api at `minReplicas` |
| `api.autoscaling.minReplicas` / `maxReplicas` | `2` / `10` |  |
| `api.autoscaling.targetCPUUtilizationPercentage` | `70` | #3110 — of the api's CPU request (200m), so 140m a pod. Each of two api pods used about 100m under light load |
| `api.autoscaling.targetMemoryUtilizationPercentage` | unset | #3110 — memory is opt-in. An api process holds about 300 MiB from the moment it starts, and that does not fall as replicas are added, so a target below it holds the HPA at `maxReplicas`. If you set one, use 73 or more with the default 512Mi request |
| `api.resources` | requests `200m` / `512Mi`, limits `1000m` / `1Gi` | #3110 — the api's measured use, see `values.yaml`. The appliance sets its own limits from the node's RAM |
| `api.probes.liveness.{initialDelaySeconds,periodSeconds,timeoutSeconds,failureThreshold}` | `10` / `30` / `30` / `4` | #1051 — `/health/live` budgets, sized for a busy single-worker loop: four 30 s misses restart a process that has said nothing for two minutes |
| `api.probes.readiness.{initialDelaySeconds,periodSeconds,timeoutSeconds,failureThreshold}` | `5` / `10` / `15` / `3` | #1051 — `/health/ready` budgets; the timeout exceeds the handler's own bounded worst case (4 s db + 4 s schema + 2 s redis) so the kubelet sees the 503 naming the failing check instead of a bare deadline |
| `api.serviceControl.enabled` | `false` | Sets `SERVICE_CONTROL_ENABLED` on the api — what the Services screen's capability probe reports |
| `api.serviceControlRBAC.enabled` | `false` | Grants the api ServiceAccount `list` + `patch` on Deployments / StatefulSets / DaemonSets, and `delete` on pods (Cluster → Pods Restart, #4232). Needs `serviceAccount.enabled` |
| `frontend.replicas` | `2` |  |
| `frontend.service.type` / `.port` | `ClusterIP` / `80` |  |
| `frontend.apiUpstream.host` | `""` (→ `{{ fullname }}-api`) | nginx-proxy target Service name |
| `frontend.apiUpstream.port` | `0` (→ `api.service.port`) | nginx-proxy target port |
| `frontend.nginxLocalResolvers` | `""` (auto-detect) | DNS resolver IPs for nginx |
| `worker.replicas` | `2` |  |
| `worker.concurrency` | `4` |  |
| `worker.queues` | `"ipam,dns,dhcp,default,bundles"` |  |
| `worker.resources` | requests `200m` / `256Mi`, limits `2000m` / `2Gi` | #3110 — the worker's memory grows for about its first hour and levels off near 1 GiB. The appliance sets its own limit from the node's RAM |
| `beat.*` | see values.yaml | Singleton scheduler |
| `migrate.enabled` | `true` | Alembic Job, a regular Job named per revision (`<release>-migrate-r<revision>`), not a Helm hook |
| `migrate.annotations` | `{}` | Annotations on the Job object (not its pod). For GitOps, see below |
| `migrate.nodeSelector` / `.tolerations` / `.affinity` | unset (follows `api.*`) | #3207 — placement of the migrate Job's pod. Unset runs it where the api runs: `api.nodeSelector`, `api.tolerations` and `api.affinity.nodeAffinity` (not the api's pod anti-affinity, which would keep the Job off the api's nodes), with `global.controlPlaneNodeSelector` merged into the selector. `{}` / `[]` opt out of the api's values |
| `initContainers.resources` | requests `10m` / `32Mi`, limit `256Mi` memory | #3208 — resources of every `wait-for-postgres` / `wait-for-migrate` init container |
| `postgresql.cnpg.enablePDB` | unset (auto) | #3204 — `kind: cnpg`. Unset enables the primary PodDisruptionBudget only when `instances > 1`, so a single instance can be drained; an explicit `true` / `false` wins |
| `postgresql.affinity.nodeAffinity` | `{}` | #3205 — `kind: cnpg`: rendered into the Cluster's `spec.affinity.nodeAffinity` (prefer a node without hard-pinning it with `nodeSelector`). Standalone: `postgresql.affinity` is the pod's whole affinity |
| `ingress.*` | disabled |  |

### Dependencies

The `postgresql` and `redis` keys are passed through to the Bitnami
subcharts verbatim — any option those charts accept works here. See:

- https://github.com/bitnami/charts/tree/main/bitnami/postgresql
- https://github.com/bitnami/charts/tree/main/bitnami/redis

### Agents

| Key | Default | Description |
|-----|---------|-------------|
| `dnsAgents.enabled` | `false` |  |
| `dnsAgents.image.repository` | `ghcr.io/spatiumnorth/dns-bind9` | Default image (BIND9 flavor) |
| `dnsAgents.flavors.powerdns.repository` | `ghcr.io/spatiumnorth/dns-powerdns` | Per-flavor image override (issue #127) |
| `dnsAgents.flavors.technitium.repository` | `ghcr.io/spatiumnorth/dns-technitium` | Per-flavor image override |
| `dnsAgents.agentKey.existingSecret` | `""` | Carries `DNS_AGENT_KEY` (shared between flavors) |
| `dnsAgents.prefixWithFullname` | `false` | #3209 — name the StatefulSet and Services `<fullname>-dns-<flavor>-<name>` instead of `dns-<flavor>-<name>`. Flipping it on a live install recreates the StatefulSet with new PVCs; see [upgrade note](#agent-object-names-3209) |
| `dnsAgents.storageClass` | `""` | #3206 — StorageClass of both claims (`agent-state`, `dns-state`); unset = cluster default. Per server: `servers[].storageClass`. Setting it on an existing install needs a one-off step: [see below](#adopting-storageclass-on-an-existing-install) |
| `dnsAgents.servers` | `[]` | One entry → one StatefulSet + Services. `flavor: bind9` (default), `powerdns`, or `technitium` |
| `dhcpAgents.enabled` | `false` |  |
| `dhcpAgents.image.repository` | `ghcr.io/spatiumnorth/dhcp-kea` |  |
| `dhcpAgents.agentKey.existingSecret` | `""` | Carries `SPATIUM_AGENT_KEY` |
| `dhcpAgents.prefixWithFullname` | `false` | #3209 — as `dnsAgents.prefixWithFullname`, for the DHCP StatefulSet and Services |
| `dhcpAgents.upgradeUnstickPods` | `true` | #3907 — a `pre-upgrade` hook deletes a DHCP agent StatefulSet (PVCs kept) holding a pod that is Running but not Ready for 2+ minutes, so Helm recreates it from the new template (needed coming from `2026.10.02-1` or older). Ready pods are never touched; `false` turns the hook off |
| `dhcpAgents.storageClass` | `""` | #3206 — StorageClass of both claims; per server: `servers[].storageClass`. Setting it on an existing install needs a one-off step: [see below](#adopting-storageclass-on-an-existing-install) |
| `dhcpAgents.servers` | `[]` |  |

Each server entry accepts `name`, `role`, `group`, `storage.agentState`,
`storage.dnsState` (or `storage.keaState`), `service.type`,
`service.annotations` / `service.loadBalancerIP` /
`service.loadBalancerSourceRanges` / `service.externalTrafficPolicy` /
`service.ipFamilyPolicy` / `service.ipFamilies` (DNS only),
`dotPort` / `dohPort` / `doqPort` (DNS only; `doqPort` on `technitium` only),
`service.nodePort` (DHCP only; pins the node-facing port of a NodePort
DHCP Service, which is otherwise random. Only useful for a relay that can
forward to a non-standard port: most, including `ip helper-address`, send
to UDP/67 only, so use LoadBalancer or `hostNetwork` for those; setting it
without `service.type` implies `NodePort`),
`hostNetwork` (DHCP only), `resources`, `storageClass` (on an existing install, [read this first](#adopting-storageclass-on-an-existing-install)), `nodeSelector`,
`tolerations` and `affinity` (#3206: merged with the chart's preferred
one-agent-per-node anti-affinity; only a `podAntiAffinity` of your own
replaces it). Agents only *prefer* separate nodes,
so after a node drain an agent can reschedule next to another one and stay
there. Pin each server to a node (`nodeSelector: { kubernetes.io/hostname:
node-a }`) to keep one agent per node behind a shared address.

### Adopting `storageClass` on an existing install

Setting `dnsAgents.storageClass`, `dhcpAgents.storageClass` or a server's
`storageClass` (#3206) on a release that is already running changes the agent
StatefulSet's `spec.volumeClaimTemplates[].spec.storageClassName`. Kubernetes
does not allow that: only `replicas`, `ordinals`, `template`, `updateStrategy`,
`revisionHistoryLimit`, `persistentVolumeClaimRetentionPolicy` and
`minReadySeconds` of a StatefulSet can be updated. The upgrade or sync is
refused with `StatefulSet.apps "<name>" is invalid: spec: Forbidden: updates to
statefulset spec for fields other than ... are forbidden`. This happens even
when the class you set is the cluster default. Changing a claim's storage size
(`servers[].storage.*`) is refused for the same reason.

Delete the StatefulSet object **without** its pod or PVCs, then upgrade or sync
again; the new StatefulSet adopts the running pod and the existing claims:

```bash
kubectl delete sts <name> -n <namespace> --cascade=orphan
helm upgrade ddi oci://ghcr.io/spatiumnorth/charts/spatiumddi --reuse-values ...   # your usual command
```

With Argo CD, run the same `kubectl delete sts ... --cascade=orphan`, then sync
the application. `Replace=true` and `ServerSideApply=true` do not help: the
field is immutable either way.

On a real `helm install` / `helm upgrade` against a cluster, the chart looks up
the live StatefulSet and stops with a message carrying this exact command
before sending anything. `helm template` and Argo CD render without cluster
access, so they cannot detect it; they print a note in `NOTES.txt` instead.

This does not move any data. Existing PVCs keep the class they were created
with; only claims created afterwards (a new replica, a new server) get the new
class. Moving an agent's data to another class needs new claims and a copy of the
data, which this procedure does not do.

### Agent object names (#3209)

The DNS and DHCP agent StatefulSet, Service and headless Service are named
`dns-<flavor>-<name>` / `dhcp-<flavor>-<name>` by default, without the release
fullname every other object carries, so two releases in one namespace collide.
`dnsAgents.prefixWithFullname` / `dhcpAgents.prefixWithFullname` (default
`false`) name them `<fullname>-dns-<flavor>-<name>` instead (`fullnameOverride`
applies). A name longer than 52 characters keeps its first 43 and gains a
hash of the full name (`-1a2b3c4d`), so servers whose names differ only past
the cut stay distinct. The render fails if two servers would still share a
name, or if the release name (or `fullnameOverride`) does not start with a
lowercase letter, which a Service name needs. The default is expected to flip
in a later release.

Do not flip it on a live install casually. A StatefulSet cannot be renamed:
Helm deletes the old one and creates a new one with **new PVCs**
(`<claim>-<new name>-0`) and a new pod name, which is the server's registered
identity, so the agent registers as a new server (the old row stays until you
delete it, and the agent's local state starts empty). To keep the data, leave
it `false`. For a new install, or one you are happy to rebuild, set it `true`
from the start.

## Upgrade

```bash
helm upgrade ddi oci://ghcr.io/spatiumnorth/charts/spatiumddi \
  --version <NEW_CHART_VERSION> \
  --namespace spatiumddi --reuse-values
```

**DNS / DHCP agent Service default changed to `ClusterIP` (#3229).** Earlier
chart versions rendered a `LoadBalancer` Service for an agent server that set
no `service.type`. An upgrade with `--reuse-values` keeps your values, so a
server that never set the type now renders `ClusterIP`: Kubernetes changes the
type in place and **releases the external IP clients use**. Before upgrading,
list what you have (`kubectl -n spatiumddi get svc -l
app.kubernetes.io/component=dns-agent`) and add `service: { type:
LoadBalancer }` to every server that must keep its address, keeping the same
`loadBalancerIP` or MetalLB annotation. Servers that already set a type are
unchanged.

The migrate Job is a regular Job named per revision, not a Helm hook. Each
upgrade creates a new one, and the api, worker and beat pods wait for the
schema in their `wait-for-migrate` init containers, so Alembic applies
before the new pods start serving. Under `helm template` (GitOps), see
[GitOps with `helm template`](#gitops-with-helm-template-argo-cd).

### Taking a new chart's defaults (#3110)

`--reuse-values` keeps every value of the release it upgrades, including
the defaults of the chart it was installed from. To take this chart's api
sizing and autoscaler defaults (#3110), upgrade once with
`--reset-then-reuse-values` (Helm 3.14 or later). It starts from this
chart's defaults and keeps the values you set:

```bash
helm upgrade ddi oci://ghcr.io/spatiumnorth/charts/spatiumddi \
  --version <NEW_CHART_VERSION> \
  --namespace spatiumddi --reset-then-reuse-values
```

### The api's replica count under the autoscaler (#3111)

While the autoscaler is on, the chart renders no replica count for the api.
The HPA alone sets the count, and an upgrade keeps it (#3111). Before this,
once the HPA had scaled, every Helm 4 upgrade failed with `conflict with
"kube-controller-manager" with subresource "scale" using apps/v1:
.spec.replicas` (the manager is `k3s` on k3s), and every Helm 3 upgrade put
the count back to `api.replicas`. The first upgrade to this chart goes one
of three ways:

- **The HPA has scaled the api at some point**, so it owns the count. The
  upgrade succeeds without `--force-conflicts` and keeps the count.
- **The HPA never has** (no metrics-server, say), so Helm owns the count.
  Dropping it from the chart sets it to 1 for a moment: one api pod stops,
  and the HPA restores `minReplicas` at its next sync (15 s by default). To
  avoid that, first hand the count to another field manager at its current
  value (the Deployment is `<release>-spatiumddi-api`):

  ```bash
  kubectl -n spatiumddi apply --server-side --field-manager=handover-to-hpa \
    --validate=false -f - <<'EOF'
  apiVersion: apps/v1
  kind: Deployment
  metadata:
    name: ddi-spatiumddi-api
  spec:
    replicas: 2
  EOF
  ```

- **Client-side apply** (Helm 3, or a release Helm 4 installed with
  `--server-side=false`). This upgrade sets the count to 1 once, as each
  earlier upgrade set it to `api.replicas`. The HPA restores `minReplicas`
  at once and its own count within a minute, and later upgrades keep it.

Turning the autoscaler off later (`api.autoscaling.enabled: false`) hands the
count back to Helm. On a release whose count the HPA took over from an older
chart, that one upgrade conflicts on `.spec.replicas` under Helm 4 while the
count differs from `api.replicas`, so run it with `--force-conflicts`.

### Sentinel ghost entries clear themselves on upgrade

Chart versions before the #590 fix let every Redis pod announce itself to
its peers by its **pod IP**. A pod that gets rescheduled (node loss, drain,
OS upgrade) returns with a new IP and a new run id, so the surviving
sentinels record a *second* entry for it and keep the old one as `s_down`
forever — Sentinel never forgets a Sentinel it has seen.

That is not cosmetic. Sentinel authorizes a failover only with a majority
of **all known** sentinels, and dead ghosts sit in the denominator without
ever voting. With three live pods, the third accumulated ghost makes
failover arithmetically impossible (6 known, 4 needed, 3 usable): the
master is stranded, `sentinel://` clients never resolve a new one, and the
API stays down. Each node loss contributes one ghost.

This release pins `replica-announce-ip` / `sentinel announce-ip` to each
pod's stable StatefulSet FQDN, so a returning pod replaces its own entry
instead of adding one.

**No manual step is needed.** The init container rewrites `sentinel.conf`
on every pod start, so the rolling update discards the accumulated ghosts
along with the rest of each sentinel's learned state. To confirm afterwards
(`usable` should equal your replica count, and no `s_down` rows):

```bash
kubectl -n spatiumddi exec <release>-redis-0 -c sentinel -- \
  redis-cli -p 26379 sentinel ckquorum mymaster
kubectl -n spatiumddi exec <release>-redis-0 -c sentinel -- \
  redis-cli -p 26379 sentinel sentinels mymaster | grep -A1 flags
```

On a cluster you cannot roll yet, `SENTINEL RESET *` on each sentinel
clears the ghosts immediately without restarting anything.

### One-time step when upgrading a Sentinel Redis whose replicas were co-located

Chart versions before the #590 fix used best-effort (`preferred`) pod
anti-affinity on the Sentinel Redis StatefulSet, so two replicas could
land on the same node — and `persistence.enabled` then pinned each
replica's `ReadWriteOnce` local PV to whichever node it first scheduled
on. This release makes the anti-affinity **required**, which is what
makes a single node loss survivable. A replica whose PV is stranded on a
node that already hosts another replica cannot schedule, and will sit
`Pending` after the rolling update.

Check for it, and repair by deleting the stranded PVC so it
re-provisions on a free node (Redis here is cache + Celery broker;
Postgres is the store of record, so the data is expendable and the
replica resyncs from the master):

```bash
kubectl -n spatiumddi get pods -l app.kubernetes.io/component=redis \
  -o wide                                    # any Pending, and where?
kubectl -n spatiumddi delete pvc data-<release>-redis-<ordinal>
kubectl -n spatiumddi delete pod <release>-redis-<ordinal>
```

Clusters whose replicas were already spread one-per-node upgrade with no
action. This does not apply to `redis.kind: standalone`.

### The same step for CloudNativePG, if you set `podAntiAffinityType: required`

CNPG has the identical hazard, and the repair is the same shape — but
Postgres is not expendable, so the rule is stricter.

`postgresql.cnpg.podAntiAffinityType` defaults to `preferred` in this chart
(the appliance renders `required`). Flipping an **existing** cluster to
`required` can strand an instance whose PVC is already bound to a node that
now hosts another instance. It goes `Pending`.

Postgres stays available while you fix it: the primary is untouched, and a
surviving replica keeps failover possible.

> **Only ever delete a REPLICA's PVC. Never the primary's.** Deleting the
> primary's PVC destroys the database. Confirm the role before you touch
> anything — CNPG labels the primary `cnpg.io/instanceRole=primary`.

```bash
# Which instance is Pending, and which one is the primary?
kubectl -n spatiumddi get pods -l cnpg.io/cluster=<cluster> \
  -L cnpg.io/instanceRole -o wide

# Confirm the Pending pod is NOT the primary, then drop its PVC.
# CNPG re-clones the replica from the primary (pg_basebackup).
kubectl -n spatiumddi delete pvc <cluster>-<ordinal>
kubectl -n spatiumddi delete pod <cluster>-<ordinal>
```

If the stranded instance *is* the primary, don't delete anything: run a
switchover first (`kubectl cnpg promote <cluster> <other-instance>`), wait
for the role to move, then repair it as a replica.

## Uninstall

```bash
helm uninstall ddi --namespace spatiumddi
```

PVCs for Postgres, Redis, and agent state are **not** deleted
automatically — remove them manually if you want a clean slate:

```bash
kubectl -n spatiumddi delete pvc -l app.kubernetes.io/instance=ddi
```

## Troubleshooting

- **API pods CrashLoopBackOff on first install:** the migrate Job
  probably hasn't finished. `kubectl -n spatiumddi logs job/ddi-spatiumddi-migrate`.
- **`secret-key` rotated unexpectedly:** the chart's `lookup` preserves
  it across upgrades, but `helm template` — or a fresh install under
  a new release name — generates a new one. Always use `helm install` /
  `helm upgrade` against the same release name, or pre-create the
  secret and set `auth.existingSecret`.
- **DNS agent can't reach control plane:** the chart sets
  `CONTROL_PLANE_URL` to `http://<release>-spatiumddi-api.<ns>.svc.cluster.local:8000`.
  Agents running outside the cluster need a different URL via a custom
  `values.yaml` override (not currently exposed — raise an issue).

## Development

```bash
cd charts/spatiumddi
helm dependency update           # pull bitnami/postgresql + bitnami/redis
helm lint .
helm template test . --namespace test | less
```

For local testing against a real cluster:

```bash
helm install test . \
  --namespace spatiumddi --create-namespace \
  --set image.tag=latest \
  --set postgresql.primary.persistence.size=2Gi
```
