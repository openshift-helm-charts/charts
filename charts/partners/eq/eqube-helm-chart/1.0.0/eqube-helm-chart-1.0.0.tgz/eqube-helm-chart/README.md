# eQube-MI Helm Chart (Parent + Sub-charts)

## Chart Structure

```
eqube-mi/                          ← parent chart
├── Chart.yaml                     ← declares dependencies on sub-charts
├── values.yaml                    ← single source of truth (all config here)
├── values.schema.json             ← JSON Schema for OpenShift certification
└── charts/
    ├── db-schema/                 ← Step 1: Oracle user & tablespace creation
    │   ├── Chart.yaml
    │   ├── values.yaml
    │   ├── sql-scripts/
    │   │   └── sql-script.sql     ← templated SQL run via sqlplus
    │   └── templates/
    │       ├── _helpers.tpl
    │       ├── secret.yaml        ← DB admin credentials (hook)
    │       ├── configmap.yaml     ← SQL script ConfigMap (hook)
    │       └── job.yaml           ← pre-install hook Job
    │
    ├── db-metadata/               ← Step 2: eQube metadata schema creation
    │   ├── Chart.yaml
    │   ├── values.yaml
    │   ├── config/server/         ← SSL certificate files (if needed)
    │   └── templates/
    │       ├── _helpers.tpl       ← includes env-merge helpers
    │       ├── secret.yaml        ← shared secret (hook)
    │       ├── config_maps/
    │       │   └── certificate_config.yaml
    │       └── job.yaml           ← pre-install hook Job
    │
    └── application/               ← Step 3: eQube-MI WAR deployment
        ├── Chart.yaml
        ├── values.yaml
        ├── config/
        │   ├── server.xml
        │   ├── server/            ← SSL cert files
        │   └── metadata/          ← metadata files
        └── templates/
            ├── _helpers.tpl       ← includes env-merge helpers
            ├── app-secret.yaml    ← shared secret
            ├── statefulset.yaml   ← primary workload (non-intelligent-scaling)
            ├── Deployment.yaml    ← intelligent-scaling mode
            ├── service.yaml
            ├── ingress.yaml
            ├── hpa.yaml
            ├── route.yaml         ← OpenShift Route
            ├── servicemonitor.yaml
            └── config_maps/
                ├── certificate_config.yaml
                └── serverxml_config.yaml
```

---

## Execution Sequence

```
helm install mychart .
       │
       ▼  [hook weight -25]
db-schema Secret + ConfigMap created
       │
       ▼  [hook weight -20]
db-schema Job runs → sqlplus creates Oracle user & tablespace
       │             Must complete (exit 0) before next step
       ▼  [hook weight -15]
db-metadata Secret + ConfigMap created
       │
       ▼  [hook weight -10]
db-metadata Job runs → eQube metadata schema creation
       │               Must complete (exit 0) before next step
       ▼  [normal install]
application resources created:
  Secret, ConfigMaps, StatefulSet (or Deployment), Service,
  Ingress / Route, HPA, ServiceMonitor
```

---

## Shared `environmentVariables` & `secret`

The **single most important design** in this chart: environment variables and
secrets are defined **once** at the parent level and **injected into both**
`db-metadata` and `application` sub-charts.

```yaml
# parent values.yaml
environmentVariables:          # ← shared across db-metadata + application
  equbemi:
    CONTEXT_NAME: eQubeMI
    ...
  equbess:
    SS_MODE: Standalone
    ...

secret:                        # ← shared across db-metadata + application
  equbemi:
    metadata:
      DB_JDBC_URL: ...
      DB_JDBC_PASSWORD: ...
```

### Override / Merge Pattern

Each sub-chart can add or override individual keys via its own `extraEnv`
section **without duplicating** the shared base:

```yaml
# parent values.yaml
db-metadata:
  extraEnv:                    # ← merged ON TOP of shared environmentVariables
    equbemi:
      CREATE_METADATA: true    # Step-2-specific key
      INSTALLER_MODE: 0

application:
  extraEnv:                    # ← merged ON TOP of shared environmentVariables
    equbemi:
      HA_AUTO_SCALING_ENABLED: 'false'   # App-specific override
```

**Merge semantics**: `extraEnv` keys **win** over shared `environmentVariables`
keys. This uses Helm's `merge` function (`deepCopy(extra) merged with shared`).

---

## Installation

```bash
# 1. Resolve sub-chart dependencies (only needed on first use / version bump)
helm dependency update .

# 2. Dry-run to verify rendered output
helm install mychart . --dry-run --debug

# 3. Install
helm install mychart . \
  --set global.dbAdminUser=SYS \
  --set global.dbAdminPass=MySecretPass \
  --set global.dbHost=oracle-db.example.com \
  --set db-schema.dbUser=eqube_user \
  --set db-schema.dbPassword=eqube_pass \
  --set db-schema.dbTablespace=EQUBE_TS \
  --set db-metadata.image.repository=myregistry/eqube-metadata \
  --set db-metadata.image.tag=2025.02.00 \
  --set application.image.repository=myregistry/eqube-mi \
  --set application.image.tag=2025.02.00

# 4. Upgrade
helm upgrade mychart . --reuse-values \
  --set application.image.tag=2025.03.00
```

---

## Step Flags

Disable a step (e.g. skip DB user creation if the user already exists):

```yaml
# values.yaml override
db-schema:
  enabled: false      # skip Step 1

db-metadata:
  enabled: false      # skip Step 2 (application still deploys)
```

---

## Hook Ordering (hook-weight values)

| Resource               | hook-weight | Purpose                          |
|------------------------|-------------|----------------------------------|
| db-schema Secret/CM    | -25         | Credentials available before Job |
| **db-schema Job**      | **-20**     | Step 1 – Oracle user creation    |
| db-metadata Secret/CM  | -15         | Credentials available before Job |
| **db-metadata Job**    | **-10**     | Step 2 – Metadata creation       |
| application resources  | (normal)    | Step 3 – WAR deployment          |

Helm guarantees all hook resources with a lower weight complete before
higher-weight hooks are created.

---

## OpenShift Certification

- `values.schema.json` — JSON Schema Draft-07 validates all configurable keys
- Named ports on all containers (`http` / `https`)
- `route.openshift.io/v1` Route template with TLS options
- `hook-delete-policy: before-hook-creation` prevents stale Job conflicts
- No `latest` tag used by default on application image
- Resource requests + limits on all containers (including hook Jobs)
