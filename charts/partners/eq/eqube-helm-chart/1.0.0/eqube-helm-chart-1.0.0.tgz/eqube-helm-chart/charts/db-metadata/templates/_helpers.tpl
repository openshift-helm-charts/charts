{{- define "db-metadata.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "db-metadata.fullname" -}}
{{- printf "%s-%s" .Release.Name "db-metadata" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "db-metadata.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "db-metadata.labels" -}}
helm.sh/chart: {{ include "db-metadata.chart" . }}
{{ include "db-metadata.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: db-metadata
{{- end }}

{{- define "db-metadata.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db-metadata.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Recursively flatten a nested dict into flat k=v env entries.
Skips nil / empty / "null" values.
*/}}
{{- define "helpers.flatten-env-vars" -}}
{{- range $key, $val := .dict }}
  {{- if kindIs "map" $val }}
    {{- include "helpers.flatten-env-vars" (dict "dict" $val) }}
  {{- else }}
    {{- $strVal := toString $val }}
    {{- if and (ne $val nil) (ne $strVal "null") (ne $strVal "") }}
- name: {{ $key }}
  value: {{ $strVal | quote }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Merge shared environmentVariables with sub-chart extraEnv and emit as env list.
extraEnv keys WIN over shared keys (sub-chart override semantics).
*/}}
{{- define "db-metadata.mergedEnv" -}}
{{- $shared := deepCopy (default dict .Values.environmentVariables) }}
{{- $extra  := deepCopy (default dict .Values.extraEnv) }}
{{- $merged := merge $extra $shared }}
{{- include "helpers.flatten-env-vars" (dict "dict" $merged) }}
{{- end }}

{{/*
Recursively base64-encode a nested secret dict into a flat map (for Secret data:).
Skips nil / empty / "null" values.
*/}}
{{- define "helpers.flattenMap" -}}
{{- $dict   := .dict -}}
{{- $result := dict -}}
{{- range $key, $val := $dict }}
  {{- if kindIs "map" $val }}
    {{- $nested := include "helpers.flattenMap" (dict "dict" $val) | fromYaml -}}
    {{- range $k, $v := $nested }}
      {{- $_ := set $result $k $v }}
    {{- end }}
  {{- else }}
    {{- if and (ne $val nil) (ne (toString $val) "") (ne (toString $val) "null") }}
      {{- $_ := set $result $key ($val | toString | b64enc) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toYaml $result | nindent 0 }}
{{- end }}

{{/*
Lookup a key recursively within a nested dict.
Usage: include "env._find" (list $data $key $resultDict)
*/}}
{{- define "env._find" -}}
{{- $data   := index . 0 -}}
{{- $key    := index . 1 -}}
{{- $result := index . 2 -}}
{{- if kindIs "map" $data -}}
  {{- range $k, $v := $data -}}
    {{- if eq $k $key -}}
      {{- $_ := set $result "value" $v -}}
    {{- else if kindIs "map" $v -}}
      {{- include "env._find" (list $v $key $result) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Public env lookup helper.
Usage: include "env.get" (list . "KEY" "default")
Searches merged (extraEnv + environmentVariables).
*/}}
{{- define "env.get" -}}
{{- $root    := index . 0 -}}
{{- $key     := index . 1 -}}
{{- $default := index . 2 | default "" -}}
{{- $result  := dict "value" $default -}}
{{- $shared  := default dict $root.Values.environmentVariables -}}
{{- $extra   := default dict $root.Values.extraEnv -}}
{{- $merged  := merge (deepCopy $extra) $shared -}}
{{- include "env._find" (list $merged $key $result) -}}
{{- get $result "value" -}}
{{- end -}}
