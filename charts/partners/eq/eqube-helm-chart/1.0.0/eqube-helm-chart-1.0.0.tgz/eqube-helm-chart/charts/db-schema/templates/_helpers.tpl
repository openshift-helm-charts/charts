{{- define "db-schema.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "db-schema.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name "db-schema" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "db-schema.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "db-schema.labels" -}}
helm.sh/chart: {{ include "db-schema.chart" . }}
{{ include "db-schema.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: db-schema
{{- end }}

{{- define "db-schema.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db-schema.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
