{{- define "application.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "application.fullname" -}}
{{- printf "%s-%s" .Release.Name "app" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "application.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "application.labels" -}}
helm.sh/chart: {{ include "application.chart" . }}
{{ include "application.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: application
{{- end }}

{{- define "application.selectorLabels" -}}
app.kubernetes.io/name: {{ include "application.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Recursively flatten a nested dict into flat k=v env list entries.
Skips nil / empty / "null" values.
*/}}
{{- define "helpers.flatten-env-vars" -}}
{{- range $key, $val := .dict }}
  {{- if kindIs "map" $val }}
    {{- include "helpers.flatten-env-vars" (dict "dict" $val) }}
  {{- else }}
    {{- $strVal := toString $val }}
    {{- if and (ne $val nil) (ne $strVal "null") (ne $strVal "") }}
- name: {{ $key }}
  value: {{ $strVal | quote }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Merge shared environmentVariables with application-specific extraEnv and
emit as a Kubernetes env list. extraEnv keys WIN (override shared).
*/}}
{{- define "application.mergedEnv" -}}
{{- $shared := deepCopy (default dict .Values.environmentVariables) }}
{{- $extra  := deepCopy (default dict .Values.extraEnv) }}
{{- $merged := merge $extra $shared }}
{{- include "helpers.flatten-env-vars" (dict "dict" $merged) }}
{{- end }}

{{/*
Recursively base64-encode a nested secret dict into a flat Kubernetes Secret data map.
Skips nil / empty / "null" values.
*/}}
{{- define "helpers.flattenMap" -}}
{{- $dict   := .dict -}}
{{- $result := dict -}}
{{- range $key, $val := $dict }}
  {{- if kindIs "map" $val }}
    {{- $nested := include "helpers.flattenMap" (dict "dict" $val) | fromYaml -}}
    {{- range $k, $v := $nested }}
      {{- $_ := set $result $k $v }}
    {{- end }}
  {{- else }}
    {{- if and (ne $val nil) (ne (toString $val) "") (ne (toString $val) "null") }}
      {{- $_ := set $result $key ($val | toString | b64enc) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- toYaml $result | nindent 0 }}
{{- end }}

{{/*
Internal recursive key finder.
*/}}
{{- define "env._find" -}}
{{- $data   := index . 0 -}}
{{- $key    := index . 1 -}}
{{- $result := index . 2 -}}
{{- if kindIs "map" $data -}}
  {{- range $k, $v := $data -}}
    {{- if eq $k $key -}}
      {{- $_ := set $result "value" $v -}}
    {{- else if kindIs "map" $v -}}
      {{- include "env._find" (list $v $key $result) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Public env lookup. Searches merged(extraEnv + environmentVariables).
Usage: include "env.get" (list . "KEY" "default")
*/}}
{{- define "env.get" -}}
{{- $root    := index . 0 -}}
{{- $key     := index . 1 -}}
{{- $default := index . 2 | default "" -}}
{{- $result  := dict "value" $default -}}
{{- $shared  := default dict $root.Values.environmentVariables -}}
{{- $extra   := default dict $root.Values.extraEnv -}}
{{- $merged  := merge (deepCopy $extra) $shared -}}
{{- include "env._find" (list $merged $key $result) -}}
{{- get $result "value" -}}
{{- end -}}
