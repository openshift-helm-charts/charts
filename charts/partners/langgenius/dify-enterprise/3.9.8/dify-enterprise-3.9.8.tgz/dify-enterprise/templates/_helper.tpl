{{/*
Expand the name of the chart.
*/}}
{{- define "dify.name" -}}
{{- default .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dify.fullname" -}}
{{- $name := default .Chart.Name }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dify.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dify.labels" -}}
helm.sh/chart: {{ include "dify.chart" . }}
{{ include "dify.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/* labels defined by user*/}}
{{- define "dify.ud.labels" -}}
{{- if .Values.labels }}
{{- toYaml .Values.labels }}
{{- end -}}
{{- end -}}

{{/* annotations defined by user*/}}
{{- define "dify.ud.annotations" -}}
{{- if .Values.annotations }}
{{- toYaml .Values.annotations }}
{{- end -}}
{{- end -}}

{{/* Extra labels on all workload pod templates (see global.podLabels). Not added to selectors. */}}
{{- define "dify.podExtraLabels" -}}
{{- if .Values.global.podLabels }}
{{- toYaml .Values.global.podLabels }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dify.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dify.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dify.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dify.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/* Effective ServiceAccount names for OpenShift-managed workloads. */}}
{{- define "dify.sandbox.serviceAccountName" -}}
{{- default (printf "%s-sandbox" (include "dify.fullname" .)) .Values.sandbox.serviceAccountName -}}
{{- end -}}

{{- define "dify.ssrfProxy.serviceAccountName" -}}
{{- default (printf "%s-ssrf-proxy" (include "dify.fullname" .)) .Values.ssrfProxy.serviceAccountName -}}
{{- end -}}

{{- define "dify.unstructured.serviceAccountName" -}}
{{- default (printf "%s-unstructured" (include "dify.fullname" .)) .Values.unstructured.serviceAccountName -}}
{{- end -}}

{{/* A per-service OpenShift boolean inherits global.openshift.enabled when unset. */}}
{{- define "dify.openshift.enabledFor" -}}
{{- $local := dig "openshift" .key nil .service -}}
{{- if kindIs "bool" $local -}}
  {{- if $local -}}true{{- end -}}
{{- else if dig "openshift" "enabled" false (default (dict) .root.Values.global) -}}
true
{{- end -}}
{{- end -}}

{{/* Namespace for plugin runtime resources */}}
{{- define "dify.pluginRuntimeNamespace" -}}
{{- default "default" (default .Release.Namespace .Values.plugin_connector.pluginNamespace) -}}
{{- end -}}

{{/* Namespace for plugin control-plane resources */}}
{{- define "dify.pluginControlPlaneNamespace" -}}
{{- default "default" .Release.Namespace -}}
{{- end -}}

{{/* MinIO host for plugin components */}}
{{- define "dify.pluginControlPlaneMinioHost" -}}
{{- printf "%s-minio.%s" (include "dify.fullname" .) (include "dify.pluginControlPlaneNamespace" .) -}}
{{- end -}}

{{/* Service account for plugin connector */}}
{{- define "dify.pluginConnectorServiceAccountName" -}}
{{- printf "%s-plugin-connector-sa" (include "dify.fullname" .) -}}
{{- end -}}

{{/* Service account for controller-created plugin builder and runner pods. */}}
{{- define "dify.pluginWorkloadServiceAccountName" -}}
{{- default (printf "%s-plugin-workload" (include "dify.fullname" .)) .Values.plugin_connector.workloadServiceAccountName -}}
{{- end -}}

{{/* Service account for plugin manager */}}
{{- define "dify.pluginManagerServiceAccountName" -}}
{{- printf "%s-plugin-manager-sa" (include "dify.fullname" .) -}}
{{- end -}}

{{/* Service account for plugin controller */}}
{{- define "dify.pluginControllerServiceAccountName" -}}
{{- printf "%s-plugin-controller-sa" (include "dify.fullname" .) -}}
{{- end -}}

{{/*
Check if any additionalWorker is enabled
*/}}
{{- define "dify.hasEnabledAdditionalWorkers" -}}
{{- range .Values.additionalWorkers -}}
  {{- if .enabled -}}true{{- end -}}
{{- end -}}
{{- end }}

{{- define "dify.redis.svc" -}}
{{- printf "%s-redis-master" .Release.Name }}
{{- end }}

{{- define "dify.redis.dsn" -}}
{{- if .Values.externalRedis.enabled -}}
  {{- $user := .Values.externalRedis.username | urlquery | replace "+" "%20" -}}
  {{- $pass := .Values.externalRedis.password | urlquery | replace "+" "%20" -}}
  {{- $db := .Values.externalRedis.db | default 0 -}}
  {{- $useSSL := .Values.externalRedis.useSSL | default false -}}
  {{- if .Values.externalRedis.sentinel.enabled -}}
    {{- $nodes := .Values.externalRedis.sentinel.nodes | default "" -}}
    {{- $svc := .Values.externalRedis.sentinel.serviceName -}}
    {{- $proto := ternary "rediss+sentinel" "redis+sentinel" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $nodes }}/{{ $db }}?sentinelService={{ $svc }}
  {{- else if .Values.externalRedis.cluster.enabled -}}
    {{- $nodes := .Values.externalRedis.cluster.nodes | default "" -}}
    {{- $proto := ternary "rediss+cluster" "redis+cluster" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $nodes }}/{{ $db }}
  {{- else -}}
    {{- $host := .Values.externalRedis.host | default "localhost" -}}
    {{- $port := .Values.externalRedis.port | default 6379 -}}
    {{- $proto := ternary "rediss" "redis" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $host }}:{{ $port }}/{{ $db }}
  {{- end -}}
{{- else if .Values.redis.enabled -}}
  {{- $pass := .Values.redis.global.redis.password | urlquery | replace "+" "%20" -}}
  {{- $svc := include "dify.redis.svc" . -}}
  redis://:{{ $pass }}@{{ $svc }}:6379/0
{{- else -}}
  ""
{{- end -}}
{{- end }}

{{/* get default database name for credential key
Returns the default database name based on credential key.
*/}}
{{- define "dify.defaultDbName" -}}
{{- $credentialKey := .credentialKey -}}
{{- $defaultDbNames := dict 
    "dify" "dify" 
    "enterprise" "enterprise" 
    "plugin_daemon" "dify_plugin_daemon" 
    "audit" "audit" 
-}}
{{- index $defaultDbNames $credentialKey -}}
{{- end }}

{{/* get database name for credential key
Returns the database name based on externalDatabase or default.
*/}}
{{- define "dify.dbName" -}}
{{- $credentialKey := .credentialKey -}}
{{- $defaultDbName := include "dify.defaultDbName" (dict "credentialKey" $credentialKey) -}}
{{- if .Values.externalDatabase.enabled -}}
  {{- $dbName := index .Values.externalDatabase.databases $credentialKey -}}
  {{- $dbName | default $defaultDbName -}}
{{- else -}}
  {{- $defaultDbName -}}
{{- end -}}
{{- end }}

{{/* get per-database credential user for a given credential key.
Returns the user from externalDatabase.databaseCredentials[credentialKey] if set,
otherwise returns empty string (application layer falls back to global DB_USER).
*/}}
{{- define "dify.dbCredentialUser" -}}
{{- $credentialKey := .credentialKey -}}
{{- if and .Values.externalDatabase.enabled .Values.externalDatabase.databaseCredentials -}}
  {{- $creds := index .Values.externalDatabase.databaseCredentials $credentialKey -}}
  {{- if $creds -}}
    {{- $creds.user | default "" -}}
  {{- end -}}
{{- end -}}
{{- end }}

{{/* get per-database credential password for a given credential key.
Returns the password from externalDatabase.databaseCredentials[credentialKey] if set,
otherwise returns empty string (application layer falls back to global DB_PASS).
*/}}
{{- define "dify.dbCredentialPassword" -}}
{{- $credentialKey := .credentialKey -}}
{{- if and .Values.externalDatabase.enabled .Values.externalDatabase.databaseCredentials -}}
  {{- $creds := index .Values.externalDatabase.databaseCredentials $credentialKey -}}
  {{- if $creds -}}
    {{- $creds.password | default "" -}}
  {{- end -}}
{{- end -}}
{{- end }}

{{/* get db instance configuration
Returns a JSON object with db instance connection details:
{
  "engine": "postgres|mysql|tidb",
  "host": "...",
  "port": "5432",
  "user": "...",
  "password": "...",
  "timezone": "UTC",
  "pg_ssl_mode": "...",
  "pg_uri_scheme": "...",
  "pg_extras": "...",
  "mysql_params": "...",
  "mysql_tls": "false"
}
*/}}
{{- define "dify.dbInstance" -}}
{{- $dbInstance := dict -}}
{{- $engine := "postgres" -}}
{{- if .Values.externalDatabase.enabled -}}
  {{- $engine = (.Values.externalDatabase.engine | default "postgres") -}}
  {{- $_ := set $dbInstance "engine" $engine -}}
  {{- $_ := set $dbInstance "host" (.Values.externalDatabase.host | default "localhost") -}}
  {{- $defaultPort := 5432 -}}
  {{- if eq $engine "mysql" -}}
    {{- $defaultPort = 3306 -}}
  {{- else if eq $engine "tidb" -}}
    {{- $defaultPort = 4000 -}}
  {{- end -}}
  {{- $_ := set $dbInstance "port" (printf "%v" (.Values.externalDatabase.port | default $defaultPort)) -}}
  {{- $_ := set $dbInstance "user" (.Values.externalDatabase.user | default "postgres") -}}
  {{- $_ := set $dbInstance "password" (.Values.externalDatabase.password | default "") -}}
  {{- $_ := set $dbInstance "timezone" (.Values.externalDatabase.timezone | default "UTC") -}}
  {{- $_ := set $dbInstance "pg_ssl_mode" (.Values.externalDatabase.dialectOptions.postgres.sslMode | default "require") -}}
  {{- $_ := set $dbInstance "pg_uri_scheme" (.Values.externalDatabase.dialectOptions.postgres.uriScheme | default "postgresql") -}}
  {{- $_ := set $dbInstance "pg_extras" (.Values.externalDatabase.dialectOptions.postgres.extras | default "") -}}
  {{- $_ := set $dbInstance "mysql_params" (.Values.externalDatabase.dialectOptions.mysql.params | default "charset=utf8mb4&parseTime=true&loc=UTC") -}}
  {{- $_ := set $dbInstance "mysql_tls" (.Values.externalDatabase.dialectOptions.mysql.tls | default false) -}}
{{- else if .Values.postgresql.enabled -}}
  {{- $username := "" -}}
  {{- $password := "" -}}
  {{- with .Values.postgresql.global.postgresql.auth -}}
    {{- if empty .username -}}
      {{- $username = "postgres" -}}
      {{- $password = .postgresPassword -}}
    {{- else -}}
      {{- $username = .username -}}
      {{- $password = .password -}}
    {{- end -}}
  {{- end -}}
  {{- $host := "" -}}
  {{- if eq .Values.postgresql.architecture "replication" -}}
    {{- $host = printf "%s-postgresql-primary" .Release.Name -}}
  {{- else -}}
    {{- $host = printf "%s-postgresql" .Release.Name -}}
  {{- end -}}
  {{- $_ := set $dbInstance "engine" "postgres" -}}
  {{- $_ := set $dbInstance "host" $host -}}
  {{- $_ := set $dbInstance "port" "5432" -}}
  {{- $_ := set $dbInstance "user" $username -}}
  {{- $_ := set $dbInstance "password" $password -}}
  {{- $_ := set $dbInstance "timezone" "UTC" -}}
  {{- $_ := set $dbInstance "pg_ssl_mode" "disable" -}}
  {{- $_ := set $dbInstance "pg_uri_scheme" "postgresql" -}}
  {{- $_ := set $dbInstance "pg_extras" "" -}}
  {{- $_ := set $dbInstance "mysql_params" "" -}}
  {{- $_ := set $dbInstance "mysql_tls" false -}}
{{- end -}}
{{- $dbInstance | toJson -}}
{{- end }}

{{/* get datasource from external database (PostgreSQL/MySQL/TiDB) or internal postgresql
Returns a JSON object with database connection details:
{
  "db_type": "postgresql|mysql",
  "db_default": "postgres|mysql",
  "driver": "postgres|mysql",
  "user": "...",
  "password": "...",
  "host": "...",
  "port": "5432",
  "ssl_mode": "...",
  "uri_scheme": "postgresql",
  "db_extras": "...",
  "db_charset": "...",
  "db_name": "..."
}

Usage: 
  As JSON: include "dify.datasource" .
  As YAML: include "dify.datasource" . | fromJson | toYaml
  With credential key: include "dify.datasource" (dict "Values" .Values "credentialKey" "enterprise")

Note: db_name is now included in the returned JSON object with default values based on credential key.
Note: db_type is the application-level database type (postgresql/mysql), used by Dify api/worker/plugin-daemon.
Note: db_default is the default database for initial connection (postgres for PostgreSQL, mysql for MySQL/TiDB).
*/}}
{{- define "dify.datasource" -}}
{{- $credentialKey := .credentialKey -}}
{{- $datasource := dict -}}
{{- $_ := set $datasource "driver" "postgres" -}}
{{- $_ := set $datasource "db_type" "postgresql" -}}
{{- $_ := set $datasource "db_default" "postgres" -}}
{{- if .Values.externalDatabase.enabled -}}
  {{- $engine := .Values.externalDatabase.engine | default "postgres" -}}
  {{- $driver := "postgres" -}}
  {{- $dbType := "postgresql" -}}
  {{- $dbDefault := "postgres" -}}
  {{- if or (eq $engine "mysql") (eq $engine "tidb") -}}
    {{- $driver = "mysql" -}}
    {{- $dbType = "mysql" -}}
    {{- $dbDefault = "mysql" -}}
  {{- end -}}
  {{- $_ := set $datasource "driver" $driver -}}
  {{- $_ := set $datasource "db_type" $dbType -}}
  {{- $_ := set $datasource "db_default" $dbDefault -}}
  {{- $_ := set $datasource "host" (.Values.externalDatabase.host | default "localhost") -}}
  {{- $defaultPort := 5432 -}}
  {{- if eq $engine "mysql" -}}
    {{- $defaultPort = 3306 -}}
  {{- else if eq $engine "tidb" -}}
    {{- $defaultPort = 4000 -}}
  {{- end -}}
  {{- $_ := set $datasource "port" (printf "%v" (.Values.externalDatabase.port | default $defaultPort)) -}}
  {{- $_ := set $datasource "user" (.Values.externalDatabase.user | default "postgres") -}}
  {{- $_ := set $datasource "password" (.Values.externalDatabase.password | default "") -}}
  {{- if or (eq $engine "mysql") (eq $engine "tidb") -}}
    {{- if .Values.externalDatabase.dialectOptions.mysql.tls -}}
      {{- $_ := set $datasource "ssl_mode" "require" -}}
    {{- else -}}
      {{- $_ := set $datasource "ssl_mode" "disable" -}}
    {{- end -}}
  {{- else -}}
    {{- $_ := set $datasource "ssl_mode" (.Values.externalDatabase.dialectOptions.postgres.sslMode | default "require") -}}
  {{- end -}}
  {{- if or (eq $engine "mysql") (eq $engine "tidb") -}}
    {{- $_ := set $datasource "uri_scheme" "mysql+pymysql" -}}
    {{- $_ := set $datasource "db_extras" "" -}}
  {{- else -}}
    {{- $_ := set $datasource "uri_scheme" (.Values.externalDatabase.dialectOptions.postgres.uriScheme | default "postgresql") -}}
    {{- $_ := set $datasource "db_extras" (.Values.externalDatabase.dialectOptions.postgres.extras | default "") -}}
  {{- end -}}
  {{- $_ := set $datasource "db_charset" "" -}}
  {{- $defaultDbName := include "dify.defaultDbName" (dict "credentialKey" $credentialKey) -}}
  {{- $dbName := index .Values.externalDatabase.databases $credentialKey -}}
  {{- $_ := set $datasource "db_name" ($dbName | default $defaultDbName) -}}
{{- else if .Values.postgresql.enabled -}}
  {{- $username := "" -}}
  {{- $password := "" -}}
  {{- with .Values.postgresql.global.postgresql.auth -}}
    {{- if empty .username -}}
      {{- $username = "postgres" -}}
      {{- $password = .postgresPassword -}}
    {{- else -}}
      {{- $username = .username -}}
      {{- $password = .password -}}
    {{- end -}}
  {{- end -}}
  {{- $host := "" -}}
  {{- if eq .Values.postgresql.architecture "replication" -}}
    {{- $host = printf "%s-postgresql-primary" .Release.Name -}}
  {{- else -}}
    {{- $host = printf "%s-postgresql" .Release.Name -}}
  {{- end -}}
  {{- $_ := set $datasource "db_type" "postgresql" -}}
  {{- $_ := set $datasource "db_default" "postgres" -}}
  {{- $_ := set $datasource "user" $username -}}
  {{- $_ := set $datasource "password" $password -}}
  {{- $_ := set $datasource "host" $host -}}
  {{- $_ := set $datasource "port" "5432" -}}
  {{- $_ := set $datasource "ssl_mode" "disable" -}}
  {{- $_ := set $datasource "uri_scheme" "postgresql" -}}
  {{- $_ := set $datasource "db_extras" "" -}}
  {{- $_ := set $datasource "db_charset" "" -}}
  {{- $defaultDbName := include "dify.defaultDbName" (dict "credentialKey" $credentialKey) -}}
  {{- $_ := set $datasource "db_name" $defaultDbName -}}
{{- end -}}
{{- $datasource | toJson -}}
{{- end }}


{{/* Shortcuts for getting datasources - no need to specify credentialKey */}}
{{- define "dify.difyDatasource" -}}
{{- include "dify.datasource" (dict "Values" .Values "Release" .Release "credentialKey" "dify") -}}
{{- end }}

{{- define "dify.enterpriseDatasource" -}}
{{- include "dify.datasource" (dict "Values" .Values "Release" .Release "credentialKey" "enterprise") -}}
{{- end }}

{{- define "dify.pluginDaemonDatasource" -}}
{{- include "dify.datasource" (dict "Values" .Values "Release" .Release "credentialKey" "plugin_daemon") -}}
{{- end }}

{{- define "dify.auditDatasource" -}}
{{- include "dify.datasource" (dict "Values" .Values "Release" .Release "credentialKey" "audit") -}}
{{- end }}

{{/*
Build external URL with optional port
Usage: {{ include "dify.externalUrl" (dict "domain" .Values.global.consoleApiDomain "useTLS" .Values.global.useTLS "port" .Values.global.externalPort) }}
*/}}
{{- define "dify.externalUrl" -}}
{{- $domain := .domain -}}
{{- $useTLS := .useTLS -}}
{{- $port := .port | default 80 -}}
{{- if $useTLS -}}https://{{- else -}}http://{{- end -}}{{ $domain }}{{- if and $port (ne (int $port) 80) (ne (int $port) 443) -}}:{{ $port }}{{- end -}}
{{- end -}}

{{/*
OTEL configuration for ConfigMaps
Returns OTEL environment variables when both global.otel.enabled and enterpriseCollector.enabled are true
*/}}
{{- define "dify.otel.config" -}}
{{- if and .Values.global.otel.enabled .Values.enterpriseCollector.enabled }}
ENABLE_OTEL: "true"
OTLP_TRACE_ENDPOINT: "http://{{ template "dify.fullname" . }}-enterprise-collector-svc:4317"
OTLP_METRIC_ENDPOINT: "http://{{ template "dify.fullname" . }}-enterprise-collector-svc:4317"
OTLP_BASE_ENDPOINT: "http://{{ template "dify.fullname" . }}-enterprise-collector-svc:4317"
OTEL_EXPORTER_OTLP_PROTOCOL: "grpc"
OTEL_EXPORTER_TYPE: "otlp"
OTEL_SAMPLING_RATE: {{ .Values.global.otel.samplingRate | default "" | quote }}
OTEL_BATCH_EXPORT_SCHEDULE_DELAY: {{ .Values.global.otel.batchExportScheduleDelay | default "" | quote }}
OTEL_MAX_QUEUE_SIZE: {{ .Values.global.otel.maxQueueSize | default "" | quote }}
OTEL_MAX_EXPORT_BATCH_SIZE: {{ .Values.global.otel.maxExportBatchSize | default "" | quote }}
OTEL_METRIC_EXPORT_INTERVAL: {{ .Values.global.otel.metricExportInterval | default "" | quote }}
OTEL_BATCH_EXPORT_TIMEOUT: {{ .Values.global.otel.batchExportTimeout | default "" | quote }}
OTEL_METRIC_EXPORT_TIMEOUT: {{ .Values.global.otel.metricExportTimeout | default "" | quote }}
{{- end }}
{{- end }}

{{/*
OTEL API key for Secrets
Returns OTLP_API_KEY when both global.otel.enabled and enterpriseCollector.enabled are true
*/}}
{{- define "dify.otel.secret" -}}
{{- if and .Values.global.otel.enabled .Values.enterpriseCollector.enabled }}
OTLP_API_KEY: {{ .Values.global.innerApiKey | b64enc | quote }}
{{- end }}
{{- end }}

{{- define "dify.customCA.enabled" -}}
{{- if and .Values.global.customCA.enabled .Values.global.customCA.existingSecret }}true{{- end }}
{{- end }}

{{- define "dify.customCA.configName" -}}
{{- printf "%s-shared-custom-ca-config" (include "dify.fullname" .) -}}
{{- end }}

{{- define "dify.customCA.volume" -}}
- name: custom-ca-secret
  secret:
    secretName: {{ .Values.global.customCA.existingSecret | quote }}
    items:
      - key: {{ .Values.global.customCA.key | quote }}
        path: {{ .Values.global.customCA.key | quote }}
- name: custom-ca-combined
  emptyDir: {}
{{- end }}

{{- define "dify.customCA.volumeMount" -}}
- name: custom-ca-combined
  mountPath: {{ .Values.global.customCA.mountPath | quote }}
  readOnly: true
{{- end }}

{{- define "dify.customCA.initContainer" -}}
- name: init-custom-ca
  image: {{ .Values.global.customCA.initImage | default "alpine:3.20" }}
  imagePullPolicy: IfNotPresent
  command:
    - sh
    - -c
    - |
      if [ -f /etc/ssl/certs/ca-certificates.crt ]; then
        cp /etc/ssl/certs/ca-certificates.crt /custom-ca-combined/ca-bundle.crt
      elif [ -f /etc/ssl/cert.pem ]; then
        cp /etc/ssl/cert.pem /custom-ca-combined/ca-bundle.crt
      else
        echo "No system CA bundle found, creating empty bundle"
        touch /custom-ca-combined/ca-bundle.crt
      fi
      echo >> /custom-ca-combined/ca-bundle.crt
      cat /custom-ca-secret/{{ .Values.global.customCA.key }} >> /custom-ca-combined/ca-bundle.crt
  volumeMounts:
    - name: custom-ca-secret
      mountPath: /custom-ca-secret
      readOnly: true
    - name: custom-ca-combined
      mountPath: /custom-ca-combined
{{- end }}
