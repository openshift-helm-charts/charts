# Dify Enterprise

This chart installs Dify Enterprise and its supporting services.

## Install

```bash
helm dependency build charts/dify
helm upgrade --install dify charts/dify --namespace dify --create-namespace -f values.yaml
```

The default values expect external PostgreSQL and Redis services. Set all
placeholder credentials and domains before installing.

## OpenShift

OpenShift support is disabled by default. Enable the runtime profile with:

```yaml
global:
  openshift:
    enabled: true
```

The profile creates Routes for non-empty `global.*Domain` values and grants
only dedicated workload ServiceAccounts access to built-in SCCs:

| Workload | SCC |
| --- | --- |
| sandbox | `privileged` |
| unstructured | `nonroot-v2` |
| plugin connector | `nonroot-v2` |
| plugin builder and runner | `anyuid` |

The SSRF proxy runs with the namespace's default `restricted-v2` SCC and does
not require a chart-managed SCC binding. No elevated SCC is granted to the
namespace `default` ServiceAccount. Existing ServiceAccounts can be supplied
with:

- `sandbox.serviceAccountName`
- `ssrfProxy.serviceAccountName`
- `unstructured.serviceAccountName`
- `plugin_connector.workloadServiceAccountName`

Each service inherits `global.openshift.enabled`. To manage one workload's SCC
binding outside the chart, set its `openshift.sccBinding` value to `false`.
`ssrfProxy.serviceAccountName` selects an existing ServiceAccount but does not
create it or grant it an SCC.

The sandbox binds its dedicated ServiceAccount to the built-in `privileged`
SCC because its code runner requires `SYS_CHROOT`. The container is not
privileged and requests only `SYS_CHROOT` in addition to its default
capabilities.

Routes are controlled by `global.openshift.routes`. Duplicate hosts are
rendered once. Edge termination is the default; passthrough and re-encrypt
target the gateway's HTTPS port.

## Certified package and CRDs

The Red Hat certified package is named `dify-enterprise` and does not contain
the `DifyPlugin` CRD. Install the standalone CRD chart first:

```bash
helm upgrade --install dify-crds dify-enterprise-crds-VERSION.tgz
helm upgrade --install dify dify-enterprise-VERSION.tgz --namespace dify --create-namespace
```

Uninstalling the CRD chart deletes the CRD and all `DifyPlugin` resources.

## Verify

```bash
helm lint charts/dify
scripts/verify-openshift-chart.sh
helm test dify --namespace dify
```
