# Dify Enterprise Helm Chart

Dify Enterprise is an LLM application development platform that enables teams to build, deploy, and manage AI-powered workflows and agents at scale.

## Prerequisites

- Kubernetes: the standard chart enforces no version gate; the OpenShift-certified package enforces `kubeVersion >=1.21.0` (OpenShift >= 4.8)
- Helm >= 3.0
- A valid Dify Enterprise license
- An external PostgreSQL database (or enable the bundled one)
- An external Redis instance (or enable the bundled one)
- **OpenShift-certified (CRD-free) package**: install the DifyPlugin CRD once per cluster BEFORE installing the chart (requires cluster-admin): `helm install dify-crds https://github.com/langgenius/dify-helm/releases/download/dify-enterprise-crds-<version>/dify-enterprise-crds-<version>.tgz` (or `oc apply -f difyplugins-crd.yaml` from the same release)

## Installation

Add the Helm repository and install the chart:

```bash
helm repo add dify https://langgenius.github.io/dify-helm/
helm repo update

helm install my-dify dify/dify \
  --namespace dify \
  --create-namespace \
  --set global.appSecretKey="<your-secret-key>" \
  --set externalDatabase.enabled=true \
  --set externalDatabase.host="<postgres-host>" \
  --set externalDatabase.password="<postgres-password>" \
  --set externalRedis.host="<redis-host>" \
  --set externalRedis.password="<redis-password>"
```

To install with a custom values file:

```bash
helm install my-dify dify/dify -f my-values.yaml --namespace dify --create-namespace
```

## Upgrade

```bash
helm upgrade my-dify dify/dify -f my-values.yaml --namespace dify
```

## Uninstall

```bash
helm uninstall my-dify --namespace dify
```

Uninstalling the application release does not affect the DifyPlugin CRD.
However, uninstalling the `dify-enterprise-crds` chart **deletes the CRD and
cascade-deletes every DifyPlugin resource in the cluster (plugin data is not
recoverable)**. To upgrade the CRD, use `helm upgrade` on the
`dify-enterprise-crds` release — do not uninstall and reinstall it.

## Key Parameters

### Global

| Parameter | Description | Default |
|-----------|-------------|---------|
| `global.edition` | Application edition: `SELF_HOSTED` or `CLOUD` | `SELF_HOSTED` |
| `global.appSecretKey` | Secret key for session signing and data encryption | `#REPLACE_ME#` |
| `global.useTLS` | Enable HTTPS | `false` |
| `global.externalPort` | External access port | `80` |
| `global.dbMigrationEnabled` | Run DB migrations on startup | `true` |

### API Service

| Parameter | Description | Default |
|-----------|-------------|---------|
| `api.enabled` | Enable the API service | `true` |
| `api.replicas` | Number of replicas | `1` |
| `api.image.repository` | API image repository | `langgenius/dify-ee-api` |
| `api.image.tag` | API image tag | `3.9.6` |
| `api.resources` | CPU/memory resource requests and limits | `{}` |

### Worker

| Parameter | Description | Default |
|-----------|-------------|---------|
| `worker.enabled` | Enable the Celery worker | `true` |
| `worker.replicas` | Number of replicas | `1` |
| `worker.image.repository` | Worker image repository | `langgenius/dify-ee-api` |

### Web Frontend

| Parameter | Description | Default |
|-----------|-------------|---------|
| `web.enabled` | Enable the web frontend | `true` |
| `web.replicas` | Number of replicas | `1` |
| `web.image.repository` | Web image repository | `langgenius/dify-ee-web` |

### Enterprise Services

| Parameter | Description | Default |
|-----------|-------------|---------|
| `enterprise.enabled` | Enable the enterprise service | `true` |
| `enterprise.licenseMode` | License mode: `online` or `offline` | `online` |
| `enterpriseAudit.enabled` | Enable audit logging service | `true` |
| `enterpriseCollector.enabled` | Enable OpenTelemetry collector | `true` |
| `enterpriseFrontend.enabled` | Enable enterprise frontend | `true` |

### Storage (Persistence)

| Parameter | Description | Default |
|-----------|-------------|---------|
| `persistence.type` | Storage backend: `local`, `s3`, `azure-blob`, `aliyun-oss`, `google-storage`, etc. | `local` |
| `persistence.local.size` | PVC size for local storage | `5Gi` |
| `persistence.s3.endpoint` | S3-compatible endpoint URL | |
| `persistence.s3.bucketName` | S3 bucket name | |

### External Database (PostgreSQL)

| Parameter | Description | Default |
|-----------|-------------|---------|
| `externalDatabase.enabled` | Use external PostgreSQL | `false` |
| `externalDatabase.host` | PostgreSQL host | `localhost` |
| `externalDatabase.port` | PostgreSQL port | `5432` |
| `externalDatabase.user` | PostgreSQL username | `postgres` |
| `externalDatabase.password` | PostgreSQL password | `#REPLACE_ME#` |
| `externalDatabase.databases.dify` | Dify database name | `dify` |

### External Redis

| Parameter | Description | Default |
|-----------|-------------|---------|
| `externalRedis.enabled` | Use external Redis | `true` |
| `externalRedis.host` | Redis host | `redis.example` |
| `externalRedis.port` | Redis port | `6379` |
| `externalRedis.password` | Redis password | `#REPLACE_ME#` |
| `externalRedis.sentinel.enabled` | Use Redis Sentinel | `false` |
| `externalRedis.cluster.enabled` | Use Redis Cluster | `false` |

### Plugin System

| Parameter | Description | Default |
|-----------|-------------|---------|
| `plugin_daemon.enabled` | Enable plugin daemon | `true` |
| `plugin_connector.enabled` | Enable plugin connector | `true` |
| `plugin_manager.enabled` | Enable plugin manager | `true` |
| `plugin_controller.enabled` | Enable plugin CRD controller | `true` |

### Ingress

| Parameter | Description | Default |
|-----------|-------------|---------|
| `ingress.enabled` | Enable ingress | `false` |
| `ingress.className` | Ingress class name | `""` |
| `ingress.tls` | TLS configuration | `[]` |

## OpenShift Deployment Notes

- This chart supports OpenShift >= 4.12 (Kubernetes >= 1.25).
- For a one-command OpenShift install, set `global.openshift.enabled: true`.
  This single toggle enables the chart's OpenShift compatibility profile:
  dedicated ServiceAccounts + SCC RoleBindings for `sandbox`
  (`anyuid`) and `unstructured` (`nonroot-v2`), the `ssrf-proxy` squid
  compatibility snippet, and one OpenShift `Route` per unique
  `global.*Domain` pointing at the gateway service. See
  `examples/values.openshift-local.yaml` for a worked example and
  `global.openshift` in `values.yaml` for the per-piece override
  matrix.
- Per-service overrides at `<svc>.openshift.<flag>` win over the
  global toggle (true to opt one piece in without flipping the
  master switch; false to opt one piece out of an enabled global,
  e.g. running a custom SCC instead of `anyuid` for `sandbox`).
- Routes are configured under `global.openshift.routes`. Defaults
  reproduce edge TLS termination + auto HTTP→HTTPS redirect, using
  the cluster's default wildcard certificate. Set
  `global.openshift.routes.enabled: false` to opt out (e.g. you
  manage Routes externally or rely on the OpenShift Ingress→Route
  auto-translation).

### Migrating from the legacy `examples/openshift-local-routes.yaml`

Earlier versions of the chart shipped a hand-applied
`examples/openshift-local-routes.yaml` containing six standalone
`Route` objects (`dify-console`, `dify-api`, `dify-app`, `dify-upload`,
`dify-enterprise`, `dify-trigger`). The chart now manages these
Routes itself, with names derived from the domain field
(`<release>-console-api`, `<release>-service-api`, etc.).

Both old and new Routes target the same hosts. The OpenShift router
admits only one Route per host per namespace, and Helm refuses to
adopt resources it didn't create, so an in-place upgrade against a
namespace that still has the old Routes will fail with
`invalid ownership metadata`.

Pick one of:

1. **Drop the old manual Routes, then upgrade** (recommended):
   ```bash
   oc delete route -n <ns> dify-console dify-api dify-app dify-upload dify-enterprise dify-trigger
   helm upgrade dify ./charts/dify -n <ns> -f your-values.yaml
   ```

2. **Keep managing Routes externally**: set
   `global.openshift.routes.enabled: false` in your values to tell the
   chart not to render any Routes; continue applying your own Route
   manifests.

## Running Helm Tests

After installation, verify the deployment with:

```bash
helm test my-dify --namespace dify
```

This runs a connectivity check against the API health endpoint.

## Source Code

- Application: https://github.com/langgenius/dify
- Helm Chart: https://github.com/langgenius/dify-helm
