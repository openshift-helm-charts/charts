# iax-operator-crd-rh Helm Chart

This chart installs only the IAXPlatform CustomResourceDefinition (CRD) and ValidatingWebhookConfiguration required
for the IAX Operator.

- No ClusterRole or ClusterRoleBinding is ever created by this chart.
- Use this chart when you want to pre-install CRDs and webhooks before installing the operator namespaced in a namespace.

Upon uninstalling this chart, the CRD and ValidatingWebhookConfiguration will both be deleted. 

## Usage

```sh
helm install iax-operator-crd-rh ./iax-operator-crd-rh -n <namespace>
```

## Files
- `templates/crd.yaml`: Contains the IAXPlatform CRD manifest (always installed, no Helm logic).
- `templates/webhook-validating.yaml`: Contains the ValidatingWebhookConfiguration manifest.
- `_helpers.tpl`: Contains template helpers for naming and labels.
- `values.yaml`: Contains minimal values for webhook configuration.

## See Also
- [iax-operator-namespaced](../iax-operator-namespaced): Namespace-scoped operator chart.
- [iax-operator](../iax-operator): Main chart that installs both namespace and cluster-scoped resources.
