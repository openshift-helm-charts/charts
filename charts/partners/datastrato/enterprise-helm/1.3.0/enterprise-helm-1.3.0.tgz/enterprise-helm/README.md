# Enterprise Chart

The Enterprise chart is an all-in-one deployment package containing:

**Core Components (Enabled by Default):**
- Enterprise Gravitino (metadata management)
- Enterprise Web UI (unified catalog interface)
- Trino (data preview/query engine)
- Marquez (lineage tracking)
- OpenSearch (search and indexing)

**Optional Components:**
- Ranger (authorization, set `ranger.enabled=true`) ⚠️ **Deprecated**: Will be removed in a future release
- Logging (Fluent-bit + Loki, set `logging-output-loki.enabled=true` or `logging.enabled=true`)
- Monitoring (Prometheus + Grafana, set `monitoring.enabled=true`)
- Ingress Controller (set `ingress-nginx.enabled=true` for environments without existing ingress)

## Prerequisites

- Kubernetes 1.29+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure
- Access to Docker Hub registry (username/password required for pulling images)

### Environment-Specific Requirements

#### Storage Provisioners

| Environment | Provisioner | Notes |
|-------------|-------------|-------|
| **OrbStack** | `local-path-provisioner` | Lightweight local storage for development |
| **Minikube** | `storage-provisioner` | Built-in local storage |
| **EKS** | `AmazonEBSCSIDriver` | Scalable cloud storage for production |
| **Kind** | `rancher.io/local-path` | Requires `volumePermissions.enabled=true` for database pods |

#### Ingress Controllers

| Environment | Setup Command |
|-------------|---------------|
| **Minikube** | `minikube addons enable ingress` |
| **OrbStack** | Add `--set ingress-nginx.enabled=true` to helm install |
| **EKS** | Add `--set ingress-nginx.enabled=true` to helm install |
| **Kind** | Add `--set ingress-nginx.enabled=true` to helm install |

## Source Code

* <https://github.com/datastrato/gravitino-enterprise>
* <https://github.com/datastrato/unified-catalog-ui>
* <https://github.com/datastrato/marquez>
* <https://github.com/apache/gravitino>
* <https://github.com/datastrato/enterprise-deployment>

## Install from AWS ECR

The enterprise chart is published to AWS ECR public registry.

### Authentication

To authenticate with AWS ECR, you need AWS credentials with ECR access:

```bash
export AWS_DEFAULT_REGION=ap-northeast-1
export AWS_ACCESS_KEY_ID=<your-access-key>
export AWS_SECRET_ACCESS_KEY=<your-secret-key>
```

### Helm Registry Login

```bash
aws ecr get-login-password --region ap-northeast-1 | \
  helm registry login --username AWS --password-stdin \
  730335553010.dkr.ecr.ap-northeast-1.amazonaws.com
```

### Quick Start Installation

```bash
# Basic installation (Gravitino + Web UI + Marquez + OpenSearch)
helm upgrade --install enterprise \
  oci://730335553010.dkr.ecr.ap-northeast-1.amazonaws.com/datastratocharts/enterprise-helm \
  --version 1.0.0-rc1 \
  -n datastrato \
  --create-namespace \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>

# With ingress controller (OrbStack/Kind/EKS)
helm upgrade --install enterprise \
  oci://730335553010.dkr.ecr.ap-northeast-1.amazonaws.com/datastratocharts/enterprise-helm \
  --version 1.0.0-rc1 \
  -n datastrato \
  --create-namespace \
  --set ingress-nginx.enabled=true \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>
```

### View Chart Values

Display all configurable parameters:

```bash
helm show values \
  oci://730335553010.dkr.ecr.ap-northeast-1.amazonaws.com/datastratocharts/enterprise-helm \
  --version 1.0.0-rc1
```

## Deployment Scenarios

### Default Installation (Gravitino + Web UI + Trino + Marquez + OpenSearch)

The default configuration deploys:
- **Gravitino** with PostgreSQL backend (shared with Marquez)
- **Enterprise Web UI** for unified catalog management
- **Trino** for data preview and SQL query execution
- **Marquez** for lineage tracking (shares PostgreSQL with Gravitino)
- **OpenSearch** for search and indexing

#### OrbStack / Kind

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set ingress-nginx.enabled=true \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>
```

Add ingress hosts to `/etc/hosts`:

```bash
kubectl get ingress -n datastrato
# Add output ADDRESS to /etc/hosts
# 198.19.249.2 gravitino.example.com
# 198.19.249.2 marquez.example.com
```

Access UI:
- Gravitino: http://gravitino.example.com/
- Marquez: http://marquez.example.com/

#### Minikube

```bash
# Enable ingress addon first
minikube addons enable ingress

helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>
```

Configure hosts mapping same as OrbStack.

#### EKS (Production)

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set ingress-nginx.enabled=true \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>
```

Configure Route53 DNS:

```bash
kubectl get ingress -n datastrato
# Map HOSTS to LoadBalancer ADDRESS FQDN in Route53
```

### Full Stack Installation (All Components)

Enable all optional components:

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set ingress-nginx.enabled=true \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key> \
  --set ranger.enabled=true \
  --set logging-output-loki.enabled=true \
  --set monitoring.enabled=true
```

Components:
- ✅ Gravitino + Web UI + Trino + Marquez + OpenSearch (default)
- ✅ Ranger (authorization) ⚠️ **Deprecated**: Will be removed in a future release
- ✅ Fluent-bit + Loki (logging)
- ✅ Prometheus + Grafana (monitoring)

**Note on Ranger:** Ranger is deprecated and will be removed in a future chart release. For new deployments, consider using Gravitino's built-in authorization features instead.

### Gravitino-Only Installation

Minimal installation with only Gravitino and Web UI (no Trino, Marquez, OpenSearch):

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key> \
  -f charts/enterprise/scenarios/enterprise-gravitino-only.yaml
```

**Components:** Only Gravitino + Web UI (no data preview, lineage, or search features)

### Using Red Hat Certified Images

For OpenShift or environments requiring Red Hat certified images:

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set global.pullSecrets.additionalRegistries[0].registry=registry.redhat.io \
  --set global.pullSecrets.additionalRegistries[0].username=<redhat-username> \
  --set global.pullSecrets.additionalRegistries[0].password=<redhat-password> \
  --set gravitino.license.key=<license-key>
```

**Note:** Red Hat images are the default for PostgreSQL and MySQL databases. The chart uses `flavor: redhat` by default.

### Separate Namespace Deployments

#### Logging in Dedicated Namespace

Deploy logging stack (Fluent-bit + Loki) separately:

```bash
helm upgrade --install logging \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n logging \
  --create-namespace \
  -f charts/enterprise/scenarios/logging-another-namespace.yaml
```

**Scenario file:** `charts/enterprise/scenarios/logging-another-namespace.yaml`

This deploys only Loki and Fluent-bit DaemonSet for centralized log collection.

#### Monitoring in Dedicated Namespace

Deploy monitoring stack (Prometheus + Grafana) separately:

```bash
helm upgrade --install monitoring \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n monitoring \
  --create-namespace \
  -f charts/enterprise/scenarios/monitoring-another-namespace.yaml
```

**Scenario file:** `charts/enterprise/scenarios/monitoring-another-namespace.yaml`

Get Grafana ingress URL:

```bash
kubectl get ingress -n monitoring
```

**Monitored Components:**
- Gravitino (JVM metrics + custom metrics)
- OpenSearch (cluster health, indexing stats)
- Loki (ingestion rate, storage stats)
- Prometheus (server metrics)

### Using Private Registry

To use your own private registry instead of Docker Hub:

**Step 1:** Create custom values file `private-registry-values.yaml`:

```yaml
global:
  pullSecrets:
    registry: "https://your-registry.example.com"
    username: "your-username"
    password: "your-password"

gravitino:
  image:
    registry: your-registry.example.com
    repository: gravitino/enterprise-gravitino
    tag: "1.3.0"

enterpriseWeb:
  image:
    registry: your-registry.example.com
    repository: gravitino/enterprise-ui
    tag: "1.3.0"

trino:
  image:
    registry: your-registry.example.com
    repository: gravitino/trino
    tag: "1.3.0"

## Note: Ranger is deprecated and will be removed in a future release
ranger:
  image:
    registry: your-registry.example.com
    repository: gravitino/enterprise-ranger
    tag: "2.4.0"

marquez:
  marquez:
    image:
      registry: your-registry.example.com
      repository: gravitino/marquez
      tag: "0.48.0"
  web:
    image:
      registry: your-registry.example.com
      repository: gravitino/marquez-web
      tag: "0.48.0"

opensearch:
  image:
    repository: "your-registry.example.com/opensearch-with-analysis-ik"
    tag: "1.3.0"
```

**Step 2:** Install with custom registry:

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  -f private-registry-values.yaml \
  --set ingress-nginx.enabled=true \
  --set gravitino.license.key=<license-key>
```

## Configuration

### Database Backend Options

The chart supports three database deployment patterns:

#### 1. Default: Separate Databases (Recommended)

- **Gravitino + Marquez:** Share PostgreSQL instance (separate databases)
- **Ranger:** Uses dedicated MySQL instance (when enabled)
- **Configuration:** Default in `values.yaml`

```yaml
gravitino:
  postgresql:
    enabled: true  # Shared PostgreSQL for Gravitino + Marquez
  mysql:
    enabled: false

mysql:
  enabled: false  # Dedicated MySQL for Ranger (only when ranger.enabled=true)

marquez:
  postgresql:
    enabled: false  # Uses Gravitino's PostgreSQL
  marquez:
    inClusterDB:
      postgresql:
        enabled: true  # Points to Gravitino's PostgreSQL
```

**Note:** Ranger is deprecated and will be removed in a future release.

#### 2. Legacy: Shared MySQL (Deprecated)

⚠️ **Deprecated:** This pattern is used for Ranger integration, which will be removed in a future release.

- **Gravitino + Ranger:** Share MySQL instance
- **Marquez:** Uses separate PostgreSQL instance

```yaml
gravitino:
  mysql:
    enabled: true  # Shared MySQL for Gravitino + Ranger
  postgresql:
    enabled: false

mysql:
  enabled: false  # Not needed, using Gravitino's MySQL

ranger:
  enabled: true  # Ranger is deprecated
  inClusterDB:
    enabled: true  # Uses Gravitino's MySQL

marquez:
  postgresql:
    enabled: true  # Separate PostgreSQL for Marquez
```

**Scenario file:** `charts/enterprise/scenarios/in-cluster-mysql.yaml`

#### 3. External Databases

All components use external managed databases. See [Configure an External Database](#configure-an-external-database) section below.

### Image Tag Configuration

#### Production Images (values.yaml)

Default tags in `values.yaml` point to official release images:

| Component | Default Registry | Default Tag |
|-----------|------------------|-------------|
| Gravitino | `docker.io/datastratosandbox/enterprise` | `enterprise-gravitino-1.3.0` |
| Enterprise UI | `docker.io/datastratosandbox/enterprise` | `ui-1.3.0-SNAPSHOT-...` |
| Trino | `docker.io/datastratosandbox/enterprise` | `trino-1.3.0-SNAPSHOT-...` |
| Ranger (deprecated) | `docker.io/datastratosandbox/enterprise` | `enterprise-ranger-2.4.0-openshift-1` |
| Marquez | `docker.io/datastratosandbox/enterprise` | `0.48.0` |
| OpenSearch | `docker.io/datastratosandbox/opensearch-with-analysis-ik` | `1.3.0-SNAPSHOT-...` |

#### CI Test Images (ci-overrides.yaml)

CI tests use community database images and public image tags via `charts/enterprise/scenarios/ci-overrides.yaml`.

**When to use:**
- Testing with community PostgreSQL/MySQL images
- Kind/local-path clusters requiring `volumePermissions`
- Development/CI environments

**Example:**

```bash
helm upgrade --install enterprise ./charts/enterprise \
  -n datastrato --create-namespace \
  --set gravitino.license.key=<license-key> \
  -f charts/enterprise/scenarios/ci-overrides.yaml \
  -f charts/enterprise/scenarios/in-cluster-postgresql.yaml
```

### Enable SCIM Provisioning

SCIM (System for Cross-domain Identity Management) enables automated user and group provisioning from your IdP (Keycloak, Okta, Azure AD).

#### Basic SCIM Setup

```bash
helm upgrade --install enterprise ./charts/enterprise \
  -n datastrato --create-namespace \
  --set gravitino.scim.enabled=true \
  --set gravitino.license.key=<license-key>
```

#### SCIM + OAuth Authentication

For production use with Keycloak OAuth:

```bash
helm upgrade --install enterprise ./charts/enterprise \
  -n datastrato --create-namespace \
  -f charts/enterprise/scenarios/authentication-keycloak.yaml \
  -f charts/enterprise/scenarios/scim-oauth.yaml \
  --set gravitino.license.key=<license-key>
```

#### SCIM Configuration Details

| Setting | Description |
|---------|-------------|
| **SCIM Endpoint** | `http://<host>:9201/scim/v2/metalakes/<metalake>` |
| **SCIM Port** | 9201 (HTTP, add TLS if needed) |
| **Ingress Support** | Enable with `gravitino.scim.ingress.enabled=true` |
| **Token Admin** | `POST/DELETE /api/metalakes/<metalake>/scim/tokens` (port 8090) |
| **Group Mapping** | Automatically writes `ScimOAuthPrincipalMapper` when enabled |
| **Schema Support** | Enterprise schema applied automatically for image versions 1.3+ |

**Requirements:**
- Gravitino license key
- Database backend with enterprise schema (auto-applied on init)
- IdP with SCIM client support (Keycloak, Okta, Azure AD, etc.)

### Using Community Database Images

The chart supports two database image flavors for PostgreSQL and MySQL:

| Flavor | PostgreSQL Image | MySQL Image | Use Case |
|--------|------------------|-------------|----------|
| **redhat** (default) | `registry.redhat.io/rhel10/postgresql-16` | `registry.redhat.io/rhel10/mysql-84` | OpenShift, Red Hat certified environments |
| **community** | `docker.io/library/postgres` | `docker.io/library/mysql` | Development, CI, non-OpenShift clusters |

#### ⚠️ Critical: Security Context Requirements

When switching to `flavor: community`, you **MUST** set `podSecurityContext.fsGroup: 999` explicitly. The community images run as UID/GID 999, but the chart defaults to Red Hat's UID/GID (26 for PostgreSQL, 27 for MySQL), causing PVC permission errors.

#### Community PostgreSQL Configuration

**Minimum required values:**

```yaml
gravitino:
  postgresql:
    image:
      flavor: community
    podSecurityContext:
      fsGroup: 999  # ← REQUIRED for community images
    containerSecurityContext:
      runAsNonRoot: true
      runAsUser: 999
      allowPrivilegeEscalation: false
      capabilities:
        drop:
          - ALL
      seccompProfile:
        type: RuntimeDefault
```

#### Community MySQL Configuration

**For Gravitino's MySQL backend:**

```yaml
gravitino:
  mysql:
    image:
      flavor: community
    podSecurityContext:
      fsGroup: 999  # ← REQUIRED for community images
    containerSecurityContext:
      runAsNonRoot: true
      runAsUser: 999
      allowPrivilegeEscalation: false
      capabilities:
        drop:
          - ALL
      seccompProfile:
        type: RuntimeDefault
```

**For Ranger's dedicated MySQL (top-level):**

```yaml
mysql:
  image:
    flavor: community
  podSecurityContext:
    fsGroup: 999  # ← REQUIRED for community images
  containerSecurityContext:
    runAsNonRoot: true
    runAsUser: 999
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault
```

#### Kind / Local-Path Clusters

On clusters whose storage provisioner does **not** honor `fsGroup` (e.g., `rancher.io/local-path` in kind), also enable `volumePermissions`:

```yaml
gravitino:
  postgresql:
    image:
      flavor: community
    podSecurityContext:
      fsGroup: 999
    containerSecurityContext:
      runAsNonRoot: true
      runAsUser: 999
      allowPrivilegeEscalation: false
      capabilities:
        drop:
          - ALL
      seccompProfile:
        type: RuntimeDefault
    volumePermissions:
      enabled: true  # ← Required for kind/local-path
```

#### Ready-to-Use Scenario Files

Pre-configured scenario files with all required settings:

| Scenario File | Purpose |
|--------------|---------|
| `charts/datastrato-gravitino/resources/scenarios/postgresql-community-values.yaml` | Community PostgreSQL for standalone Gravitino chart |
| `charts/datastrato-gravitino/resources/scenarios/mysql-community-values.yaml` | Community MySQL for standalone Gravitino chart |
| `charts/enterprise/scenarios/ci-overrides.yaml` | CI testing: community DB images + volumePermissions + public Docker Hub tags |
| `charts/enterprise/scenarios/enterprise-gravitino-only.yaml` | Gravitino-only with community PostgreSQL (via ci-overrides) |
| `charts/enterprise/scenarios/in-cluster-postgresql.yaml` | Community PostgreSQL shared by Gravitino + Marquez |
| `charts/enterprise/scenarios/in-cluster-mysql.yaml` | Community MySQL shared by Gravitino + Ranger |

**Example using scenario file:**

```bash
helm upgrade --install enterprise ./charts/enterprise \
  -n datastrato --create-namespace \
  --set gravitino.license.key=<license-key> \
  -f charts/enterprise/scenarios/ci-overrides.yaml \
  -f charts/enterprise/scenarios/in-cluster-postgresql.yaml
```

### Overriding Image Tags for Testing

When testing specific image versions (e.g., CI builds or hotfixes), override image tags via `--set` without modifying `values.yaml`:

#### Single Component Override

```bash
# Test a specific Gravitino build
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato --create-namespace \
  --set gravitino.image.tag=enterprise-gravitino-1.3.0-test-20260724 \
  --set gravitino.license.key=<license-key> \
  --set global.pullSecrets.password=<dockerhub-password>
```

#### Multiple Component Overrides

```bash
# Test multiple custom builds at once
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato --create-namespace \
  --set gravitino.image.tag=enterprise-gravitino-1.3.0-test \
  --set enterpriseWeb.image.tag=ui-1.3.0-test \
  --set ranger.image.tag=enterprise-ranger-2.4.0-test \
  --set trino.image.tag=trino-1.3.0-test \
  --set marquez.marquez.image.tag=0.48.0-test \
  --set marquez.web.image.tag=0.48.0-test \
  --set gravitino.license.key=<license-key> \
  --set global.pullSecrets.password=<dockerhub-password>
```

#### Available Image Tag Parameters

| Component | Helm Parameter |
|-----------|----------------|
| Gravitino | `gravitino.image.tag` |
| Enterprise UI | `enterpriseWeb.image.tag` |
| Trino | `trino.image.tag` |
| Ranger (deprecated) | `ranger.image.tag` |
| Marquez (API) | `marquez.marquez.image.tag` |
| Marquez (Web) | `marquez.web.image.tag` |
| OpenSearch | `opensearch.image.tag` |
| MySQL | `mysql.image.redhat.tag` or `mysql.image.community.tag` |
| PostgreSQL | `gravitino.postgresql.image.redhat.tag` or `gravitino.postgresql.image.community.tag` |

**Note:** This is the same mechanism used by the CI workflow's `workflow_dispatch` event to test specific image builds without code changes.

### Configure an External Database

To disable the MySQL component and use an external database host instead, configure the following in your Helm values.

> **Prerequisites — External databases**
>
> When using external databases, the init containers that create users, databases, and initialize schemas are **not executed**. You must manually prepare all databases before installing the chart.
>
> #### 1. Gravitino (External MySQL or PostgreSQL)
>
> When both `gravitino.mysql.enabled` and `gravitino.postgresql.enabled` are `false`, the Gravitino init container is skipped. The database, user, **and schema** must all be created manually.
>
> Create the user and database:
>
> ```sql
> CREATE USER IF NOT EXISTS 'gravitino'@'%' IDENTIFIED BY '<jdbcPassword>';
> CREATE DATABASE IF NOT EXISTS gravitino;
> GRANT ALL PRIVILEGES ON gravitino.* TO 'gravitino'@'%';
> FLUSH PRIVILEGES;
> ```
>
> Initialize the schema by extracting and running the SQL script bundled in the Gravitino image:
>
> ```bash
> # Copy schema scripts out of the Gravitino image
> docker run --rm -v /tmp/gravitino-scripts:/out \
>   <gravitino-image> cp -r /opt/gravitino/scripts /out
>
> # Run the schema file matching your version (e.g. 1.4.0)
> VERSION=<gravitino-version>
> mysql -h <host> -u gravitino -p<jdbcPassword> gravitino \
>   < /tmp/gravitino-scripts/scripts/mysql/schema-${VERSION}-mysql.sql
> ```
>
> Replace `gravitino` (user/database), `<jdbcPassword>`, and `<gravitino-version>` with the values in `gravitino.entity.jdbcUser`, `gravitino.entity.jdbcPassword`, and the image tag in `gravitino.image.tag`.
>
> #### 2. Ranger (External MySQL) - ⚠️ Deprecated
>
> **Note:** Ranger is deprecated and will be removed in a future chart release. This section is provided for existing deployments only.
>
> When `ranger.inClusterDB.enabled` is `false`, the Ranger init container is skipped. Ranger's internal `setup.sh` will create the schema automatically, but the user and database must exist and the `dbRootUser` must have `CREATE DATABASE` privileges:
>
> ```sql
> CREATE USER IF NOT EXISTS 'rangeradmin'@'%' IDENTIFIED BY '<rangerAdminPassword>';
> ALTER USER IF EXISTS 'rangeradmin'@'%' IDENTIFIED BY '<rangerAdminPassword>';
> CREATE DATABASE IF NOT EXISTS ranger;
> GRANT ALL PRIVILEGES ON ranger.* TO 'rangeradmin'@'%';
> FLUSH PRIVILEGES;
> ```
>
> Note: MySQL 8.4+ no longer loads the `mysql_native_password` plugin by default
> (it is removed entirely in MySQL 9.0), so the statements above rely on the
> server's default plugin (`caching_sha2_password`), which is fully supported by
> the mysql-connector-java driver bundled with Ranger.
>
> Replace `<rangerAdminPassword>` with the value in `ranger.rangerAdminPassword`.
>
> #### 3. Marquez (External PostgreSQL)
>
> When `marquez.postgresql.enabled` is `false`, the Marquez init container is skipped. Marquez runs schema migrations automatically on startup (`MIGRATE_ON_STARTUP=true`), but the database and user must exist with sufficient privileges beforehand:
>
> ```sql
> CREATE USER buendia WITH PASSWORD '<password>';
> CREATE DATABASE marquez OWNER buendia;
> \c marquez
> GRANT ALL ON SCHEMA public TO buendia;
> ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO buendia;
> ```
>
> Replace `buendia`, `<password>`, and `marquez` with the values in `marquez.marquez.db.user`, `marquez.marquez.db.password`, and `marquez.marquez.db.name`.

cus-external-db-value.yaml

```yaml
gravitino:
  mysql:
    enabled: false
  entity:
    jdbcUrl: "jdbc:mysql://<mysql-host>:3306/gravitino"
    jdbcDriver: "com.mysql.cj.jdbc.Driver"
    jdbcUser: "<gravitino-db-user>"
    jdbcPassword: "<gravitino-db-password>"

ranger:
  inClusterDB:
    enabled: false
  externalDatabaseHost: "<mysql-host>"
  rangerAdminPassword: "<ranger-admin-password>"
  dbRootUser: "<db-root-user>"
  dbRootPassword: "<db-root-password>"

marquez:
  postgresql:
    enabled: false
  marquez:
    db:
      host: "<postgresql-host>"
      port: 5432
      name: "<marquez-db-name>"
      user: "<marquez-db-user>"
      password: "<marquez-db-password>"
```

```bash
helm upgrade --install enterprise oci://${REGISTRY}/${REPOSITORY}/enterprise-helm --version ${CHART_VERSION} -n datastrato --create-namespace -f cus-external-db-value.yaml
```

### Enable Logging and Monitoring (All-in-One)

Deploy full observability stack in a single namespace:

```bash
helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  --set ingress-nginx.enabled=true \
  --set logging-output-loki.enabled=true \
  --set monitoring.enabled=true \
  --set global.pullSecrets.password=<dockerhub-password> \
  --set gravitino.license.key=<license-key>
```

**Components:**
- **Fluent-bit:** DaemonSet log collector (tails pod logs)
- **Loki:** Log aggregation and storage
- **Prometheus:** Metrics collection and storage
- **Grafana:** Visualization dashboard (includes Loki data source)

Access Grafana:

```bash
kubectl get ingress -n datastrato
# Default: http://grafana.example.com
```

### Mount Shared Volumes (Environments Without Dynamic Provisioning)

For clusters without a PV provisioner (or when using NFS/hostPath storage), manually create PVs and configure the chart to use them.

#### Example: Fluent-bit with NFS Storage

**Step 1:** Create custom values file `fluent-bit-nfs-values.yaml`:

```yaml
logging:
  enabled: true

fluent-bit-file:
  daemonSetVolumes:
    - name: varlog
      hostPath:
        path: /var/log
    - name: varlibdockercontainers
      hostPath:
        path: /var/lib/docker/containers
    - name: etcmachineid
      hostPath:
        path: /etc/machine-id
        type: File
  daemonSetVolumeMounts:
    - name: varlog
      mountPath: /var/log
    - name: varlibdockercontainers
      mountPath: /var/lib/docker/containers
      readOnly: true
    - name: etcmachineid
      mountPath: /etc/machine-id
      readOnly: true
  extraVolumeMounts:
    - name: output-log
      mountPath: /tmp/logs
  extraVolumes:
    - name: output-log
      persistentVolumeClaim:
        claimName: log-pvc  # ← Pre-created PVC
  config:
    outputs: |
      [OUTPUT]
          Name file
          Match *
          Path /tmp/logs
          Mkdir true
```

**Step 2:** Create PV and PVC for log storage (`log-pv-pvc.yaml`):

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: log-pv
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  nfs:
    server: 172.31.42.16
    path: /nfs/shared/logs
  volumeMode: Filesystem
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: log-pvc
  namespace: datastrato
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
  storageClassName: ""  # ← Empty for static binding
  volumeMode: Filesystem
```

**Step 3:** Apply resources and install:

```bash
kubectl apply -f log-pv-pvc.yaml

helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  -f fluent-bit-nfs-values.yaml \
  --set gravitino.license.key=<license-key> \
  --set global.pullSecrets.password=<dockerhub-password>
```

#### Example: Loki + Minio with NFS Storage

**Step 1:** Create custom values file `loki-nfs-values.yaml`:

```yaml
logging-output-loki:
  enabled: true

loki:
  singleBinary:
    persistence:
      enabled: true
      size: 10Gi
      storageClass: "nfs"  # ← Custom storage class
  minio:
    enabled: true
    persistence:
      enabled: true
      storageClass: "nfs"
      size: 5Gi
```

**Step 2:** Create PVs for Loki and Minio (`loki-pv.yaml`):

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: loki-pv
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: nfs
  nfs:
    server: 172.31.42.16
    path: /nfs/shared/loki
  volumeMode: Filesystem
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: minio-pv-1
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: nfs
  nfs:
    server: 172.31.42.16
    path: /nfs/shared/minio-1
  volumeMode: Filesystem
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: minio-pv-2
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: nfs
  nfs:
    server: 172.31.42.16
    path: /nfs/shared/minio-2
  volumeMode: Filesystem
```

**Step 3:** Apply PVs and install:

```bash
kubectl apply -f loki-pv.yaml

helm upgrade --install enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n datastrato \
  --create-namespace \
  -f loki-nfs-values.yaml \
  --set gravitino.license.key=<license-key> \
  --set global.pullSecrets.password=<dockerhub-password>
```

**Note:** This pattern applies to any component requiring persistent storage (databases, OpenSearch, Prometheus). Replace NFS details with your storage backend (Ceph, GlusterFS, hostPath, etc.).

### Upgrade Existing Release

When upgrading, the MySQL/PostgreSQL subcharts require existing passwords. Without them, the upgrade fails with a `PASSWORDS ERROR`.

#### Step 1: Retrieve Existing Passwords

**For MySQL (Ranger's database):**

```bash
export MYSQL_ROOT_PASSWORD=$(kubectl get secret -n <namespace> <release>-mysql -o jsonpath="{.data.mysql-root-password}" | base64 -d)
export MYSQL_PASSWORD=$(kubectl get secret -n <namespace> <release>-mysql -o jsonpath="{.data.mysql-password}" | base64 -d)
```

**For PostgreSQL (Gravitino + Marquez shared database):**

```bash
export POSTGRESQL_PASSWORD=$(kubectl get secret -n <namespace> <release>-gravitino-postgresql -o jsonpath="{.data.password}" | base64 -d)
```

#### Step 2: Run Upgrade

**Basic upgrade:**

```bash
helm upgrade enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n <namespace> \
  --set mysql.auth.rootPassword=$MYSQL_ROOT_PASSWORD \
  --set mysql.auth.password=$MYSQL_PASSWORD \
  --set gravitino.postgresql.auth.password=$POSTGRESQL_PASSWORD \
  --set gravitino.license.key=<license-key>
```

**With custom values file:**

```bash
helm upgrade enterprise \
  oci://${REGISTRY}/${REPOSITORY}/enterprise-helm \
  --version ${CHART_VERSION} \
  -n <namespace> \
  -f <values-file> \
  --set mysql.auth.rootPassword=$MYSQL_ROOT_PASSWORD \
  --set mysql.auth.password=$MYSQL_PASSWORD \
  --set gravitino.postgresql.auth.password=$POSTGRESQL_PASSWORD \
  --set gravitino.license.key=<license-key>
```

**Note:** If using only one database type (MySQL or PostgreSQL), only set the passwords for the active database.

## Uninstall

### Remove Helm Release

```bash
helm uninstall <release-name> -n <namespace>
```

### Cleanup CRDs (Monitoring Components)

If monitoring was enabled, CRDs are not removed automatically:

```bash
kubectl delete crd alertmanagerconfigs.monitoring.coreos.com
kubectl delete crd alertmanagers.monitoring.coreos.com
kubectl delete crd podmonitors.monitoring.coreos.com
kubectl delete crd probes.monitoring.coreos.com
kubectl delete crd prometheusagents.monitoring.coreos.com
kubectl delete crd prometheuses.monitoring.coreos.com
kubectl delete crd prometheusrules.monitoring.coreos.com
kubectl delete crd scrapeconfigs.monitoring.coreos.com
kubectl delete crd servicemonitors.monitoring.coreos.com
kubectl delete crd thanosrulers.monitoring.coreos.com
```

### Cleanup Persistent Volumes

PVCs are not deleted automatically. Remove them manually:

```bash
# List PVCs
kubectl get pvc -n <namespace>

# Delete specific PVC
kubectl delete pvc <pvc-name> -n <namespace>

# Delete all PVCs in namespace
kubectl delete pvc --all -n <namespace>
```

**Warning:** Deleting PVCs will **permanently delete** all database data, logs, and metrics.

## Troubleshooting

### Helm Command Hangs

**Symptom:** `helm install` or `helm upgrade` hangs indefinitely.

**Cause:** The Minio post-install job (`<release>-minio-post-job`) may not have been deleted after completion.

**Solution:**

```bash
# List jobs
kubectl get jobs -n <namespace>

# Delete the post-job manually
kubectl delete job <release>-minio-post-job -n <namespace>
```

### Database Pod Fails with "Permission denied"

**Symptom:** PostgreSQL or MySQL pod crashes with:
```
initdb: error: could not change permissions of directory "/var/lib/postgresql/data": Permission denied
```

**Cause:** Using community database images (`flavor: community`) without setting `podSecurityContext.fsGroup: 999`.

**Solution:** See [Using Community Database Images](#using-community-database-images) section. Set `fsGroup: 999` explicitly.

### OpenSearch Not Responding

**Symptom:** OpenSearch pod is running but not responding to requests.

**Verification:**

```bash
# Get OpenSearch pod
kubectl get pods -n <namespace> -l app.kubernetes.io/name=opensearch

# Check OpenSearch health (replace pod IP with actual)
curl -u admin:admin -k http://<opensearch-pod-ip>:9200

# Expected response:
{
  "name" : "opensearch-cluster-master-0",
  "cluster_name" : "opensearch-cluster",
  "version" : { ... },
  "tagline" : "The OpenSearch Project: https://opensearch.org/"
}
```

**Common issues:**
- Check logs: `kubectl logs <opensearch-pod> -n <namespace>`
- Verify memory limits are sufficient (default: 2Gi)
- Check PVC is bound: `kubectl get pvc -n <namespace>`

### Ingress Not Working

**Symptom:** Cannot access services via ingress hosts.

**Verification:**

```bash
# Check ingress resources
kubectl get ingress -n <namespace>

# Check ingress controller pods
kubectl get pods -n ingress-nginx
```

**Solutions:**
- **Minikube:** Run `minikube addons enable ingress`
- **OrbStack/Kind/EKS:** Install with `--set ingress-nginx.enabled=true`
- **DNS:** Add ingress ADDRESS to `/etc/hosts` (local) or configure DNS/Route53 (production)

### Pod Stuck in Pending

**Symptom:** Pods remain in `Pending` state.

**Cause:** PVC cannot be bound (no PV available or no storage provisioner).

**Solution:**

```bash
# Check PVC status
kubectl get pvc -n <namespace>

# Check PV availability
kubectl get pv

# For clusters without provisioners, manually create PVs
# See: Mount Shared Volumes section
```

### Image Pull Errors

**Symptom:**
```
Failed to pull image: unauthorized: authentication required
```

**Cause:** Missing or incorrect Docker Hub credentials.

**Solution:**

```bash
# Verify secret exists
kubectl get secret image-pull-secret -n <namespace>

# Recreate with correct credentials
helm upgrade <release> ... \
  --set global.pullSecrets.password=<correct-dockerhub-password>
```

### Database Connection Failures

**Symptom:** Gravitino logs show:
```
java.sql.SQLException: Access denied for user 'gravitino'@'%'
```

**Causes:**
1. Database pod not ready yet (wait for init container to complete)
2. Wrong credentials in external database configuration
3. External database user/schema not created manually

**Solution:**

For external databases, verify:
1. User and database exist
2. User has ALL PRIVILEGES on the database
3. Schema is initialized (see [Configure an External Database](#configure-an-external-database))

```bash
# Check database pod logs
kubectl logs <database-pod> -n <namespace>

# Check Gravitino logs
kubectl logs <gravitino-pod> -n <namespace>
```
