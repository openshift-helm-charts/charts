# RedHat Certification Fix for OpenSearch

## Problem

The OpenSearch chart uses `busybox:latest` as the default image for init containers (`persistence` and `sysctlInit`). This violates RedHat certification requirements because:

1. **Non-UBI base image**: `busybox` is not a RedHat Universal Base Image (UBI)
2. **Version control**: Using `latest` tag violates certification requirements for reproducible builds
3. **Security compliance**: Non-certified images may fail security scans required for RedHat certification

## Impact

When deploying the enterprise chart with OpenSearch enabled, the following init containers use `busybox:latest`:

```bash
# Example from pod inspection:
kubectl get pod opensearch-cluster-master-0 -n redhat-test -o yaml | grep "image:"
image: datastratosandbox/opensearch-with-analysis-ik:1.3.0-SNAPSHOT-20260720032632
image: busybox:latest  # <-- This causes certification issues
```

This affects:
- RedHat OpenShift certification
- Security compliance audits
- Enterprise procurement processes
- Production deployments requiring certified images

## Solution

Override the default `busybox` images with RedHat certified UBI images in `values.yaml`:

```yaml
opensearch:
  enabled: true
  ## Override init container images to use RedHat certified UBI images instead of busybox
  ## This is required for RedHat certification compliance
  persistence:
    image: registry.access.redhat.com/ubi9/ubi-micro
    imageTag: "9.4"
  sysctlInit:
    enabled: false
    image: registry.access.redhat.com/ubi9/ubi-micro
    imageTag: "9.4"
```

## UBI Image Selection

We use `ubi9/ubi-micro` because:

1. **Minimal footprint**: Smallest UBI variant, suitable for init containers
2. **RedHat certified**: Official RedHat Universal Base Image
3. **Security**: Regularly updated with security patches
4. **Compatibility**: Compatible with OpenShift restricted SCC

Alternative UBI images:
- `ubi9/ubi-minimal`: Includes microdnf package manager (larger, ~100MB)
- `ubi9/ubi-init`: Full systemd support (largest, not needed for init containers)

## Verification

To verify the fix is working:

1. Install the chart:
```bash
helm install enterprise ./charts/enterprise -n test-namespace
```

2. Check the init container images:
```bash
kubectl get pod opensearch-cluster-master-0 -n test-namespace -o yaml | grep "image:"
```

Expected output should show:
```
image: datastratosandbox/opensearch-with-analysis-ik:1.3.0-SNAPSHOT-20260720032632
image: registry.access.redhat.com/ubi9/ubi-micro:9.4  # <-- Fixed
```

## Additional Notes

### sysctlInit Container

The `sysctlInit.enabled` is set to `false` because:
- OpenShift restricted SCC does not allow privileged containers
- The sysctl init container requires privileged access
- If you need to set sysctl parameters, you must:
  1. Use a less restrictive SCC
  2. Set `sysctlInit.enabled: true`
  3. Grant the necessary RBAC permissions

### Registry Access

The UBI images are available from:
- `registry.access.redhat.com` (public, no authentication required for UBI)
- `registry.redhat.io` (requires RedHat subscription)

No additional pull secrets are needed for UBI images from `registry.access.redhat.com`.

## References

- [RedHat Universal Base Images](https://developers.redhat.com/products/rhel/ubi)
- [RedHat OpenShift Certification Policy](https://docs.redhat.com/en/documentation/red_hat_software_certification/2026/html/red_hat_openshift_software_certification_policy_guide/)
- [UBI Image Catalog](https://catalog.redhat.com/software/containers/search?q=ubi)
- [OpenSearch Helm Chart](https://github.com/opensearch-project/helm-charts)

## Change History

- 2026-07-24: Initial fix to replace busybox with ubi-micro for RedHat certification compliance
