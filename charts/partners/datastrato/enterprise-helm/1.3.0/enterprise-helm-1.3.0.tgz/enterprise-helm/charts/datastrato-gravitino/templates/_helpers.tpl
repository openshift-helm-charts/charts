{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "datastrato-gravitino.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "datastrato-gravitino.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "datastrato-gravitino.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels (Kubernetes recommended labels)
*/}}
{{- define "datastrato-gravitino.labels" -}}
app.kubernetes.io/name: {{ include "datastrato-gravitino.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "datastrato-gravitino.chart" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "datastrato-gravitino.selectorLabels" -}}
app.kubernetes.io/name: {{ include "datastrato-gravitino.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Return the labels applied to the Gravitino Deployment pod.
*/}}
{{- define "datastrato-gravitino.gravitino.labels" -}}
{{- include "datastrato-gravitino.labels" . }}
app.kubernetes.io/component: gravitino
{{- end -}}

{{/*
Return the selector labels applied to the Gravitino Deployment pod.
*/}}
{{- define "datastrato-gravitino.gravitino.selectorLabels" -}}
{{- include "datastrato-gravitino.selectorLabels" . }}
app.kubernetes.io/component: gravitino
{{- end -}}

{{/*
Define the namespace
*/}}
{{- define "datastrato-gravitino.namespace" -}}
    {{- .Release.Namespace -}}
{{- end -}}

{{/*
Return an image reference for the provided image root and global values.
*/}}
{{- define "datastrato-gravitino.imageReference" -}}
{{- $registry := coalesce .global.imageRegistry .imageRoot.registry -}}
{{- $repository := required "image repository is required" .imageRoot.repository -}}
{{- if .imageRoot.digest -}}
{{- if $registry -}}
{{- printf "%s/%s@%s" $registry $repository .imageRoot.digest -}}
{{- else -}}
{{- printf "%s@%s" $repository .imageRoot.digest -}}
{{- end -}}
{{- else -}}
{{- $tag := required "image tag is required" .imageRoot.tag -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper Gravitino Enterprise image name
*/}}
{{- define "datastrato-gravitino.image" -}}
  {{- include "datastrato-gravitino.imageReference" (dict "imageRoot" .Values.image "global" .Values.global) -}}
{{- end -}}

{{/*
Return the image settings block (registry/repository/tag/pullPolicy) matching
mysql.image.flavor ("redhat" or "community").
*/}}
{{- define "datastrato-gravitino.mysql.imageRoot" -}}
{{- $flavor := .Values.mysql.image.flavor | default "redhat" -}}
{{- if eq $flavor "community" -}}
  {{- .Values.mysql.image.community | toYaml -}}
{{- else if eq $flavor "redhat" -}}
  {{- .Values.mysql.image.redhat | toYaml -}}
{{- else -}}
  {{- fail (printf "mysql.image.flavor must be \"redhat\" or \"community\", got %q" $flavor) -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper MySQL image name (used by the native MySQL StatefulSet,
the init-mysql initContainer, and the schema-init test).
*/}}
{{- define "datastrato-gravitino.init-mysql.image" -}}
{{- if .Values.mysql.enabled -}}
  {{- $imageRoot := include "datastrato-gravitino.mysql.imageRoot" . | fromYaml -}}
  {{- include "datastrato-gravitino.imageReference" (dict "imageRoot" $imageRoot "global" .Values.global) -}}
{{- end -}}
{{- end -}}

{{/*
Return "community" or "redhat" for the active MySQL image flavor.
*/}}
{{- define "datastrato-gravitino.mysql.flavor" -}}
{{- .Values.mysql.image.flavor | default "redhat" -}}
{{- end -}}

{{/*
Return the imagePullPolicy for the active MySQL image flavor.
*/}}
{{- define "datastrato-gravitino.mysql.pullPolicy" -}}
{{- $imageRoot := include "datastrato-gravitino.mysql.imageRoot" . | fromYaml -}}
{{- $imageRoot.pullPolicy | default "IfNotPresent" -}}
{{- end -}}

{{/*
Return the MySQL data directory path for the active image flavor.
The Red Hat rhel9/mysql-84 (sclorg) image stores data under
/var/lib/mysql/data, while the community mysql image expects
/var/lib/mysql directly.
*/}}
{{- define "datastrato-gravitino.mysql.dataDir" -}}
{{- if eq (include "datastrato-gravitino.mysql.flavor" .) "community" -}}
/var/lib/mysql
{{- else -}}
/var/lib/mysql/data
{{- end -}}
{{- end -}}

{{/*
Return the base resource name for the chart-managed MySQL StatefulSet,
Service, and default Secret.
*/}}
{{- define "datastrato-gravitino.mysql.fullname" -}}
{{- printf "%s-mysql" (include "datastrato-gravitino.fullname" .) -}}
{{- end -}}

{{/*
Return the labels applied to the MySQL StatefulSet pod.
*/}}
{{- define "datastrato-gravitino.mysql.labels" -}}
{{- include "datastrato-gravitino.labels" . }}
app.kubernetes.io/component: mysql
{{- end -}}

{{/*
Return the selector labels applied to the MySQL StatefulSet pod.
*/}}
{{- define "datastrato-gravitino.mysql.selectorLabels" -}}
{{- include "datastrato-gravitino.selectorLabels" . }}
app.kubernetes.io/component: mysql
{{- end -}}

{{/*
Return the name of the Secret that holds MySQL credentials.
*/}}
{{- define "datastrato-gravitino.mysql.secretName" -}}
{{- .Values.mysql.auth.existingSecret | default (include "datastrato-gravitino.mysql.fullname" .) -}}
{{- end -}}

{{/*
Return the image settings block (registry/repository/tag/pullPolicy) matching
postgresql.image.flavor ("redhat" or "community").
*/}}
{{- define "datastrato-gravitino.postgresql.imageRoot" -}}
{{- $flavor := .Values.postgresql.image.flavor | default "redhat" -}}
{{- if eq $flavor "community" -}}
  {{- .Values.postgresql.image.community | toYaml -}}
{{- else if eq $flavor "redhat" -}}
  {{- .Values.postgresql.image.redhat | toYaml -}}
{{- else -}}
  {{- fail (printf "postgresql.image.flavor must be \"redhat\" or \"community\", got %q" $flavor) -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper PostgreSQL image name (used by the native PostgreSQL
StatefulSet, the init-postgresql initContainer, and the schema-init test).
*/}}
{{- define "datastrato-gravitino.init-postgresql.image" -}}
{{- if .Values.postgresql.enabled -}}
  {{- $imageRoot := include "datastrato-gravitino.postgresql.imageRoot" . | fromYaml -}}
  {{- include "datastrato-gravitino.imageReference" (dict "imageRoot" $imageRoot "global" .Values.global) -}}
{{- end -}}
{{- end -}}

{{/*
Return "community" or "redhat" for the active PostgreSQL image flavor.
*/}}
{{- define "datastrato-gravitino.postgresql.flavor" -}}
{{- .Values.postgresql.image.flavor | default "redhat" -}}
{{- end -}}

{{/*
Return the imagePullPolicy for the active PostgreSQL image flavor.
*/}}
{{- define "datastrato-gravitino.postgresql.pullPolicy" -}}
{{- $imageRoot := include "datastrato-gravitino.postgresql.imageRoot" . | fromYaml -}}
{{- $imageRoot.pullPolicy | default "IfNotPresent" -}}
{{- end -}}

{{/*
Return the PostgreSQL data directory path for the active image flavor.
The Red Hat rhel9/postgresql-16 image stores data under /var/lib/pgsql/data,
while the community postgres image expects /var/lib/postgresql/data.
*/}}
{{- define "datastrato-gravitino.postgresql.dataDir" -}}
{{- if eq (include "datastrato-gravitino.postgresql.flavor" .) "community" -}}
/var/lib/postgresql/data
{{- else -}}
/var/lib/pgsql/data
{{- end -}}
{{- end -}}

{{/*
Return the base resource name for the chart-managed PostgreSQL StatefulSet,
Service, and default Secret.
*/}}
{{- define "datastrato-gravitino.postgresql.fullname" -}}
{{- printf "%s-postgresql" (include "datastrato-gravitino.fullname" .) -}}
{{- end -}}

{{/*
Return the labels applied to the PostgreSQL StatefulSet pod.
*/}}
{{- define "datastrato-gravitino.postgresql.labels" -}}
{{- include "datastrato-gravitino.labels" . }}
app.kubernetes.io/component: postgresql
{{- end -}}

{{/*
Return the selector labels applied to the PostgreSQL StatefulSet pod.
*/}}
{{- define "datastrato-gravitino.postgresql.selectorLabels" -}}
{{- include "datastrato-gravitino.selectorLabels" . }}
app.kubernetes.io/component: postgresql
{{- end -}}

{{/*
Return the name of the Secret that holds PostgreSQL credentials.
*/}}
{{- define "datastrato-gravitino.postgresql.secretName" -}}
{{- .Values.postgresql.auth.existingSecret | default (include "datastrato-gravitino.postgresql.fullname" .) -}}
{{- end -}}

{{/*
Generate Docker registry config JSON for pull secrets.
Merges the primary global.pullSecrets registry/username/password with any
entries in global.pullSecrets.additionalRegistries, so a single Secret can
authenticate against multiple registries (e.g. docker.io and
registry.redhat.io) at once.
*/}}
{{- define "datastrato-gravitino.dockerConfigJson" -}}
{{- $registries := list (dict "registry" .Values.global.pullSecrets.registry "username" .Values.global.pullSecrets.username "password" .Values.global.pullSecrets.password) -}}
{{- $registries = concat $registries (.Values.global.pullSecrets.additionalRegistries | default list) -}}
{
  "auths": {
    {{- range $index, $reg := $registries }}
    {{ $reg.registry | quote }}: {
      "username": {{ $reg.username | quote }},
      "password": {{ $reg.password | quote }},
      "auth": {{ printf "%s:%s" $reg.username $reg.password | b64enc | quote }}
    }{{ if lt (add1 $index) (len $registries) }},{{ end }}
    {{- end }}
  }
}
{{- end -}}

{{/*
Return the name of the Secret that holds the JDBC password for the active backend.
*/}}
{{- define "datastrato-gravitino.jdbcPasswordSecretName" -}}
{{- if .Values.mysql.enabled -}}
  {{- include "datastrato-gravitino.mysql.secretName" . -}}
{{- else if .Values.postgresql.enabled -}}
  {{- include "datastrato-gravitino.postgresql.secretName" . -}}
{{- else -}}
  {{- printf "%s-entity-store" (include "datastrato-gravitino.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return the key within the JDBC password Secret for the active backend.
*/}}
{{- define "datastrato-gravitino.jdbcPasswordSecretKey" -}}
{{- if .Values.mysql.enabled -}}
mysql-password
{{- else if .Values.postgresql.enabled -}}
password
{{- else -}}
jdbc-password
{{- end -}}
{{- end -}}

{{/*
Return the ServiceAccount name to use.
*/}}
{{- define "datastrato-gravitino.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
  {{- .Values.serviceAccount.name | default (include "datastrato-gravitino.fullname" .) -}}
{{- else -}}
  {{- .Values.serviceAccount.name | default "default" -}}
{{- end -}}
{{- end -}}

{{/*
Return "true" when SCIM provisioning is enabled via scim.enabled or auxService.names.
*/}}
{{- define "datastrato-gravitino.scimEnabled" -}}
{{- if or (and .Values.scim .Values.scim.enabled) (contains "scim" (.Values.auxService.names | default "")) -}}
true
{{- end -}}
{{- end -}}

{{/*
SCIM IdP listener port (gravitino.scim.httpPort / Service / shared Ingress).
*/}}
{{- define "datastrato-gravitino.scimHttpPort" -}}
{{- .Values.scim.httpPort | default 9201 -}}
{{- end -}}

{{/*
SCIM token admin REST feature package registered on the main server.
*/}}
{{- define "datastrato-gravitino.scimExtensionPackage" -}}
com.datastrato.gravitino.scim.web.rest.feature
{{- end -}}

{{/*
SCIM OAuth request-path filter FQCN.
*/}}
{{- define "datastrato-gravitino.scimOAuthRequestPathFilter" -}}
com.datastrato.gravitino.scim.basic.oauth.ScimOAuthRequestPathFilter
{{- end -}}

{{/*
SCIM OAuth principal mapper FQCN (loads groups from scim_user_group_rel).
*/}}
{{- define "datastrato-gravitino.scimOAuthPrincipalMapper" -}}
com.datastrato.gravitino.scim.basic.oauth.ScimOAuthPrincipalMapper
{{- end -}}

