# Datastrato Gravitino Enterprise Helm Chart

Datastrato Gravitino Enterprise — unified metadata catalog federation with data discovery, lineage, and fine-grained access control.

## What This Chart Deploys

- **Gravitino server** — the core metadata service
- **PostgreSQL** (default) or MySQL — configurable relational metadata backend
- **Iceberg REST catalog** — auxiliary service for Apache Iceberg (opt-in)
- **Lance REST service** — auxiliary service for Lance (opt-in)
- **SCIM 2.0 provisioning** — IdP user/group sync on port 9201 (opt-in)
- Optional: NetworkPolicy, ServiceMonitor, PersistentVolumeClaim

## Prerequisites

- Kubernetes >= 1.29 or OpenShift >= 4.16
- Helm >= 3.x
- A valid Datastrato license key
- Cluster resources: minimum 2 CPU, 4 GB memory (server + database)

## Quick Start

```bash
helm install gravitino ./datastrato-gravitino \
  --namespace gravitino --create-namespace \
  --set license.key="GRAV-XXXX-XXXX-XXXX"
```

This deploys Gravitino with:
- PostgreSQL as the metadata backend (persistent)
- Simple authentication enabled
- Authorization enabled
- Auto-generated admin password

### Retrieve the Admin Password

```bash
kubectl get secret gravitino-datastrato-gravitino-admin-credentials \
  -n gravitino \
  -o jsonpath='{.data.password}' | base64 -d; echo
```

Default username: `admin`

## Configuration

Key parameters (see `values.yaml` for the full list):

| Parameter                | Description                                               | Default            |
| ------------------------ | --------------------------------------------------------- | ------------------ |
| `license.key`            | Datastrato license key (required)                         | `""`               |
| `postgresql.enabled`     | Deploy PostgreSQL backend                                 | `true`             |
| `mysql.enabled`          | Deploy MySQL backend (mutually exclusive with PostgreSQL) | `false`            |
| `persistence.enabled`    | Enable persistent storage                                 | `true`             |
| `persistence.size`       | PVC size                                                  | `10Gi`             |
| `authenticators`         | Authentication mechanisms (comma-separated)               | `simple`           |
| `admin.username`         | Initial admin username                                    | `admin`            |
| `admin.password`         | Initial admin password (auto-generated if empty)          | `""`               |
| `authorization.enable`   | Enable authorization                                      | `true`             |
| `search.storageImpl`     | Search backend (`memory` or `opensearch`)                 | `memory`           |
| `serviceMonitor.enabled` | Create Prometheus ServiceMonitor                          | `false`            |
| `networkPolicy.enabled`  | Create NetworkPolicy                                      | `false`            |
| `ingress.enabled`        | Enable Ingress                                            | `false`            |
| `route.enabled`          | Enable OpenShift Route                                    | `false`            |
| `scim.enabled`           | Enable SCIM provisioning                                  | `false`            |
| `scim.httpPort`          | IdP SCIM listener port                                    | `9201`             |
| `scim.classpath`         | SCIM aux classpath under the image                        | `scim-server/libs` |
| `scim.ingress.enabled`   | Expose SCIM on shared Ingress/HTTPRoute                   | `false`            |
| `scim.ingress.host`      | Public hostname for SCIM base URL                         | `""`               |

### Metadata Backend

**PostgreSQL (default, Red Hat certified image):**

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX"
```

By default the in-chart PostgreSQL StatefulSet uses the Red Hat certified
`registry.redhat.io/rhel9/postgresql-16` image. This requires a
`registry.redhat.io` pull secret (Red Hat subscription/service account) —
see [Image Pull Secrets](#image-pull-secrets) below.

**PostgreSQL (community image, no Red Hat account required):**

For customers who don't have a Red Hat subscription, switch to the upstream
Docker Hub `postgres` image:

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set postgresql.image.flavor=community
```

**MySQL (default, Red Hat certified image):**

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set postgresql.enabled=false \
  --set mysql.enabled=true
```

By default the in-chart MySQL StatefulSet uses the Red Hat certified
`registry.redhat.io/rhel9/mysql-84` image. This requires a `registry.redhat.io`
pull secret (Red Hat subscription/service account) — see
[Image Pull Secrets](#image-pull-secrets) below.

**MySQL (community image, no Red Hat account required):**

For customers who don't have a Red Hat subscription, switch to the upstream
Docker Hub `mysql` image:

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set postgresql.enabled=false \
  --set mysql.enabled=true \
  --set mysql.image.flavor=community
```

**External database:**

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set postgresql.enabled=false \
  --set entity.jdbcUrl="jdbc:postgresql://mydb.example.com:5432/gravitino" \
  --set entity.jdbcDriver="org.postgresql.Driver" \
  --set entity.jdbcUser="gravitino" \
  --set entity.jdbcPassword="mypassword"
```

### Authentication

The default authenticator is `simple` (anonymous access). Switch to `basic` after UI supports basic auth.

To enable OAuth:

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set authenticators="simple\,oauth" \
  --set authenticator.oauth.serviceAudience="gravitino" \
  --set authenticator.oauth.jwksUri="https://keycloak.example.com/realms/myrealm/protocol/openid-connect/certs" \
  --set authenticator.oauth.provider="oidc" \
  --set authenticator.oauth.clientId="gravitino-client" \
  --set authenticator.oauth.authority="https://keycloak.example.com/realms/myrealm"
```

### SCIM provisioning

SCIM is disabled by default. Enabling it wires the aux listener on `scim.httpPort`
(default **9201**), registers token admin REST APIs on **8090**, and installs
`ScimOAuthPrincipalMapper` with empty `groupsFields` (required by the SCIM token
admin extension; used for OAuth group resolution when oauth is also enabled).
The Service/`extraExposePorts` entry and optional shared Ingress host stay in
sync with `scim.httpPort`.
Requires `ingress.enabled=true` when using `scim.ingress.enabled`
(classic Ingress, or Gateway API HTTPRoute when `ingress.type=gateway`).

OAuth authenticator is **not** required to enable SCIM. A common full stack still
layers oauth + SCIM:

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set authenticators=oauth \
  --set authenticator.oauth.serviceAudience="gravitino" \
  --set authenticator.oauth.jwksUri="https://keycloak.example.com/realms/myrealm/protocol/openid-connect/certs" \
  --set authenticator.oauth.provider="oidc" \
  --set authenticator.oauth.clientId="gravitino-client" \
  --set authenticator.oauth.authority="https://keycloak.example.com/realms/myrealm" \
  --set authenticator.oauth.tokenValidatorClass="org.apache.gravitino.server.authentication.JwksTokenValidator" \
  --set scim.enabled=true
```

Minimal SCIM enablement (no oauth authenticator):

```bash
helm install gravitino ./datastrato-gravitino \
  --set license.key="GRAV-XXXX" \
  --set scim.enabled=true
```

| Parameter              | Description                                         | Default            |
| ---------------------- | --------------------------------------------------- | ------------------ |
| `scim.enabled`         | Enable SCIM aux service + SCIM extension wiring     | `false`            |
| `scim.httpPort`        | IdP SCIM listener port                              | `9201`             |
| `scim.classpath`       | Aux classpath under the image                       | `scim-server/libs` |
| `scim.ingress.enabled` | Expose SCIM on shared Ingress/HTTPRoute             | `false`            |
| `scim.ingress.host`    | Public hostname for SCIM base URL                   | `""`               |

DB init always applies `scripts/enterprise/*/enterprise-schema-*.sql` for image
versions **1.3+** (same path as core schema init). SCIM tables are part of that
enterprise schema and are not gated on `scim.enabled`.

IdP SCIM base URL:

- Direct to the Service / `scim.httpPort` (default **9201**, cleartext HTTP unless you terminate TLS yourself):

```text
http://<host>:<scim.httpPort>/scim/v2/metalakes/<metalake>
```

- Via shared Ingress or Gateway HTTPRoute (`scim.ingress.enabled`, typically TLS on 443 — **do not** append `:9201`):

```text
https://<scim.ingress.host>/scim/v2/metalakes/<metalake>
```

Token admin (metalake owner, main server auth):

```text
/api/metalakes/<metalake>/scim/tokens
```

See also `charts/enterprise/scenarios/scim-oauth.yaml`.

### Image Pull Secrets

If either the main application image or the in-chart MySQL/PostgreSQL image
comes from a private/authenticated registry, the chart can auto-create a
single `kubernetes.io/dockerconfigjson` Secret and attach it to every pod
(`global.pullSecrets.create=true`, the default). This is commonly needed for:

- `docker.io` — if the application image is pulled from a private Docker Hub repository.
- `registry.redhat.io` — required when `mysql.image.flavor` or `postgresql.image.flavor` is `redhat` (the default).

Since a single deployment may need to pull from **both** registries at once,
credentials for additional registries can be merged into the same Secret via
`global.pullSecrets.additionalRegistries`:

```yaml
global:
  pullSecrets:
    create: true
    registry: "https://index.docker.io/v1/"
    username: "<docker-hub-username>"
    password: "<docker-hub-password-or-token>"
    additionalRegistries:
      - registry: registry.redhat.io
        username: "<redhat-username>"
        password: "<redhat-password-or-token>"
```

Alternatively, set `global.pullSecrets.create=false` and reference one or
more pre-existing Secrets via `global.imagePullSecrets`:

```yaml
global:
  imagePullSecrets:
    - name: docker-hub-pull-secret
    - name: redhat-registry-pull-secret
```

### Using External Secrets

All sensitive values support `existingSecret` to reference pre-created Kubernetes Secrets (compatible with External Secrets Operator, Sealed Secrets, Vault, etc.):

```yaml
license:
  existingSecret: "my-license-secret"   # key: license-key

admin:
  existingSecret: "my-admin-secret"     # keys: username, password (only used when authenticators includes "basic")

postgresql:
  auth:
    existingSecret: "my-pg-secret"      # key: password
```

## Production Considerations

- Use an external managed database (RDS, Cloud SQL) instead of the in-chart PostgreSQL
- Enable `networkPolicy` to restrict traffic
- Enable `serviceMonitor` for Prometheus observability
- Configure `ingress` or `route` with TLS for external access
- Set explicit `resources` (CPU/memory limits)
- Use `existingSecret` for all credentials rather than passing via `--set`

## Upgrading

```bash
helm upgrade gravitino ./datastrato-gravitino \
  --namespace gravitino \
  --set license.key="GRAV-XXXX"
```

Important:
- Chart-managed passwords (database, admin) are preserved automatically across upgrades (stored in Secrets with `helm.sh/resource-policy: keep`). When using `existingSecret`, credentials are managed externally and not touched by the chart.
- Schema migrations run automatically via init containers when the in-chart database is enabled (`mysql.enabled` or `postgresql.enabled`). For external databases, run migration scripts manually before upgrading.

## Uninstalling

```bash
helm uninstall gravitino --namespace gravitino
```

**What persists after uninstall:**
- PersistentVolumeClaims (delete manually if no longer needed)
- Secrets with `helm.sh/resource-policy: keep` (database passwords, admin credentials)

To fully clean up:

```bash
kubectl delete pvc -l app.kubernetes.io/instance=gravitino -n gravitino
kubectl delete secret -l app.kubernetes.io/instance=gravitino -n gravitino
```

## Customization

The chart provides these extension points (no need to fork templates):

| Extension Point                      | Purpose                                          |
| ------------------------------------ | ------------------------------------------------ |
| `extraVolumes` / `extraVolumeMounts` | Add volumes                                      |
| `env` / `envFrom`                    | Add environment variables                        |
| `podAnnotations` / `podLabels`       | Add pod metadata                                 |
| `additionalConfigItems`              | Add arbitrary gravitino.conf entries             |
| `extraInitContainers`                | Add custom init containers                       |
| `extraContainers`                    | Add sidecar containers                           |
| `extraManifests`                     | Render arbitrary Kubernetes resources            |
| `serviceAccount.annotations`         | Add IAM annotations (IRSA, Workload Identity)    |

If your customization cannot be expressed through these extension points, please file an issue so we can extend the chart.

## OpenShift Deployment

The chart runs under the `restricted-v2` SCC without modifications:

```bash
helm install gravitino ./datastrato-gravitino \
  --namespace gravitino --create-namespace \
  --set license.key="GRAV-XXXX" \
  --set route.enabled=true
```

## Links

- Documentation: https://datastrato.ai/docs
- Source: https://github.com/datastrato/enterprise-deployment
- Issues: https://github.com/datastrato/enterprise-deployment/issues
- Support: support@datastrato.com
