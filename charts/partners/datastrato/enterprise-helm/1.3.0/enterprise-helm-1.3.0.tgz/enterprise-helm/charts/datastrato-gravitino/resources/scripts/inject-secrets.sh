#!/bin/bash
# inject-secrets.sh
# Replaces credential placeholders in gravitino.conf with actual values from environment variables.
# Called by init.sh before starting the Gravitino server.

CONF_FILE="${GRAVITINO_HOME}/conf/gravitino.conf"

replace_placeholder() {
  local placeholder="$1"
  local env_var="$2"
  if [ -n "${env_var}" ]; then
    sed -i "s|${placeholder}|${env_var}|g" "$CONF_FILE"
  fi
}

# Entity store JDBC password (always present)
replace_placeholder "__GRAVITINO_JDBC_PASSWORD__" "${GRAVITINO_JDBC_PASSWORD:-}"

# Iceberg REST JDBC
replace_placeholder "__GRAVITINO_ICEBERG_JDBC_PASSWORD__" "${GRAVITINO_ICEBERG_JDBC_PASSWORD:-}"

# Iceberg REST S3
replace_placeholder "__GRAVITINO_ICEBERG_S3_ACCESS_KEY_ID__" "${GRAVITINO_ICEBERG_S3_ACCESS_KEY_ID:-}"
replace_placeholder "__GRAVITINO_ICEBERG_S3_SECRET_ACCESS_KEY__" "${GRAVITINO_ICEBERG_S3_SECRET_ACCESS_KEY:-}"

# Iceberg REST OSS
replace_placeholder "__GRAVITINO_ICEBERG_OSS_ACCESS_KEY_ID__" "${GRAVITINO_ICEBERG_OSS_ACCESS_KEY_ID:-}"
replace_placeholder "__GRAVITINO_ICEBERG_OSS_SECRET_ACCESS_KEY__" "${GRAVITINO_ICEBERG_OSS_SECRET_ACCESS_KEY:-}"

# Iceberg REST Azure
replace_placeholder "__GRAVITINO_ICEBERG_AZURE_STORAGE_ACCOUNT_KEY__" "${GRAVITINO_ICEBERG_AZURE_STORAGE_ACCOUNT_KEY:-}"
replace_placeholder "__GRAVITINO_ICEBERG_AZURE_CLIENT_SECRET__" "${GRAVITINO_ICEBERG_AZURE_CLIENT_SECRET:-}"

# OpenSearch
replace_placeholder "__GRAVITINO_OPENSEARCH_PASSWORD__" "${GRAVITINO_OPENSEARCH_PASSWORD:-}"
