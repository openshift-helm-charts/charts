{{/*
Expand the name of the chart.
*/}}
{{- define "enterprise.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "enterprise.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "enterprise.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "enterprise.labels" -}}
helm.sh/chart: {{ include "enterprise.chart" . }}
{{ include "enterprise.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "enterprise.selectorLabels" -}}
app.kubernetes.io/name: {{ include "enterprise.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{/*
annotations
*/}}
{{- define "enterprise.annotations" -}}
meta.helm.sh/release-name: {{ .Release.Name }}
meta.helm.sh/release-namespace: {{ .Release.Namespace }}
{{- end }}

{{/*
Fully-qualified service name for the Gravitino sub-chart.
The gravitino sub-chart hardcodes its service name via gravitino.service.name,
so we read that value directly instead of deriving it from the release name.
Falls back to "<release>-gravitino" when service.name is not set.
*/}}
{{- define "enterprise.gravitino.fullname" -}}
{{- .Values.gravitino.service.name | default (printf "%s-gravitino" .Release.Name) -}}
{{- end -}}

{{/*
Fully-qualified service name for the dedicated Ranger MySQL StatefulSet.
This resolves to "<fullnameOverride>-mysql" (e.g. "enterprise-mysql").
*/}}
{{- define "enterprise.mysql.fullname" -}}
{{- printf "%s-mysql" (include "enterprise.fullname" .) -}}
{{- end -}}

{{/*
Fully-qualified service name for the shared PostgreSQL sub-chart (under gravitino).
The gravitino subchart uses alias "gravitino", so its fullname is "<release>-gravitino".
The PostgreSQL StatefulSet is named "<gravitino-fullname>-postgresql".
*/}}
{{- define "enterprise.postgresql.fullname" -}}
{{- printf "%s-gravitino-postgresql" .Release.Name -}}
{{- end -}}

{{/*
Fully-qualified service name for the Marquez sub-chart.
No alias is declared for marquez in Chart.yaml, so its fullname is "<release>-marquez".
*/}}
{{- define "enterprise.marquez.fullname" -}}
{{- printf "%s-marquez" .Release.Name -}}
{{- end -}}

{{/*
Fully-qualified service name for the OpenSearch sub-chart.
The opensearch chart hardcodes its master service name as "opensearch-cluster-master"
regardless of release name, so we return that fixed value here.
If that chart ever changes its naming, update only this helper.
*/}}
{{- define "enterprise.opensearch.fullname" -}}
opensearch-cluster-master
{{- end -}}

{{/*
Fully-qualified service name for the Loki sub-chart.
Loki is declared with alias "loki" in Chart.yaml, so its fullname is "<release>-loki".
*/}}
{{- define "enterprise.loki.fullname" -}}
{{- printf "%s-loki" .Release.Name -}}
{{- end -}}

{{/*
Return the name of the Gravitino ConfigMap targeted by enterprise-web.
Supports Helm template expressions in enterpriseWeb.rbac.configMapName.
*/}}
{{- define "enterpriseWeb.gravitinoConfigMapName" -}}
{{- $tpl := default (include "enterprise.gravitino.fullname" .) .Values.enterpriseWeb.rbac.configMapName }}
{{- tpl $tpl . }}
{{- end -}}

{{/*
Return the name of the Secret that holds conf_versions database credentials.
*/}}
{{- define "enterpriseWeb.confVersionDbSecretName" -}}
{{- if .Values.enterpriseWeb.confVersionDb.name }}
{{- .Values.enterpriseWeb.confVersionDb.name }}
{{- else }}
{{- printf "%s-conf-version-db" (include "enterprise.fullname" .) }}
{{- end }}
{{- end -}}

{{/*
Return the name of the ServiceAccount to use for enterprise-web
*/}}
{{- define "enterpriseWeb.serviceAccountName" -}}
{{- if .Values.enterpriseWeb.serviceAccount.create }}
{{- default (printf "%s-web" (include "enterprise.fullname" .)) .Values.enterpriseWeb.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.enterpriseWeb.serviceAccount.name }}
{{- end }}
{{- end -}}

{{/*
Return the proper enterprise web image name
*/}}
{{- define "enterpriseWeb.image" -}}
{{- include "common.images.image" (dict "imageRoot" .Values.enterpriseWeb.image "global" .Values.global) -}}
{{- end -}}

{{/*
Return the proper Trino image name
*/}}
{{- define "trino.image" -}}
{{- include "common.images.image" (dict "imageRoot" .Values.trino.image "global" .Values.global) -}}
{{- end -}}

{{/*
Return the proper curl image name for the check in initContainer
*/}}
{{- define "init-curl.image" -}}
  {{- include "common.images.image" (dict "imageRoot" .Values.trino.initContainer.image "global" .Values.global) -}}
{{- end -}}

{{/*
Generate Docker registry config JSON for pull secrets.
Merges the primary global.pullSecrets registry/username/password with any
entries in global.pullSecrets.additionalRegistries, so a single Secret can
authenticate against multiple registries (e.g. the ECR registry and
docker.io/registry.redhat.io) at once.
*/}}
{{- define "docker.config.json" -}}
{{- $registries := list (dict "registry" .Values.global.pullSecrets.registry "username" .Values.global.pullSecrets.username "password" .Values.global.pullSecrets.password) -}}
{{- $registries = concat $registries (.Values.global.pullSecrets.additionalRegistries | default list) -}}
{
  "auths": {
    {{- range $index, $reg := $registries }}
    {{ $reg.registry | quote }}: {
      "username": {{ $reg.username | quote }},
      "password": {{ $reg.password | quote }},
      "auth": {{ printf "%s:%s" $reg.username $reg.password | b64enc | quote }}
    }{{ if lt (add1 $index) (len $registries) }},{{ end }}
    {{- end }}
  }
}
{{- end }}

{{/*
Return the merged imagePullSecrets list for all pods.
Combines:
  - global.imagePullSecrets  (manually-created Secrets, e.g. aws-ecr-pull-secret)
  - global.pullSecrets.name  (auto-generated Secret when pullSecrets.create=true,
                              merges primary registry + additionalRegistries so a
                              single Secret covers ECR, registry.redhat.io, etc.)
Duplicates are removed so the same Secret name is not listed twice.
Usage:
  {{- include "enterprise.imagePullSecrets" . | nindent 6 }}
*/}}
{{- define "enterprise.imagePullSecrets" -}}
{{- $seen := dict -}}
{{- $secrets := list -}}
{{- range .Values.global.imagePullSecrets -}}
  {{- if not (index $seen .name) -}}
    {{- $secrets = append $secrets . -}}
    {{- $_ := set $seen .name true -}}
  {{- end -}}
{{- end -}}
{{- if .Values.global.pullSecrets.create -}}
  {{- $name := .Values.global.pullSecrets.name -}}
  {{- if not (index $seen $name) -}}
    {{- $secrets = append $secrets (dict "name" $name) -}}
  {{- end -}}
{{- end -}}
{{- if $secrets -}}
imagePullSecrets:
  {{- toYaml $secrets | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
Return the proper Ranger image name
*/}}
{{- define "ranger.image" -}}
{{- include "common.images.image" (dict "imageRoot" .Values.ranger.image "global" .Values.global) -}}
{{- end -}}

{{/*
Return the proper MySQL image name for the init-mysql initContainer.
Priority:
  1. mysql.enabled (dedicated Ranger MySQL StatefulSet) → use mysql.image
  2. gravitino.mysql.enabled (legacy shared MySQL) → use gravitino.mysql.image
  3. Neither → returns empty (init container will not be created)

Both mysql.image and gravitino.mysql.image use the same "flavor" + "redhat"/"community"
structure (see datastrato-gravitino subchart). Resolve the active flavor block first.
*/}}
{{- define "enterprise.mysql.imageRoot" -}}
{{- $flavor := .Values.mysql.image.flavor | default "redhat" -}}
{{- if eq $flavor "community" -}}
  {{- .Values.mysql.image.community | toYaml -}}
{{- else -}}
  {{- .Values.mysql.image.redhat | toYaml -}}
{{- end -}}
{{- end -}}

{{- define "enterprise.mysql.image" -}}
{{- $imageRoot := include "enterprise.mysql.imageRoot" . | fromYaml -}}
{{- include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) -}}
{{- end -}}

{{/*
Return "community" or "redhat" for the active Ranger MySQL image flavor.
*/}}
{{- define "enterprise.mysql.flavor" -}}
{{- .Values.mysql.image.flavor | default "redhat" -}}
{{- end -}}

{{/*
Return the imagePullPolicy for the active Ranger MySQL image flavor.
*/}}
{{- define "enterprise.mysql.pullPolicy" -}}
{{- $imageRoot := include "enterprise.mysql.imageRoot" . | fromYaml -}}
{{- $imageRoot.pullPolicy | default "IfNotPresent" -}}
{{- end -}}

{{/*
Return the MySQL data directory path for the active Ranger MySQL image flavor.
The Red Hat rhel9/mysql-84 (sclorg) image stores data under /var/lib/mysql/data,
while the community mysql image expects /var/lib/mysql.
*/}}
{{- define "enterprise.mysql.dataDir" -}}
{{- if eq (include "enterprise.mysql.flavor" .) "community" -}}
/var/lib/mysql
{{- else -}}
/var/lib/mysql/data
{{- end -}}
{{- end -}}

{{/*
Return the name of the Secret that holds Ranger MySQL credentials.
*/}}
{{- define "enterprise.mysql.secretName" -}}
{{- .Values.mysql.auth.existingSecret | default (printf "%s-mysql" (include "enterprise.fullname" .)) -}}
{{- end -}}

{{/*
Return the proper MySQL init-container image for Ranger's init-mysql container.
Priority:
  1. mysql.enabled → use the dedicated Ranger MySQL image (enterprise.mysql.image)
  2. gravitino.mysql.enabled (legacy) → use gravitino.mysql.image
The init container runs mysql CLI to create the rangeradmin user, so the image
must be the same flavor as the running MySQL server.
*/}}
{{- define "ranger.init-mysql.imageRoot" -}}
{{- if .Values.mysql.enabled -}}
  {{- $flavor := .Values.mysql.image.flavor | default "redhat" -}}
  {{- if eq $flavor "community" -}}
    {{- .Values.mysql.image.community | toYaml -}}
  {{- else -}}
    {{- .Values.mysql.image.redhat | toYaml -}}
  {{- end -}}
{{- else -}}
  {{- $flavor := .Values.gravitino.mysql.image.flavor | default "redhat" -}}
  {{- if eq $flavor "community" -}}
    {{- .Values.gravitino.mysql.image.community | toYaml -}}
  {{- else -}}
    {{- .Values.gravitino.mysql.image.redhat | toYaml -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "ranger.init-mysql.image" -}}
{{- if .Values.ranger.inClusterDB.enabled -}}
  {{- $imageRoot := include "ranger.init-mysql.imageRoot" . | fromYaml -}}
  {{- include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) -}}
{{- end -}}
{{- end -}}

{{/*
File install.properties
*/}}
{{- define "install.properties" -}}
#
# This file provides a list of the deployment variables for the Policy Manager Web Application
#

#------------------------- DB CONFIG - BEGIN ----------------------------------
# Uncomment the below if the DBA steps need to be run separately
#setup_mode=SeparateDBA

PYTHON_COMMAND_INVOKER=python3

#DB_FLAVOR=MYSQL|ORACLE|POSTGRES|MSSQL|SQLA
DB_FLAVOR=MYSQL
#

#
# Location of DB client library (please check the location of the jar file)
#
#SQL_CONNECTOR_JAR=/usr/share/java/ojdbc6.jar
#SQL_CONNECTOR_JAR=/usr/share/java/mysql-connector-java.jar
#SQL_CONNECTOR_JAR=/usr/share/java/postgresql.jar
#SQL_CONNECTOR_JAR=/usr/share/java/sqljdbc4.jar
#SQL_CONNECTOR_JAR=/opt/sqlanywhere17/java/sajdbc4.jar
SQL_CONNECTOR_JAR=/usr/share/java/mysql-connector-java.jar


#
# DB password for the DB admin user-id
# **************************************************************************
# ** If the password is left empty or not-defined here,
# ** it will try with blank password during installation process
# **************************************************************************
#
#db_root_user=root|SYS|postgres|sa|dba
#db_host=host:port              # for DB_FLAVOR=MYSQL|POSTGRES|SQLA|MSSQL       #for example: db_host=localhost:3306
#db_host=host:port:SID          # for DB_FLAVOR=ORACLE                          #for SID example: db_host=localhost:1521:ORCL
#db_host=host:port/ServiceName  # for DB_FLAVOR=ORACLE                          #for Service example: db_host=localhost:1521/XE
db_root_user={{ .Values.ranger.dbRootUser }}
db_root_password={{ if .Values.ranger.inClusterDB.enabled }}__DB_ROOT_PASSWORD__{{ else }}{{ .Values.ranger.dbRootPassword }}{{ end }}
db_host={{ if .Values.ranger.inClusterDB.enabled }}{{ if .Values.mysql.enabled }}{{ include "enterprise.fullname" . }}-mysql{{ else }}{{ .Release.Name }}-gravitino-mysql{{ end }}{{ else }}{{ .Values.ranger.externalDatabaseHost }}{{ end }}
#SSL config
db_ssl_enabled=false
db_ssl_required=false
db_ssl_verifyServerCertificate=false
#db_ssl_auth_type=1-way|2-way, where 1-way represents standard one way ssl authentication and 2-way represents mutual ssl authentication
db_ssl_auth_type=2-way
javax_net_ssl_keyStore=
javax_net_ssl_keyStorePassword=
javax_net_ssl_trustStore=
javax_net_ssl_trustStorePassword=
javax_net_ssl_trustStore_type=jks
javax_net_ssl_keyStore_type=jks

# For postgresql db
db_ssl_certificate_file=

#
# DB UserId used for the Ranger schema
#
db_name={{ .Values.ranger.rangerDatabase | default "ranger" }}
db_user={{ .Values.ranger.rangerDatabaseUser | default "rangeradmin" }}
db_password={{ .Values.ranger.rangerAdminPassword }}

#For over-riding the jdbc url.
is_override_db_connection_string=false
db_override_connection_string=


# change password. Password for below mentioned users can be changed only once using this property.
#PLEASE NOTE :: Password should be minimum 8 characters with min one alphabet and one numeric.
rangerAdmin_password={{ .Values.ranger.rangerAdminPassword }}
rangerTagsync_password={{ .Values.ranger.rangerAdminPassword }}
rangerUsersync_password={{ .Values.ranger.rangerAdminPassword }}
keyadmin_password={{ .Values.ranger.rangerAdminPassword }}


#Source for Audit Store. Currently solr, elasticsearch and cloudwatch logs are supported.
# * audit_store is solr
audit_store=DB

# * audit_solr_url Elasticsearch Host(s). E.g. 127.0.0.1
audit_elasticsearch_urls=
audit_elasticsearch_port=
audit_elasticsearch_protocol=
audit_elasticsearch_user=
audit_elasticsearch_password=
audit_elasticsearch_index=
audit_elasticsearch_bootstrap_enabled=true


# * audit_solr_url URL to Solr. E.g. http://<solr_host>:6083/solr/ranger_audits
audit_solr_urls=
audit_solr_user=
audit_solr_password=
audit_solr_zookeepers=

audit_solr_collection_name=ranger_audits
#solr Properties for cloud mode
audit_solr_config_name=ranger_audits
audit_solr_configset_location=
audit_solr_no_shards=1
audit_solr_no_replica=1
audit_solr_max_shards_per_node=1
audit_solr_acl_user_list_sasl=solr,infra-solr
audit_solr_bootstrap_enabled=true

# * audit to amazon cloudwatch properties
audit_cloudwatch_region=
audit_cloudwatch_log_group=
audit_cloudwatch_log_stream_prefix=

#------------------------- DB CONFIG - END ----------------------------------

#
# ------- PolicyManager CONFIG ----------------
#

policymgr_external_url=http://localhost:6080
policymgr_http_enabled=true
policymgr_https_keystore_file=
policymgr_https_keystore_keyalias=rangeradmin
policymgr_https_keystore_password=

#Add Supported Components list below separated by semi-colon, default value is empty string to support all components
#Example :  policymgr_supportedcomponents=hive,hbase,hdfs
policymgr_supportedcomponents=

#
# ------- PolicyManager CONFIG - END ---------------
#


#
# ------- UNIX User CONFIG ----------------
#
unix_user=ranger
unix_user_pwd=ranger
unix_group=ranger

#
# ------- UNIX User CONFIG  - END ----------------
#
#

#
# UNIX authentication service for Policy Manager
#
# PolicyManager can authenticate using UNIX username/password
# The UNIX server specified here as authServiceHostName needs to be installed with ranger-unix-ugsync package.
# Once the service is installed on authServiceHostName, the UNIX username/password from the host <authServiceHostName> can be used to login into policy manager
#
# ** The installation of ranger-unix-ugsync package can be installed after the policymanager installation is finished.
#
#LDAP|ACTIVE_DIRECTORY|UNIX|NONE
authentication_method=NONE
remoteLoginEnabled=true
authServiceHostName=localhost
authServicePort=5151
ranger_unixauth_keystore=keystore.jks
ranger_unixauth_keystore_password=password
ranger_unixauth_truststore=cacerts
ranger_unixauth_truststore_password=changeit

####LDAP settings - Required only if have selected LDAP authentication ####
#
# Sample Settings
#
#xa_ldap_url=ldap://127.0.0.1:389
#xa_ldap_userDNpattern=uid={0},ou=users,dc=xasecure,dc=net
#xa_ldap_groupSearchBase=ou=groups,dc=xasecure,dc=net
#xa_ldap_groupSearchFilter=(member=uid={0},ou=users,dc=xasecure,dc=net)
#xa_ldap_groupRoleAttribute=cn
#xa_ldap_base_dn=dc=xasecure,dc=net
#xa_ldap_bind_dn=cn=admin,ou=users,dc=xasecure,dc=net
#xa_ldap_bind_password=
#xa_ldap_referral=follow|ignore
#xa_ldap_userSearchFilter=(uid={0})

xa_ldap_url=
xa_ldap_userDNpattern=
xa_ldap_groupSearchBase=
xa_ldap_groupSearchFilter=
xa_ldap_groupRoleAttribute=
xa_ldap_base_dn=
xa_ldap_bind_dn=
xa_ldap_bind_password=
xa_ldap_referral=
xa_ldap_userSearchFilter=
####ACTIVE_DIRECTORY settings - Required only if have selected AD authentication ####
#
# Sample Settings
#
#xa_ldap_ad_domain=xasecure.net
#xa_ldap_ad_url=ldap://127.0.0.1:389
#xa_ldap_ad_base_dn=dc=xasecure,dc=net
#xa_ldap_ad_bind_dn=cn=administrator,ou=users,dc=xasecure,dc=net
#xa_ldap_ad_bind_password=
#xa_ldap_ad_referral=follow|ignore
#xa_ldap_ad_userSearchFilter=(sAMAccountName={0})

xa_ldap_ad_domain=
xa_ldap_ad_url=
xa_ldap_ad_base_dn=
xa_ldap_ad_bind_dn=
xa_ldap_ad_bind_password=
xa_ldap_ad_referral=
xa_ldap_ad_userSearchFilter=

#------------ Kerberos Config -----------------
spnego_principal=
spnego_keytab=
token_valid=30
cookie_domain=
cookie_path=/
admin_principal=
admin_keytab=
lookup_principal=
lookup_keytab=
hadoop_conf=/etc/hadoop/conf
#
#-------- SSO CONFIG - Start ------------------
#
sso_enabled=false
sso_providerurl=https://127.0.0.1:8443/gateway/knoxsso/api/v1/websso
sso_publickey=

#
#-------- SSO CONFIG - END ------------------

# Custom log directory path
RANGER_ADMIN_LOG_DIR=$PWD
RANGER_ADMIN_LOGBACK_CONF_FILE=

# PID file path
RANGER_PID_DIR_PATH=/var/run/ranger

# #################  DO NOT MODIFY ANY VARIABLES BELOW #########################
#
# --- These deployment variables are not to be modified unless you understand the full impact of the changes
#
################################################################################
XAPOLICYMGR_DIR=$PWD
app_home=$PWD/ews/webapp
TMPFILE=$PWD/.fi_tmp
LOGFILE=$PWD/logfile
LOGFILES="$LOGFILE"

JAVA_BIN='java'
JAVA_VERSION_REQUIRED='1.8'
JAVA_ORACLE='Java(TM) SE Runtime Environment'

ranger_admin_max_heap_size=1g
#retry DB and Java patches after the given time in seconds.
PATCH_RETRY_INTERVAL=120
STALE_PATCH_ENTRY_HOLD_TIME=10

#mysql_create_user_file=${PWD}/db/mysql/create_dev_user.sql
mysql_core_file=db/mysql/optimized/current/ranger_core_db_mysql.sql
mysql_audit_file=db/mysql/xa_audit_db.sql
#mysql_asset_file=${PWD}/db/mysql/reset_asset.sql

#oracle_create_user_file=${PWD}/db/oracle/create_dev_user_oracle.sql
oracle_core_file=db/oracle/optimized/current/ranger_core_db_oracle.sql
oracle_audit_file=db/oracle/xa_audit_db_oracle.sql
#oracle_asset_file=${PWD}/db/oracle/reset_asset_oracle.sql
#
postgres_core_file=db/postgres/optimized/current/ranger_core_db_postgres.sql
postgres_audit_file=db/postgres/xa_audit_db_postgres.sql
#
sqlserver_core_file=db/sqlserver/optimized/current/ranger_core_db_sqlserver.sql
sqlserver_audit_file=db/sqlserver/xa_audit_db_sqlserver.sql
#
sqlanywhere_core_file=db/sqlanywhere/optimized/current/ranger_core_db_sqlanywhere.sql
sqlanywhere_audit_file=db/sqlanywhere/xa_audit_db_sqlanywhere.sql
cred_keystore_filename=$app_home/WEB-INF/classes/conf/.jceks/rangeradmin.jceks
{{- end }}


{{/*
Return the name of the Secret that holds the Gravitino JDBC password.
Mirrors the logic in datastrato-gravitino/templates/_helpers.tpl:
  - MySQL subchart enabled  → "<release>-gravitino-mysql"       key: mysql-password
  - PostgreSQL subchart enabled → "<release>-postgresql"        key: password
  - External / H2 (neither) → "<release>-gravitino-entity-store" key: jdbc-password
    (the subchart alias is "gravitino", so fullname = "<release>-gravitino")
*/}}
{{- define "enterprise.gravitino.jdbcPasswordSecretName" -}}
{{- if .Values.gravitino.mysql.enabled -}}
  {{- .Values.gravitino.mysql.auth.existingSecret | default (printf "%s-gravitino-mysql" .Release.Name) -}}
{{- else if .Values.gravitino.postgresql.enabled -}}
  {{- .Values.gravitino.postgresql.auth.existingSecret | default (include "enterprise.postgresql.fullname" .) -}}
{{- else -}}
  {{- printf "%s-entity-store" (include "enterprise.gravitino.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return the key within the Gravitino JDBC password Secret.
*/}}
{{- define "enterprise.gravitino.jdbcPasswordSecretKey" -}}
{{- if .Values.gravitino.mysql.enabled -}}
mysql-password
{{- else if .Values.gravitino.postgresql.enabled -}}
password
{{- else -}}
jdbc-password
{{- end -}}
{{- end -}}
