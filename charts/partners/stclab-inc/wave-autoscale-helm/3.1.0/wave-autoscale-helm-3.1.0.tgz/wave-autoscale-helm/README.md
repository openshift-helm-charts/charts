# Wave Autoscale Helm Chart

AI-powered Kubernetes resource optimization and cost reduction solution that uses machine learning to automatically optimize resource allocation and reduce cloud costs.

## Overview

Wave Autoscale is an intelligent autoscaling solution that:
- Creates performance model using machine learning
- Optimizes resource allocation in real-time
- Reduces cloud infrastructure costs by up to 70%
- Provides a web console for monitoring and management
- Works with both standard Kubernetes and OpenShift

## Prerequisites

- Kubernetes 1.26+ or OpenShift 4.13+
- Helm 3.x
- Cluster admin privileges for RBAC setup
- Valid Wave Autoscale license key

## Security Considerations

Wave Autoscale requires elevated privileges to collect system and container metrics:

**DaemonSet (Agent & cAdvisor):**
- `privileged: true` - Required to access host container runtime and cgroup metrics
- `hostPath` volumes - Needed to read `/proc`, `/sys`, `/var/run` for system metrics
- `hostPID: true` - Required for process-level monitoring

**StatefulSet (Core, Web Console, Intelligence):**
- `hostPort` - Used for direct node access to services

These permissions are necessary for the application to perform resource monitoring and optimization. For OpenShift environments, appropriate SecurityContextConstraints (SCCs) are provided.

## Installation

### Standard Kubernetes Installation

```bash
# Add the Helm repository (if available)
helm repo add wave-autoscale <repository-url>
helm repo update

# Install Wave Autoscale
helm install wave-autoscale wave-autoscale/wave-autoscale-helm \
  --namespace wave-autoscale \
  --create-namespace \
  --set license.key=<your-license-key>
```

### OpenShift Installation

For OpenShift environments with CRI-O container runtime:

```bash
# Create namespace
oc new-project wave-autoscale

# Install with OpenShift-specific configuration
helm install wave-autoscale wave-autoscale/wave-autoscale-helm \
  --namespace wave-autoscale \
  --set license.key=<your-license-key> \
  --set openshift.waveAutoscale.scc.create=true \
  --set openshift.waveAutoscaleAgent.scc.create=true \
  --set spec.securityContext.fsGroup=0
```

## Configuration

### Key Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `license.key` | Wave Autoscale license key | `""` |
| `spec.core.image.repository` | Core service image repository | `$repository` |
| `spec.core.image.tag` | Core service image tag | `$tag` |
| `spec.agent.enabled` | Enable Wave Autoscale agent DaemonSet | `true` |
| `spec.pvcStorage` | Persistent volume size | `30Gi` |
| `spec.storageClassName` | Storage class name | `""` |
| `openshift.waveAutoscale.scc.create` | Create SecurityContextConstraints for OpenShift | `false` |

### Resource Requirements

Default resource requests:
- **Core**: 1500m CPU, 3Gi memory
- **Web Console**: 300m CPU, 300Mi memory
- **Intelligence**: 1 CPU, 2Gi memory
- **Agent**: 100m CPU, 50Mi memory (per node)

### Container Runtime Configuration

**For CRI-O (OpenShift):**
```yaml
spec:
  cadvisor:
    args:
      - --containerd=/var/run/crio/crio.sock
```

**For Docker (default):**
No additional configuration needed - uses `--docker_only` automatically.

## Architecture

Wave Autoscale consists of:
- **Core Service**: Main API and orchestration engine
- **Web Console**: Management UI
- **Intelligence Service**: ML-powered prediction engine
- **Agent**: Per-node metrics collection (DaemonSet)
- **cAdvisor**: Container metrics collection

## Accessing the Application

After installation, access the web console:

```bash
# Port-forward the web console service
kubectl port-forward -n wave-autoscale svc/wave-autoscale-svc 3025:3025

# Access at http://localhost:3025
```

For production, configure an Ingress or Route:

```yaml
# OpenShift Route example
oc expose svc wave-autoscale-svc --port=3025 -n wave-autoscale
```

## Upgrading

```bash
helm upgrade wave-autoscale wave-autoscale/wave-autoscale-helm \
  --namespace wave-autoscale \
  --reuse-values
```

## Uninstalling

```bash
helm uninstall wave-autoscale -n wave-autoscale
```

## Support

For support and additional documentation:
- Website: https://www.waveautoscale.com
- Email: team@waveautoscale.com
- Documentation: https://waveautoscale.com/docs/introduction

## License

Requires a valid Wave Autoscale license. Contact sales@stclab.com for licensing information.
