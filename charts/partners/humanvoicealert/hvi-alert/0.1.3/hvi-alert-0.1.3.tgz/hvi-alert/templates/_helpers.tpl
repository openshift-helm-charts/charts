{{- define "alert.check" -}}
{{- if and .Values.route.enabled (ne .Values.apiTLS.source "openshift") -}}
{{- fail "External API certificates require route.enabled=false; configure a separately managed ingress with explicit destination trust" -}}
{{- end -}}
{{- if not .Values.acceptUnvalidated -}}
{{- fail "This local candidate requires acceptUnvalidated=true; no release is approved" -}}
{{- end -}}
{{- if not (hasPrefix (printf "%s-" .Values.modelProfile) .Values.embeddingSpace) -}}
{{- fail "Embedding space must match the selected candidate profile" -}}
{{- end -}}
{{- if contains "CONFIGURE" (upper .Values.embeddingSpace) -}}
{{- fail "Replace the placeholder embedding space" -}}
{{- end -}}
{{- range .Values.signingKeyIds -}}
{{- if hasPrefix "configure-" . -}}
{{- fail "Replace placeholder signing key IDs" -}}
{{- end -}}
{{- end -}}
{{- range $image := .Values.images -}}
{{- if or (contains "example.invalid" $image) (regexMatch ":(0{64}|1{64}|a{64}|f{64})$" $image) -}}
{{- fail "Replace example image references with actual immutable digests" -}}
{{- end -}}
{{- end -}}
{{- end -}}
