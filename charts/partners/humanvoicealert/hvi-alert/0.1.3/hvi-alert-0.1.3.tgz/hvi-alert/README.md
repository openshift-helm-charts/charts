# Human_Voice_Speaker_Verification

This chart installs the API, private speaker-model service, migration/readiness
Jobs, Services, NetworkPolicies and an optional HTTPS re-encrypt OpenShift Route.
It uses Helm directly: no HVIAlert CRD or long-running operator is required.
Only Methods 1 and 2 are active. Enrollment stores original WAV audio in
PostgreSQL; API responses never return embeddings or signed voiceprints.

**Candidate status:** not Red Hat certified or approved for customer release.
Images must finish licensing/security review, exact-release acceptance and
container certification before chart certification/publication. ARM64 CPU is the
tested architecture. OpenShift 4.22 is the current certification target; the
Kubernetes version constraint is restricted to 1.35 for that initial target;
other OpenShift minors require separate validation before widening it.

## Before installation

Use a dedicated application namespace with one chart release. Fixed names such
as `alert-api` and `alert-models` deliberately prevent multiple releases sharing
a namespace. Do not install over the live sandbox or an operator-owned release.

A namespace administrator must provide:

1. PostgreSQL 16 with pgvector, verified TLS, database `alert`, and separate
   `alert_owner`/`alert_app` roles. Grant extension creation to the database
   administrator; provision the `vector` extension before installation. Database
   HA, backup/restore, server certificates and PVC lifecycle are external to this
   application chart. The SQL schema is `Alert_Sandbox`.
2. Existing runtime Secrets, delivered securely rather than through Helm values:
   `alert-migration` contains the owner `database_dsn` and `database_ca.crt`;
   `alert-runtime` contains the app DSN/CA, `api_token`, `model_token` and
   `signing_keys.json`; `alert-model-runtime` contains the same model token and
   signing-key document. The DSNs require `sslmode=verify-full` and the correct
   mounted CA path (`/run/alert-migration/database_ca.crt` or
   `/run/alert/database_ca.crt`). Use the deployment's exact model-space/key
   binding; never reuse a key for a different model bundle.
3. Private registry pull credentials in a Secret such as `alert-registry`, with
   pull-only access. List that Secret under `imagePullSecrets`.
4. The `alert-readiness` service account and namespaced Role/RoleBinding from
   `examples/readiness-rbac.yaml` included in the unpacked chart. It can only GET
   `alert-api` and `alert-models` Deployments. The chart's post-install and test
   hooks use this account. Business API/model pods have no Kubernetes API token.
5. Permission for the installer to manage this chart's namespaced resources.
   The chart never grants cluster-admin, creates a namespace, or owns a database
   StatefulSet, PVC or database credential Secret.

OpenShift service CA issues API/model certificates by default. For non-OpenShift
testing, provide external API/model certificates and the model CA ConfigMap,
select `apiTLS.source: external`, `modelTLS.source: external`, and disable the
managed Route. A separately managed ingress must verify the API certificate.
Do not disable TLS verification to get an installation to pass.

## Configuration and commands

Create a public configuration file, with no tokens, passwords or key material:

```yaml
tenantId: your-tenant
embeddingSpace: v4-candidate-<exact-image-bundle-fingerprint>
signingKeyIds: [your-existing-key-id]
modelProfile: v4-candidate
acceptUnvalidated: true # Explicitly enables sandbox candidates only.
imagePullSecrets: [alert-registry]
images:
  api: quay.io/humanvoicealert/alert-api@sha256:<approved-api-digest>
  model: quay.io/humanvoicealert/alert-model@sha256:<approved-model-digest>
```

The example is incomplete; replace every placeholder with actual deployment
values. `values.schema.json` rejects unknown fields, credentials in values,
mutable image tags and inconsistent model-space/profile combinations. Other
settings include replicas, Secret names/revision, TLS sources, Route enablement
and the DNS namespace. Inspect `values.yaml` and `values.schema.json` for their
defaults and constraints.

```sh
oc -n YOUR_DEDICATED_NAMESPACE apply -f operator/helm/hvi-alert/examples/readiness-rbac.yaml
helm lint operator/helm/hvi-alert -f YOUR_PUBLIC_VALUES.yaml
helm upgrade --install hvi-alert operator/helm/hvi-alert \
  --namespace YOUR_DEDICATED_NAMESPACE -f YOUR_PUBLIC_VALUES.yaml --timeout 5m
helm test hvi-alert --namespace YOUR_DEDICATED_NAMESPACE --timeout 2m
```

The pre-install/pre-upgrade migration must finish before application resources
are created or changed. A failed migration stops that operation. The post hook
waits for current-generation API/model rollouts at the requested configuration.
`helm test` independently repeats that read-only readiness check; it does not
enroll speakers or prove biometric accuracy, capacity, or public HTTPS access.
Run the deployment's separate authenticated API acceptance tests as well.

## Upgrade, recovery and removal

Back up PostgreSQL and test restore before release/schema changes. Supply the
new immutable digests and compatible configuration to `helm upgrade`. Changes
to Secret contents require increasing `secretRevision` to roll API/model pods.
Model dependency/preprocessing changes require a new model-space binding and an
explicit enrollment transition; existing vectors must not be relabeled.

Helm does not continuously reconcile configuration drift. Operators must detect
drift and run a reviewed upgrade/reapply. A failed post-install hook can leave
partially rolled resources; investigate rollout status before retrying. Do not
assume `helm rollback` can reverse SQL migrations or model-space changes. Restore
database/image/configuration together according to their compatibility contract.

`helm uninstall hvi-alert -n YOUR_DEDICATED_NAMESPACE` removes managed application
resources but leaves externally managed PostgreSQL, PVCs and runtime Secrets.
Hook Jobs and their migration service account/policy can outlive the release;
clean up only these named application hooks after verifying they are inactive.
Never remove the namespace or database merely to uninstall the application.

## Support

Human Voice Inc.: <https://humanvoice.inc>, bradley.warren@humanvoice.inc.
Initial response within 24 hours, seven days a week. This is not a resolution-time
guarantee. Provide versions, image digests and sanitized symptoms; do not send
credentials, customer audio or embeddings in routine support reports.
