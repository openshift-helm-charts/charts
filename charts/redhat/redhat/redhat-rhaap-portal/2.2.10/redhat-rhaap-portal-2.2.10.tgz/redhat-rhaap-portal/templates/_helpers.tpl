{{/*
    Updates the Quay image tag in dynamic.plugins.package values - development env only
*/}}
{{- define "deployment.quay-image-tag" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "%s" (.Values.global.imageTagInfo) -}}
    {{- end -}}
{{- end -}}

{{/*
    Updates the image tag for stage environment
*/}}
{{- define "deployment.image-tag" -}}
    {{- if .Values.global._environment._stage -}}
        {{- printf "%s" (.Values.global.imageTagInfo) -}}
    {{- end -}}
{{- end -}}

{{/*
    Returns the container image registry.
    Supports override via global.imageRegistry for disconnected/air-gapped environments.
*/}}
{{- define "deployment.registry" -}}
    {{- if .Values.global.imageRegistry -}}
        {{- printf "%s" .Values.global.imageRegistry -}}
    {{- else -}}
        {{- printf "%s" "registry.redhat.io" -}}
    {{- end -}}
{{- end -}}

{{/*
    Returns the full OCI plugin image path (registry + repository).
    If ociPluginImage is set, uses it directly.
    Otherwise, constructs from deployment.registry + default repo path.
*/}}
{{- define "deployment.oci-plugin-image" -}}
    {{- if .Values.global.ociPluginImage -}}
        {{- printf "%s" .Values.global.ociPluginImage -}}
    {{- else -}}
        {{- printf "%s/ansible-automation-platform/automation-portal" (include "deployment.registry" .) -}}
    {{- end -}}
{{- end -}}

{{/*
    Updates the extraContainers image.
    Supports override via global.imageRegistry for disconnected/air-gapped environments.
*/}}
{{- define "deployment.container-image" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "%s" "ghcr.io/ansible/community-ansible-dev-tools:v26.7.1" -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "registry.stage.redhat.io/ansible-automation-platform-27/ansible-dev-tools-rhel9@sha256:20682ea97fabb44f52d82361bd985d2e9b31d8e445c09b99ebf0acdbcfe5f210" -}}
    {{- else if .Values.global._environment._production -}}
        {{- printf "%s/ansible-automation-platform-27/ansible-dev-tools-rhel9@sha256:20682ea97fabb44f52d82361bd985d2e9b31d8e445c09b99ebf0acdbcfe5f210" (include "deployment.registry" .) -}}
    {{- end -}}
{{- end -}}

{{- define "deployment.test.imagePullSecret" }}
    {{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" (index .Values "redhat-developer-hub" "testImageCredentials" "registry") (printf "%s:%s" (index .Values "redhat-developer-hub" "testImageCredentials" "username") (index .Values "redhat-developer-hub" "testImageCredentials" "password") | b64enc) | b64enc }}
{{- end }}

{{- define "deployment.test.registryCredentials" }}
    {{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" (index .Values "redhat-developer-hub" "registryCredentials" "registry") (printf "%s:%s" (index .Values "redhat-developer-hub" "registryCredentials" "username") (index .Values "redhat-developer-hub" "registryCredentials" "password") | b64enc) | b64enc }}
{{- end }}

{{- define "plugins.load.auth" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "oci://quay.io/redhat-user-workloads/ansible-plugins-tenant/ansible-plugins:%s!ansible-backstage-plugin-auth-backend-module-rhaap-provider" (include "deployment.quay-image-tag" .) -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "oci://registry.stage.redhat.io/ansible-automation-platform/automation-portal:%s!ansible-backstage-plugin-auth-backend-module-rhaap-provider" (include "deployment.image-tag" .) -}}
    {{- else if .Values.global._environment._production -}}
        {{- if eq .Values.global.pluginMode "oci" -}}
            {{- printf "oci://%s:%s!ansible-backstage-plugin-auth-backend-module-rhaap-provider" (include "deployment.oci-plugin-image" .) (.Values.global.imageTagInfo) -}}
        {{- else -}}
            {{- printf "http://plugin-registry:8080/ansible-backstage-plugin-auth-backend-module-rhaap-provider-dynamic-2.2.8.tgz" -}}
        {{- end -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.load.catalog" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "oci://quay.io/redhat-user-workloads/ansible-plugins-tenant/ansible-plugins:%s!ansible-backstage-plugin-catalog-backend-module-rhaap" (include "deployment.quay-image-tag" .) -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "oci://registry.stage.redhat.io/ansible-automation-platform/automation-portal:%s!ansible-backstage-plugin-catalog-backend-module-rhaap" (include "deployment.image-tag" .) -}}
    {{- else if .Values.global._environment._production -}}
        {{- if eq .Values.global.pluginMode "oci" -}}
            {{- printf "oci://%s:%s!ansible-backstage-plugin-catalog-backend-module-rhaap" (include "deployment.oci-plugin-image" .) (.Values.global.imageTagInfo) -}}
        {{- else -}}
            {{- printf "http://plugin-registry:8080/ansible-backstage-plugin-catalog-backend-module-rhaap-dynamic-2.2.8.tgz" -}}
        {{- end -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.load.self-service" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "oci://quay.io/redhat-user-workloads/ansible-plugins-tenant/ansible-plugins:%s!ansible-plugin-backstage-self-service" (include "deployment.quay-image-tag" .) -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "oci://registry.stage.redhat.io/ansible-automation-platform/automation-portal:%s!ansible-plugin-backstage-self-service" (include "deployment.image-tag" .) -}}
    {{- else if .Values.global._environment._production -}}
        {{- if eq .Values.global.pluginMode "oci" -}}
            {{- printf "oci://%s:%s!ansible-plugin-backstage-self-service" (include "deployment.oci-plugin-image" .) (.Values.global.imageTagInfo) -}}
        {{- else -}}
            {{- printf "http://plugin-registry:8080/ansible-plugin-backstage-self-service-dynamic-2.2.8.tgz" -}}
        {{- end -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.load.scaffolder" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "oci://quay.io/redhat-user-workloads/ansible-plugins-tenant/ansible-plugins:%s!ansible-plugin-scaffolder-backend-module-backstage-rhaap" (include "deployment.quay-image-tag" .) -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "oci://registry.stage.redhat.io/ansible-automation-platform/automation-portal:%s!ansible-plugin-scaffolder-backend-module-backstage-rhaap" (include "deployment.image-tag" .) -}}
    {{- else if .Values.global._environment._production -}}
        {{- if eq .Values.global.pluginMode "oci" -}}
            {{- printf "oci://%s:%s!ansible-plugin-scaffolder-backend-module-backstage-rhaap" (include "deployment.oci-plugin-image" .) (.Values.global.imageTagInfo) -}}
        {{- else -}}
            {{- printf "http://plugin-registry:8080/ansible-plugin-scaffolder-backend-module-backstage-rhaap-dynamic-2.2.8.tgz" -}}
        {{- end -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.integrity.auth" -}}
    {{- if and .Values.global._environment._production (eq .Values.global.pluginMode "tarball") -}}
        {{- printf "sha512-N3itmhfl9S2JYhjyFuHmt9CAowa2JuldSOW2yV+Ehqr4ghf88Evu7loTnL8zlP/ZcbQ5NOx66EePlctIB4BobQ==" -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.integrity.catalog" -}}
    {{- if and .Values.global._environment._production (eq .Values.global.pluginMode "tarball") -}}
        {{- printf "sha512-D+oHEL+aH6PlDiUxNx5czVCAAzSK1vzX1axDKtz2sWEiR2XVLdM+fEpq2rf17jLRqTKH/89MClGlCcnN8nAGXA==" -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.integrity.self-service" -}}
    {{- if and .Values.global._environment._production (eq .Values.global.pluginMode "tarball") -}}
        {{- printf "sha512-DUwagItVscoP6ASl44w4I0tX8af/H2StjR5+7py9jP1xQ05tNhcqw0lTopUkzHU1sh1NHRLvYlL400a0TZoJow==" -}}
    {{- end -}}
{{- end -}}

{{- define "plugins.integrity.scaffolder" -}}
    {{- if and .Values.global._environment._production (eq .Values.global.pluginMode "tarball") -}}
        {{- printf "sha512-2xEvNrBsQ5dLbYTAzpS5P6uK/xJUy3gQlNuvg/a8FY448JpVlDyKssqIdqCobvKz4XEydcSbeSf4we9RXGcFug==" -}}
    {{- end -}}
{{- end -}}

{{/*
    Returns the registry for ghcr.io-hosted images.
    In airgapped environments, global.imageRegistry overrides ghcr.io so users don't need a
    separate registry value — the same mirror covers all images.
*/}}
{{- define "deployment.ghcr-registry" -}}
    {{- if .Values.global.imageRegistry -}}
        {{- printf "%s" .Values.global.imageRegistry -}}
    {{- else -}}
        {{- printf "%s" "ghcr.io" -}}
    {{- end -}}
{{- end -}}

{{/*
    RHDH GitHub / GitLab auth backend modules — pulled from ghcr.io overlays by default.
    In airgapped environments, global.imageRegistry redirects to the internal mirror.
    Ansible plugins still follow pluginMode in other helpers.
*/}}
{{- define "plugins.load.github-auth-provider" -}}
    {{- printf "oci://%s/redhat-developer/rhdh-plugin-export-overlays/backstage-plugin-auth-backend-module-github-provider:bs_1.49.4__0.5.1!backstage-plugin-auth-backend-module-github-provider" (include "deployment.ghcr-registry" .) -}}
{{- end -}}

{{- define "plugins.load.gitlab-auth-provider" -}}
    {{- printf "oci://%s/redhat-developer/rhdh-plugin-export-overlays/backstage-plugin-auth-backend-module-gitlab-provider:bs_1.49.4__0.4.1!backstage-plugin-auth-backend-module-gitlab-provider" (include "deployment.ghcr-registry" .) -}}
{{- end -}}

{{- define "catalog.providers.env" -}}
    {{- if .Values.global._environment._development -}}
        {{- printf "development" -}}
    {{- else if .Values.global._environment._stage -}}
        {{- printf "stage" -}}
    {{- else if .Values.global._environment._production -}}
        {{- printf "production" -}}
    {{- end -}}
{{- end -}}
