{{/*
Get value from a resource. Currently only from secrets.

Arguments (dict):
  * .root - .
  * .valueFrom - The "valueFrom" object
*/}}
{{- define "_trustify.valueFrom" }}

{{- if .valueFrom.secretKeyRef }}
{{- $secret := lookup "v1" "Secret" .root.Release.Namespace .valueFrom.secretKeyRef.name }}
{{- if not $secret.data }}
{{- fail (printf "Secret '%s' not found in namespace '%s' (or 'lookup' is unavailable in this mode)" .valueFrom.secretKeyRef.name .root.Release.Namespace) }}
{{- end }}
{{- required (printf "Key '%s' not found in Secret '%s'" .valueFrom.secretKeyRef.key .valueFrom.secretKeyRef.name) (index $secret.data .valueFrom.secretKeyRef.key) | b64dec }}

{{- else if .valueFrom.configMapKeyRef }}
{{- $config := lookup "v1" "ConfigMap" .root.Release.Namespace .valueFrom.configMapKeyRef.name }}
{{- if not $config.data }}
{{- fail (printf "ConfigMap '%s' not found in namespace '%s' (or 'lookup' is unavailable in this mode)" .valueFrom.configMapKeyRef.name .root.Release.Namespace) }}
{{- end }}
{{- required (printf "Key '%s' not found in ConfigMap '%s'" .valueFrom.configMapKeyRef.key .valueFrom.configMapKeyRef.name) (index $config.data .valueFrom.configMapKeyRef.key) }}

{{- else }}
{{- fail "valueFrom can only use .secretKeyRef or .configMapRef" }}
{{- end }}

{{- end }}
