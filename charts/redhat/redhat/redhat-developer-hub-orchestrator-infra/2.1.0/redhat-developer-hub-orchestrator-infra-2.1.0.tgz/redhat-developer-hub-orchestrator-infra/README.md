
# Orchestrator Infra Chart for OpenShift

![Version: 2.1.0](https://img.shields.io/badge/Version-2.1.0-informational?style=flat-square)
![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

Helm chart to deploy the Orchestrator solution's required infrastructure suite on OpenShift, including OpenShift Serverless Operator and OpenShift Serverless Logic Operator, both required to configure Red Hat Developer Hub to use the Orchestrator.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Red Hat Developer Hub Team |  | <https://github.com/redhat-developer/rhdh-chart> |

## Source Code

* <https://github.com/redhat-developer/rhdh-chart>

## Requirements

Kubernetes: `>= 1.25.0-0`

## TL;DR

```console
helm repo add redhat-developer https://redhat-developer.github.io/rhdh-chart

helm install my-orchestrator-infra redhat-developer/redhat-developer-hub-orchestrator-infra --version 2.1.0
```

> **Tip**: List all releases using `helm list`

## Testing a Release

Once an Helm Release has been deployed, you can test it using the [`helm test`](https://helm.sh/docs/helm/helm_test/) command:

```sh
helm test <release_name>
```

This will run a simple Pod in the cluster to check that the required resources have been created.

You can control whether to disable this test pod or you can also customize the image it leverages.
See the `test.enabled` and `test.image` parameters in the [`values.yaml`](./values.yaml) file.

> **Tip**: Disabling the test pod will not prevent the `helm test` command from passing later on. It will simply report that no test suite is available.

Below are a few examples:

<details>

<summary>Disabling the test pod</summary>

```sh
helm install <release_name> <repo> \
  --set test.enabled=false
```

</details>

<details>

<summary>Customizing the test pod image</summary>

```sh
helm install <release_name> <repo> \
  --set test.image=<image>
```

</details>

## Uninstalling the Chart

To uninstall/delete a Helm release named `my-orchestrator-infra`:

```console
helm uninstall my-orchestrator-infra
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Values

| Key | Description | Type | Default |
|-----|-------------|------|---------|
| olm.catalog.selector | ClusterCatalog selector for OLM v1 ClusterExtension resources | object | `{"matchLabels":{"olm.operatorframework.io/metadata.name":"openshift-redhat-operators"}}` |
| olmVersion | OLM API version to use for operator installation (`v0` or `v1`) | string | `"v0"` |
| serverlessLogicOperator.clusterExtension.serviceAccount.name | service account used by OLM v1 to install the operator | string | `"serverless-logic-operator-installer"` |
| serverlessLogicOperator.createNamespace | whether to create the operator namespace (set to false if namespace already exists) | bool | `true` |
| serverlessLogicOperator.enabled | whether the operator should be deployed by the chart | bool | `true` |
| serverlessLogicOperator.subscription.namespace | namespace where the operator should be deployed | string | `"openshift-serverless-logic"` |
| serverlessLogicOperator.subscription.spec.channel | channel of an operator package to subscribe to | string | `"stable"` |
| serverlessLogicOperator.subscription.spec.installPlanApproval | whether the update should be installed automatically | string | `"Manual"` |
| serverlessLogicOperator.subscription.spec.name | name of the operator package | string | `"logic-operator"` |
| serverlessLogicOperator.subscription.spec.source | name of the catalog source | string | `"redhat-operators"` |
| serverlessLogicOperator.subscription.spec.sourceNamespace |  | string | `"openshift-marketplace"` |
| serverlessLogicOperator.subscription.spec.startingCSV | The initial version of the operator, must match CRDs installed by the chart | string | `"logic-operator.v1.39.2"` |
| serverlessOperator.clusterExtension.serviceAccount.name | service account used by OLM v1 to install the operator | string | `"serverless-operator-installer"` |
| serverlessOperator.createNamespace | whether to create the operator namespace (set to false if namespace already exists) | bool | `true` |
| serverlessOperator.enabled | whether the operator should be deployed by the chart | bool | `true` |
| serverlessOperator.subscription.namespace | namespace where the operator should be deployed | string | `"openshift-serverless"` |
| serverlessOperator.subscription.spec.channel | channel of an operator package to subscribe to | string | `"stable"` |
| serverlessOperator.subscription.spec.installPlanApproval | whether the update should be installed automatically | string | `"Manual"` |
| serverlessOperator.subscription.spec.name | name of the operator package | string | `"serverless-operator"` |
| serverlessOperator.subscription.spec.source | name of the catalog source | string | `"redhat-operators"` |
| serverlessOperator.subscription.spec.sourceNamespace |  | string | `"openshift-marketplace"` |
| tests.enabled | Whether to create the test pod used for testing the Release using `helm test`. | bool | `true` |
| tests.image | Test pod image | string | `"bitnami/kubectl:latest"` |

### OLM v0 and OLM v1 operator installation

The chart defaults to `olmVersion: v0`.

- `v0`: creates `Subscription` resources
- `v1`: creates `ClusterExtension` resources with an installer ServiceAccount and ClusterRoleBinding

```bash
helm install my-orchestrator-infra ./charts/orchestrator-infra --set olmVersion=v0
helm install my-orchestrator-infra ./charts/orchestrator-infra --set olmVersion=v1
```

### OLM v1 API CRDs (chart-testing only)

With `olmVersion: v1`, this chart creates `ClusterExtension` resources (see the previous section). Before Kubernetes can accept those objects, the cluster must already expose the OLM v1 API types `ClusterExtension` and `ClusterCatalog`.

On OpenShift, those APIs usually come from the platform (you do not install them as part of this chart). The `rhdh-operator` plugin-infra flow assumes they are already present when it applies its own `ClusterExtension` manifests.

Pull request CI tests this chart on a KinD cluster using `ci/upstream-olm-v1-values.yaml`. KinD does not ship OLM v1, so the shared test workflow downloads a pinned [operator-controller](https://github.com/operator-framework/operator-controller) release, applies only the `CustomResourceDefinition` manifests from that bundle, and does **not** install the operator-controller controller. That is enough for `helm template`, `ct install`, and `helm test` to validate the v1 chart output.

To change which operator-controller release CI uses, update `OPERATOR_CONTROLLER_VERSION` in the `Install OLM v1 API CRDs (orchestrator-infra chart-testing)` step in [`.github/actions/test-charts/action.yml`](../../.github/actions/test-charts/action.yml).

### Installing Knative Eventing and Knative Serving CRDs

The orchestrator-infra chart requires several CRDs for Knative Eventing and Knative Serving. These CRDs will be applied prior to installing the chart, ensuring that Knative CRs can be created as part of the chart's deployment process. This approach eliminates the need to wait for the OpenShift Serverless Operator's subscription to install them beforehand.

The KnativeEventing and KnativeServing CRDs are required for this chart to run. These CRDs need to be present under the `crds/` directory before running `helm install`.
After installing the openshift-serverless subscription, more Knative CRDs will be installed on the cluster.

The versions of the CRDs present in the chart and the ones in the subscription must match. In order to verify the correct CRD, use this following command to extract the CRD:

```bash
export osl_bundle=registry.redhat.io/openshift-serverless-1/serverless-operator-bundle:1.38.1
podman container run --rm --entrypoint cat "$osl_bundle" /manifests/operator_v1beta1_knativeeventing_crd.yaml > crds/knative-eventing/knative-eventing-crd.yaml

podman container run --rm --entrypoint cat "$osl_bundle" /manifests/operator_v1beta1_knativeserving_crd.yaml > crds/knative-serving/knative-serving-crd.yaml
```
