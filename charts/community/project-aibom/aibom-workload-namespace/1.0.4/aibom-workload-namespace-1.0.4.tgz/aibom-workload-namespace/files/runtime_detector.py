"""
AIBOM Runtime Detector - Runtime shim for automatic training metadata collection.

Mounted into the app container as sitecustomize.py (on PYTHONPATH), so Python's
site module imports it at interpreter startup; can also be imported explicitly.
Monkey-patches common ML dataset
entry points to capture dataset name, source, and configuration without requiring
manual specification in intent.yaml, and inspects the training process's own
argv/config files to capture training args and parallelization strategy.

Supported dataset frameworks:
  - PyTorch DataLoader / Dataset
  - HuggingFace datasets.load_dataset
  - torchvision.datasets
  - webdataset.WebDataset

Also hooks transformers.TrainingArguments, transformers.PreTrainedModel.from_pretrained,
and peft.LoraConfig -- catching model/training config for scripts that build these
objects directly in Python, with no corresponding CLI flags for postprocess.py's
command-line detectors to see -- and the global seeding functions (random.seed,
numpy.random.seed, torch.manual_seed) plus torch's determinism flags, the
first torch.optim.Optimizer constructed, and the versions of the ML libraries
the process imported.

Writes detected metadata to $AIBOM_DATASET_OUTPUT (default: /results/dataset_detected.json)
only -- this process never talks to the Kubernetes API. The aibom-dataset-sidecar
container (dataset_sidecar.py) reads and signs that file and performs the actual
ConfigMap write from a process this application container doesn't control (#47) --
previously this module wrote directly to the ConfigMap itself using whatever
credentials the webhook gave the pod, which meant a compromised or malicious
training script could forge dataset-<pod-name>.json with a syntactically valid
(if meaningless) write of its own.

Output is written shortly after each detection (debounced), at exit, and on
SIGTERM, under an flock and via write-then-rename, since many processes share
the file and any of them can be killed without running atexit (#107).

All hooks are fault-tolerant — detection failures never interrupt training.
"""

import atexit
import contextlib
import fcntl
import functools
import hashlib
import importlib.util
import json
import math
import operator
import os
import signal
import sys
import threading
import time
import traceback
import weakref

_OUTPUT_PATH = os.environ.get(
    "AIBOM_DATASET_OUTPUT", "/results/dataset_detected.json"
)
_DEBUG = os.environ.get("AIBOM_DEBUG", "0") == "1"
# Read at startup: the hash seed is fixed when the interpreter starts, so a
# script that sets os.environ["PYTHONHASHSEED"] later changes nothing.
_STARTUP_PYTHONHASHSEED = os.environ.get("PYTHONHASHSEED")


def _dbg(msg):
    if _DEBUG:
        print(f"[AIBOM-DEBUG] {msg}", file=sys.stderr, flush=True)


def _dbg_exc(context):
    if _DEBUG:
        print(f"[AIBOM-DEBUG] EXCEPTION in {context}:", file=sys.stderr, flush=True)
        traceback.print_exc(file=sys.stderr)

class _NotifyingDict(dict):
    """runtime_info that schedules a (debounced) flush whenever it changes, so
    every one of the hook sites that records into it gets durable writes
    without each having to remember to ask for one (#107)."""

    # Only a real change notifies. _flush re-captures argv-derived values into
    # this dict on every run, and notifying on an identical write would
    # reschedule a flush forever.

    def __setitem__(self, key, value):
        changed = key not in self or self[key] != value
        super().__setitem__(key, value)
        if changed:
            _notify_change()

    def update(self, *args, **kwargs):
        incoming = dict(*args, **kwargs)
        changed = any(k not in self or self[k] != v for k, v in incoming.items())
        super().update(incoming)
        if changed:
            _notify_change()


_detected_datasets = []
_runtime_info = _NotifyingDict()
_lock = threading.Lock()
_hooks_installed = {}
# Maps a live dataset object (e.g. one returned by datasets.load_dataset) to
# its already-recorded entry, so a later DataLoader wrapping the same object
# updates that entry in place instead of recording it as a second dataset.
_dataset_registry = weakref.WeakKeyDictionary()
# Maps a HF dataset's (builder_name, config_name) to its already-recorded
# entry. Identity-based lookup above misses the very common case where a
# script transforms the loaded dataset (.map/.filter/.select/.shuffle, or
# re-fetching a split from a DatasetDict) before handing it to a DataLoader --
# each of those returns a *new* Dataset object, but builder_name/config_name
# survive the transform, so this catches it as the same underlying dataset.
# The split is part of the key, so a train DataLoader isn't attached to a
# later test load (#114). So is the builder's cache directory, whose name
# hashes the data_files and revision and which transforms keep writing into,
# so the same builder/config/split loaded from different files stays apart.
# (info.download_checksums would be the obvious choice, but it's None for
# local files.) A key two different loads still share -- e.g. an in-memory
# dataset with no cache files -- maps to None and matches nothing.
_hf_dataset_key_registry = {}


def _hf_dataset_key(dataset):
    info = getattr(dataset, "info", None)
    builder_name = getattr(info, "builder_name", None) if info else None
    if not builder_name:
        return None
    split = getattr(dataset, "split", None)
    cache_files = getattr(dataset, "cache_files", None)
    cache_dir = None
    if isinstance(cache_files, list) and cache_files and isinstance(cache_files[0], dict):
        cache_dir = os.path.dirname(cache_files[0].get("filename") or "") or None
    return (builder_name, getattr(info, "config_name", None), str(split) if split is not None else None, cache_dir)


def _register_hf_dataset(dataset, entry):
    """Caller holds _lock."""
    try:
        _dataset_registry[dataset] = entry
    except TypeError:
        _dbg("HF datasets hook: dataset object doesn't support weak references, skipping registry")
    key = _hf_dataset_key(dataset)
    if key is not None:
        if _hf_dataset_key_registry.get(key, entry) is not entry:
            entry = None
        _hf_dataset_key_registry[key] = entry


def _sole_hf_entry():
    """The only load_dataset entry, if there is exactly one. Caller holds _lock.

    Fallback for an HF dataset that matches no key: one saved with
    save_to_disk and reloaded (axolotl's prepared-dataset cache) lives in a
    different cache directory, and concatenating loads drops builder_name.
    ponytail: one recorded load is taken to be the source; a script that also
    trains on an unrelated load_from_disk dataset gets it merged in wrongly.
    """
    entries = [e for e in _detected_datasets if e.get("source") == "datasets.load_dataset"]
    return entries[0] if len(entries) == 1 else None


def _record(entry):
    _dbg(f"Recording dataset: {entry.get('dataset_name', '?')} via {entry.get('source', '?')}")
    with _lock:
        _detected_datasets.append(entry)
    _notify_change()


def _path_fingerprint(path):
    """SHA256 fingerprint from file metadata (names, sizes, mtimes) under path."""
    try:
        path = os.path.abspath(path)
        if not os.path.exists(path):
            return None
        h = hashlib.sha256()
        if os.path.isfile(path):
            st = os.stat(path)
            h.update(f"{path}\0{st.st_size}\0{int(st.st_mtime)}".encode())
        else:
            for dirpath, dirnames, filenames in os.walk(path):
                dirnames.sort()
                for fname in sorted(filenames):
                    fp = os.path.join(dirpath, fname)
                    try:
                        st = os.stat(fp)
                        rel = os.path.relpath(fp, path)
                        h.update(f"{rel}\0{st.st_size}\0{int(st.st_mtime)}".encode())
                    except OSError:
                        continue
        return h.hexdigest()
    except Exception:
        _dbg_exc("_path_fingerprint")
        return None


def _int_or_float(val):
    """`3` -> 3, `0.5` -> 0.5 (fractional epochs are valid)."""
    f = float(val)
    if f != f or f in (float("inf"), float("-inf")):
        raise ValueError(val)
    return int(f) if f.is_integer() else f


def _capture_training_args():
    """Best-effort extraction of common training args from sys.argv."""
    _arg_map = {
        "--epochs": ("epochs", _int_or_float),
        "--num-epochs": ("epochs", _int_or_float),
        "--num_epochs": ("epochs", _int_or_float),
        "--num-train-epochs": ("epochs", _int_or_float),
        "--num_train_epochs": ("epochs", _int_or_float),
        "--batch-size": ("batch_size", int),
        "--batch_size": ("batch_size", int),
        "--per-device-train-batch-size": ("batch_size", int),
        "--per_device_train_batch_size": ("batch_size", int),
        "--lr": ("learning_rate", float),
        "--learning-rate": ("learning_rate", float),
        "--learning_rate": ("learning_rate", float),
    }
    argv = sys.argv[:]
    for i, arg in enumerate(argv):
        key, _, val = arg.partition("=")
        if key not in _arg_map:
            continue
        # Per argument: one value `conv` can't parse (`--num_epochs $N`) must
        # not lose every argument after it.
        try:
            name, conv = _arg_map[key]
            if not val and i + 1 < len(argv):
                val = argv[i + 1]
            if val:
                _runtime_info[name] = conv(val)
                _dbg(f"Captured from argv: {name}={_runtime_info[name]}")
        except Exception:
            _dbg_exc("_capture_training_args")


_ACCELERATE_DISTRIBUTED_TYPE_STRATEGIES = {
    "fsdp": "fsdp",
    "deepspeed": "deepspeed",
    "multi_gpu": "data_parallel",
    "multi_cpu": "data_parallel",
}


def _capture_accelerate_config():
    """Resolve the real parallelization strategy from an --accelerate_config
    YAML file's actual content -- running here, inside the training
    container, is the only place this file is readable."""
    try:
        argv = sys.argv[:]
        path = None
        for i, arg in enumerate(argv):
            key, _, val = arg.partition("=")
            # `--config_file` is `accelerate launch`'s own spelling of the same flag.
            if key in ("--accelerate_config", "--accelerate-config", "--config_file", "--config-file"):
                if not val and i + 1 < len(argv):
                    val = argv[i + 1]
                path = val or None
                break
        if not path or not os.path.isfile(path):
            return
        try:
            import yaml
        except ImportError:
            _dbg("Accelerate config detection: PyYAML not available, skipping")
            return
        with open(path) as f:
            config = yaml.safe_load(f) or {}
        distributed_type = str(config.get("distributed_type", "")).lower()
        strategy = _ACCELERATE_DISTRIBUTED_TYPE_STRATEGIES.get(distributed_type)
        if strategy:
            _runtime_info["parallelization_strategy"] = strategy
            _dbg(f"Captured parallelization_strategy={strategy} from {path}")
        distributed = {}
        for key, name in (("num_processes", "world_size"), ("num_machines", "nodes")):
            if _positive_int(config.get(key)):
                distributed[name] = config[key]
        fsdp, deepspeed = config.get("fsdp_config"), config.get("deepspeed_config")
        if strategy == "fsdp":
            fsdp = fsdp if isinstance(fsdp, dict) else {}
            distributed["fsdp"] = _fsdp_summary(
                fsdp.get("fsdp_version"), fsdp.get("fsdp_sharding_strategy"),
                fsdp.get("fsdp_reshard_after_forward"), fsdp.get("fsdp_offload_params"))
        if strategy == "deepspeed":
            deepspeed = deepspeed if isinstance(deepspeed, dict) else {}
            distributed["deepspeed"] = _deepspeed_summary(
                deepspeed.get("zero_stage"), deepspeed.get("offload_optimizer_device"),
                deepspeed.get("offload_param_device"),
            ) or _deepspeed_json_summary(deepspeed.get("deepspeed_config_file"))
        if distributed:
            _runtime_info["accelerate_config_distributed"] = distributed
    except Exception:
        _dbg_exc("_capture_accelerate_config")


def _find_git_dir(start=None):
    """Walk upward from `start` (default: CWD) looking for `.git`, mirroring
    how `git` itself locates the repo root from any subdirectory -- the
    training script may not run from the exact directory a wrapper script
    `cd`'d into after cloning. Returns (worktree root, git dir), or None.

    `.git` is a file (`gitdir: <path>`) in a linked worktree or a submodule;
    walking past it would report the main checkout or the superproject
    instead (#113)."""
    path = os.path.abspath(start or os.getcwd())
    for _ in range(20):  # bound the walk -- avoid looping forever on a broken/circular mount
        dot_git = os.path.join(path, ".git")
        if os.path.isdir(dot_git):
            return path, dot_git
        if os.path.isfile(dot_git):
            with open(dot_git) as f:
                content = f.read().strip()
            if not content.startswith("gitdir:"):
                return None
            return path, os.path.normpath(os.path.join(path, content[len("gitdir:"):].strip()))
        parent = os.path.dirname(path)
        if parent == path:
            return None
        path = parent
    return None


def _find_repo():
    """The repo holding the running script, else the one around the CWD:
    `cd / && python /app/repo/train.py` has nothing above the CWD (#113)."""
    main_file = getattr(sys.modules.get("__main__"), "__file__", None)
    for script in (main_file, sys.argv[0] if sys.argv else None):
        if script and os.path.isfile(script):
            found = _find_git_dir(os.path.dirname(os.path.abspath(script)))
            if found:
                return found
    return _find_git_dir()


def _git_common_dir(git_dir):
    """A linked worktree's git dir holds only its own HEAD; refs and config
    live in the main repo's, named by its `commondir` file."""
    commondir = os.path.join(git_dir, "commondir")
    if os.path.isfile(commondir):
        with open(commondir) as f:
            return os.path.normpath(os.path.join(git_dir, f.read().strip()))
    return git_dir


def _is_sha(value):
    """A full SHA-1 or SHA-256 object name, the only thing a resolved ref holds."""
    return len(value) in (40, 64) and all(c in "0123456789abcdef" for c in value)


def _resolve_git_ref(git_dir, ref, _depth=0):
    """Resolve "ref: refs/heads/<branch>" to a commit SHA via the loose ref
    file, falling back to packed-refs (git packs infrequently-updated refs,
    e.g. right after a shallow clone). A detached HEAD's file already
    contains the SHA directly. A loose ref can itself be a symref, which is
    followed; anything that doesn't end in a SHA resolves to None (#113)."""
    ref = ref.strip()
    if not ref.startswith("ref:"):
        return ref if _is_sha(ref) else None
    if _depth >= 5:
        return None
    ref_path = ref[len("ref:"):].strip()
    loose = os.path.join(git_dir, ref_path)
    if os.path.isfile(loose):
        with open(loose) as f:
            return _resolve_git_ref(git_dir, f.read(), _depth + 1)
    packed = os.path.join(git_dir, "packed-refs")
    if os.path.isfile(packed):
        with open(packed) as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) == 2 and parts[1] == ref_path:
                    return parts[0] if _is_sha(parts[0]) else None
    return None


# SECURITY: keep this logic identical to postprocess.py's redact_git_url -- the two can't share a
# module (see tests/test_redact_git_url_sync.py, which fails if they drift).
def _redact_git_url(url):
    """Strip credentials from a git remote URL before it's recorded (#102).

    `git clone https://user:TOKEN@host/repo` stores that URL verbatim in
    .git/config and in the container command, and it would otherwise land in
    the signed, immutable AIBOM. For http(s)/ftp the whole userinfo goes (a
    bare username is often the token itself, e.g. a GitHub PAT); for other
    schemes (ssh://git@host/...) only a password is dropped, since the
    username isn't secret. scp-style `git@host:org/repo` has no scheme and is
    returned as-is for the same reason. Query string and fragment are dropped
    entirely (`?token=`, `?private_token=`), since they never identify the
    repository.
    """
    if not isinstance(url, str) or "://" not in url:
        return url
    # Imported here, not at module level: this runs as sitecustomize in the
    # user's own process at startup, and this is only needed at exit.
    import re
    import urllib.parse
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        # Unparseable (e.g. malformed IPv6 host): drop anything that looks
        # like userinfo, query and fragment rather than risk keeping a secret.
        return re.sub(r"[?#].*$", "", re.sub(r"^([^:/]+://)[^/]*@", r"\1", url))
    netloc = parts.netloc
    if "@" in netloc:
        userinfo, _, hostport = netloc.rpartition("@")
        if parts.scheme.lower() in ("http", "https", "ftp", "ftps"):
            netloc = hostport
        else:
            user = userinfo.partition(":")[0]
            netloc = f"{user}@{hostport}" if user else hostport
    return f"{parts.scheme}://{netloc}{parts.path}"


def _git_remote_url(git_dir):
    """Best-effort read of the "origin" remote URL straight out of
    .git/config, without shelling out to the git binary (which isn't
    guaranteed to be installed in the training image). Without an "origin"
    (`git clone --origin upstream`), the first remote listed (#113)."""
    config_path = os.path.join(git_dir, "config")
    if not os.path.isfile(config_path):
        return None
    try:
        import configparser
        parser = configparser.ConfigParser(strict=False)
        parser.read(config_path)
        remotes = [sec for sec in parser.sections() if sec.startswith('remote "')]
        if remotes:
            section = 'remote "origin"' if 'remote "origin"' in remotes else remotes[0]
            return _redact_git_url(parser.get(section, "url", fallback=None))
    except Exception:
        _dbg_exc("_git_remote_url")
    return None


def _git_dirty(worktree_dir):
    """Best-effort `git status --porcelain` if the git binary happens to be
    installed in the training image (not guaranteed). Returns None -- not
    False -- when it can't be determined, so callers don't misreport a clean
    tree they never actually checked. Untracked files don't count (`-uno`):
    checkpoints and logs written inside the repo aren't changes to the code
    that ran (#113)."""
    try:
        import subprocess
        result = subprocess.run(
            ["git", "status", "--porcelain", "-uno"],
            cwd=worktree_dir, capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return None
        return bool(result.stdout.strip())
    except Exception:
        return None


def _capture_git_provenance(check_dirty=True):
    """Best-effort git provenance from a .git directory in the working
    tree -- covers workloads that `git clone` their training code at
    runtime rather than baking it into the image (see IMPLEMENTATION_NOTES.md's git
    provenance section). Ranked above postprocess.py's command-line `git
    clone` parsing: this reflects the actual final checked-out state
    (after any `git checkout`/`git pull` beyond the initial clone), not
    just what the command said it intended to do.
    """
    try:
        found = _find_repo()
        if not found:
            return
        worktree, git_dir = found
        common_dir = _git_common_dir(git_dir)
        head_path = os.path.join(git_dir, "HEAD")
        if not os.path.isfile(head_path):
            return
        with open(head_path) as f:
            head = f.read().strip()
        commit = _resolve_git_ref(common_dir, head)
        if not commit:
            return
        info = {"git_commit": commit}
        if head.startswith("ref:"):
            # The whole name after refs/heads/: `feature/foo`, not `foo` (#113).
            branch = head[len("ref:"):].strip()
            if branch.startswith("refs/heads/"):
                branch = branch[len("refs/heads/"):]
            info["git_branch"] = branch
        remote = _git_remote_url(common_dir)
        if remote:
            info["git_repository"] = remote
        # `git status` can take up to its 10s timeout; skipped when flushing
        # from a signal handler, where the kubelet's grace period is ticking.
        dirty = _git_dirty(worktree) if check_dirty else None
        if dirty is not None:
            info["git_dirty"] = dirty
        with _lock:
            _runtime_info.update(info)
        _dbg(f"Captured git provenance: {info}")
    except Exception:
        _dbg_exc("_capture_git_provenance")


# ── Durable, concurrent-safe output (#107) ──────────────────────────────────
#
# This file is written by every Python process in every instrumented
# container of the pod -- each torchrun rank, spawned DataLoader worker, the
# launcher itself, `pip` -- so a write has to (a) take turns with the others
# and (b) never leave a half-written file for the sidecar to read. It also
# can't wait for atexit alone: SIGKILL (OOM, the kubelet's grace-period kill)
# and SIGTERM under Python's default handler skip it, so changes are flushed
# shortly after they happen, and SIGTERM flushes before dying.

_FLUSH_DEBOUNCE_S = float(os.environ.get("AIBOM_FLUSH_DEBOUNCE_S", "2"))
_LOCK_TIMEOUT_S = 5.0

_durable_flush_enabled = False
_flush_timer = None
_flush_timer_lock = threading.Lock()
_git_captured = False
_fork_handler_registered = False
_sigterm_installed = False


def _notify_change():
    """Schedule one flush ~_FLUSH_DEBOUNCE_S from now unless one is already
    pending, so a burst of detections costs a single write. A no-op until
    hooks are actually installed."""
    global _flush_timer
    if not _durable_flush_enabled:
        return
    # Bounded wait, not `with`: this is reachable from the SIGTERM handler
    # (via _flush's argv captures), which may have interrupted this very
    # function mid-hold.
    if not _flush_timer_lock.acquire(timeout=0.2):
        return
    try:
        if _flush_timer is not None:
            return
        timer = threading.Timer(_FLUSH_DEBOUNCE_S, _debounced_flush)
        timer.daemon = True
        _flush_timer = timer
    finally:
        _flush_timer_lock.release()
    try:
        timer.start()
    except RuntimeError:  # interpreter shutting down; atexit will flush
        with _flush_timer_lock:
            _flush_timer = None


def _debounced_flush():
    global _flush_timer
    with _flush_timer_lock:
        _flush_timer = None
    try:
        _flush(final=False)
    except Exception:
        _dbg_exc("_debounced_flush")


def _cancel_pending_flush():
    global _flush_timer
    with _flush_timer_lock:
        timer, _flush_timer = _flush_timer, None
    if timer is not None:
        timer.cancel()


def _after_fork_in_child():
    """A forked child (DataLoader worker, multiprocessing) inherits our locks
    in whatever state another thread left them -- including held by the
    flush timer thread, which doesn't exist in the child -- and a Timer
    object that will never fire. Start clean."""
    global _lock, _flush_timer, _flush_timer_lock, _git_captured, _training_activity
    _lock = threading.Lock()
    _flush_timer_lock = threading.Lock()
    _flush_timer = None
    _git_captured = False
    # The child records determinism flags only if it does training work of
    # its own; a DataLoader worker doesn't.
    _training_activity = False


def _on_sigterm(signum, frame):
    """Flush, then die exactly as the default handler would have: restore
    SIG_DFL and re-deliver, so the process still terminates by SIGTERM (exit
    status 143) rather than exiting cleanly. Only installed when the handler
    was SIG_DFL at startup; an application handler (uvicorn, torchrun) makes
    its own orderly exit, which runs atexit."""
    try:
        _flush(final=True, in_signal=True)
    except Exception:
        pass
    signal.signal(signum, signal.SIG_DFL)
    os.kill(os.getpid(), signum)


def _register_durable_flush():
    """Wire up everything that gets data out before the process disappears.
    Called from each install path; safe to call more than once."""
    global _durable_flush_enabled, _fork_handler_registered, _sigterm_installed
    _durable_flush_enabled = True
    atexit.register(_flush)
    if not _fork_handler_registered and hasattr(os, "register_at_fork"):
        os.register_at_fork(after_in_child=_after_fork_in_child)
        _fork_handler_registered = True
    if not _sigterm_installed:
        try:
            if signal.getsignal(signal.SIGTERM) == signal.SIG_DFL:
                signal.signal(signal.SIGTERM, _on_sigterm)
                _sigterm_installed = True
        except (ValueError, OSError):  # not the main thread / no signals
            _dbg("SIGTERM handler not installed (not main thread)")


@contextlib.contextmanager
def _output_lock(path, timeout_s):
    """Exclusive flock on a sidecar-file next to the output, taken with a
    bounded wait so a stuck holder can never hang process exit."""
    lock_path = path + ".lock"
    with open(lock_path, "a") as f:  # closing releases the flock
        deadline = time.monotonic() + timeout_s
        while True:
            try:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError(f"could not lock {lock_path} within {timeout_s}s")
                time.sleep(0.02)
        yield


# Fields that tell two loads apart: the same builder with different files,
# splits or configs is a different dataset (#114).
_DATASET_IDENTITY_KEYS = (
    "dataset_name", "source", "config_name", "split", "revision",
    "data_files", "data_dir", "root", "path",
)


def _dataset_identity(entry):
    return json.dumps([entry.get(k) for k in _DATASET_IDENTITY_KEYS], sort_keys=True, default=str)


def _merge_output(existing, data, info):
    """Fold this process's detections into what other processes already
    wrote. Datasets are deduped by _dataset_identity; a repeat updates the
    stored entry, so a batch_size or seen_via added after an earlier flush
    isn't lost. runtime_info is
    last-writer-wins per key, except the git_* keys, which are one
    observation of one checkout: a process that captured any replaces the
    whole group, so a commit from one working tree is never labelled with the
    branch (or dirty flag) of another, and software_versions, whose
    package lists are unioned."""
    existing_ds = existing.get("datasets", [])
    by_key = {_dataset_identity(e): e for e in existing_ds}
    for entry in data:
        key = _dataset_identity(entry)
        old = by_key.get(key)
        if old is None:
            existing_ds.append(entry)
            by_key[key] = entry
            continue
        seen_via = old.get("seen_via", [])
        seen_via = seen_via + [v for v in entry.get("seen_via", []) if v not in seen_via]
        old.update(entry)
        if seen_via:
            old["seen_via"] = seen_via

    output = {"datasets": existing_ds}
    merged_info = existing.get("runtime_info", {})
    if any(k.startswith("git_") for k in info):
        merged_info = {k: v for k, v in merged_info.items() if not k.startswith("git_")}
    # Each process lists only the libraries it imported, so the package lists
    # are unioned: a launcher that imported only torch, and exits after its
    # ranks, mustn't replace a rank's fuller list.
    old_sv, new_sv = merged_info.get("software_versions"), info.get("software_versions")
    if isinstance(old_sv, dict) and isinstance(new_sv, dict):
        packages = {**(old_sv.get("packages") or {}), **(new_sv.get("packages") or {})}
        info = {**info, "software_versions": {**old_sv, **new_sv, "packages": packages}}
    merged_info.update(info)
    if merged_info:
        output["runtime_info"] = merged_info
    return output


def _flush(final=True, in_signal=False):
    """Write what this process has detected into the shared output file.

    final=False is a periodic flush while the process is still running; it
    still writes everything, but only captures git provenance once. in_signal
    avoids blocking on `_lock` (the signal may have interrupted the very
    thread holding it) and skips the slow `git status`.
    """
    global _git_captured
    _capture_training_args()
    _capture_accelerate_config()
    if _training_activity:
        _capture_determinism_flags()
        _capture_precision_flags()
        _capture_distributed_env()

    got_lock = _lock.acquire(timeout=0.5 if in_signal else -1)
    try:
        if not _detected_datasets and not _runtime_info:
            _dbg("Flush: nothing detected, skipping write")
            return
    finally:
        if got_lock:
            _lock.release()

    # Only a process that detected something of its own records git
    # provenance. Capturing it unconditionally made every Python process that
    # happened to run in a checkout (`pip`, a launcher shim) overwrite the
    # training process's commit/branch with its own (#107).
    if final or not _git_captured:
        _capture_git_provenance(check_dirty=not in_signal)
        _git_captured = True
    # Not from a signal handler: the first lookup reads package metadata off
    # disk, and the periodic flush has normally done it long before.
    if not in_signal:
        _capture_software_versions()

    got_lock = _lock.acquire(timeout=0.5 if in_signal else -1)
    try:
        data = _detected_datasets.copy()
        info = dict(_runtime_info)
    finally:
        if got_lock:
            _lock.release()

    _dbg(f"Flushing {len(data)} dataset(s) to {_OUTPUT_PATH} (final={final})")
    try:
        os.makedirs(os.path.dirname(_OUTPUT_PATH) or ".", exist_ok=True)
        with _output_lock(_OUTPUT_PATH, 1.0 if in_signal else _LOCK_TIMEOUT_S):
            existing = {}
            if os.path.exists(_OUTPUT_PATH):
                try:
                    with open(_OUTPUT_PATH) as f:
                        existing = json.load(f)
                    _dbg(f"Merging with existing file ({len(existing.get('datasets', []))} datasets)")
                except Exception:
                    pass
            output = _merge_output(existing, data, info)
            # Write-then-rename in the same directory: the sidecar (and the
            # next writer) only ever sees a complete file, never a truncated
            # one mid-write.
            tmp_path = f"{_OUTPUT_PATH}.{os.getpid()}.tmp"
            with open(tmp_path, "w") as f:
                json.dump(output, f, indent=2, default=str)
            os.replace(tmp_path, _OUTPUT_PATH)
        _dbg(f"Flush succeeded: {_OUTPUT_PATH} ({len(output['datasets'])} datasets)")
        # The ConfigMap write itself now happens in the aibom-dataset-sidecar
        # container (dataset_sidecar.py), which watches this file from
        # outside this process's control and signs what it reads -- see the
        # module docstring above and #47.
    except Exception:
        _dbg_exc("_flush")


# ── PyTorch DataLoader hook ──────────────────────────────────────────────────

def _install_dataloader_hook():
    try:
        import torch.utils.data as tud
        import torch
    except ImportError:
        _dbg("DataLoader hook: torch not available, skipping")
        return

    if "dataloader" in _hooks_installed:
        return
    # Look up what's being patched before marking the hook installed, so a
    # failed lookup leaves it retryable instead of silently "installed".
    _orig_init = tud.DataLoader.__init__
    _hooks_installed["dataloader"] = True

    with _lock:
        _runtime_info["framework"] = "PyTorch"
        _runtime_info["framework_version"] = torch.__version__
    _dbg(f"DataLoader hook: installed (torch {torch.__version__})")

    def _patched_init(self, dataset=None, *args, **kwargs):
        global _training_activity
        _orig_init(self, dataset, *args, **kwargs)
        try:
            _training_activity = True
            batch_size = getattr(self, "batch_size", None)
            sampling = _dataloader_sampling(self)
            with _lock:
                existing = _dataset_registry.get(dataset) if dataset is not None else None
                if existing is None and dataset is not None:
                    key = _hf_dataset_key(dataset)
                    if key is not None:
                        existing = _hf_dataset_key_registry.get(key)
                    if existing is None and key not in _hf_dataset_key_registry and hasattr(dataset, "info"):
                        existing = _sole_hf_entry()
            if existing is not None:
                _dbg(f"DataLoader hook: dataset already recorded via {existing.get('source', '?')}, merging")
                # An eval loader on the same dataset (a DatasetDict entry
                # covers every split) must not replace the train batch size.
                is_train = str(getattr(dataset, "split", "")).startswith("train") or getattr(dataset, "train", None) is True
                if batch_size is not None and ("batch_size" not in existing or is_train):
                    existing["batch_size"] = batch_size
                # First loader wins: accelerate's prepare() rebuilds Trainer's
                # loader around a sharded batch sampler, hiding the real one.
                if sampling and "sampling" not in existing:
                    existing["sampling"] = sampling
                seen_via = existing.setdefault("seen_via", [])
                if "torch.utils.data.DataLoader" not in seen_via:
                    seen_via.append("torch.utils.data.DataLoader")
                _notify_change()
                return

            entry = _inspect_torch_dataset(dataset)
            if batch_size is not None:
                entry["batch_size"] = batch_size
            if sampling:
                entry["sampling"] = sampling
            _record(entry)
        except Exception:
            _dbg_exc("DataLoader._patched_init")

    tud.DataLoader.__init__ = _patched_init


_DEFAULT_BATCH_SAMPLER = "torch.utils.data.sampler.BatchSampler"


def _class_name(obj):
    cls = type(obj)
    return f"{cls.__module__}.{cls.__qualname__}"


def _dataloader_sampling(loader):
    """How a constructed DataLoader orders and batches its data (#177).

    Read from the loader's resolved sampler rather than its kwargs: shuffle=True
    is only ever visible as the RandomSampler it builds, and Trainer passes a
    sampler (LengthGroupedSampler for group_by_length) instead of shuffle.
    """
    out = {}
    batch_sampler = getattr(loader, "batch_sampler", None)
    if batch_sampler is None:
        # No automatic batching: loader.sampler yields the indices itself.
        sampler, drop_last = getattr(loader, "sampler", None), getattr(loader, "drop_last", None)
    else:
        if _class_name(batch_sampler) != _DEFAULT_BATCH_SAMPLER:
            out["batch_sampler"] = _class_name(batch_sampler)
        # Read through the batch sampler only: given one, loader.sampler is a
        # placeholder SequentialSampler and loader.drop_last a placeholder
        # False (the loader's own BatchSampler wraps the real ones).
        # accelerate's BatchSamplerShard keeps the batch sampler it wraps in
        # .batch_sampler and has no .sampler. A sampler not found this way is
        # left out rather than guessed.
        sampler = drop_last = None
        bs = batch_sampler
        for _ in range(4):
            if drop_last is None and isinstance(getattr(bs, "drop_last", None), bool):
                drop_last = bs.drop_last
            sampler = getattr(bs, "sampler", None)
            bs = getattr(bs, "batch_sampler", None)
            if sampler is not None or bs is None:
                break
    if sampler is not None:
        name = _class_name(sampler)
        out["sampler"] = name
        short = type(sampler).__name__
        if short == "RandomSampler":
            out["shuffle"] = True
            if getattr(sampler, "replacement", False) is True:
                out["replacement"] = True
        elif short == "SequentialSampler":
            out["shuffle"] = False
        elif short == "DistributedSampler":
            if isinstance(getattr(sampler, "shuffle", None), bool):
                out["shuffle"] = sampler.shuffle
            seed = _seed_value(getattr(sampler, "seed", None))
            if seed is not None:
                out["sampler_seed"] = seed
            if isinstance(getattr(sampler, "drop_last", None), bool):
                out["sampler_drop_last"] = sampler.drop_last
        # Anything else (LengthGroupedSampler, custom) is only named: whether
        # it shuffles isn't knowable from its class.
    if isinstance(drop_last, bool):
        out["drop_last"] = drop_last
    num_workers = getattr(loader, "num_workers", None)
    if isinstance(num_workers, int) and not isinstance(num_workers, bool):
        out["num_workers"] = num_workers
    generator = getattr(loader, "generator", None)
    if generator is not None:
        try:
            seed = _seed_value(generator.initial_seed())
        except Exception:
            seed = None
        if seed is not None:
            out["generator_seed"] = seed
    return out


def _inspect_torch_dataset(dataset):
    cls = type(dataset)
    entry = {
        "source": "torch.utils.data.DataLoader",
        "dataset_class": f"{cls.__module__}.{cls.__qualname__}",
    }

    for attr in ("root", "data_path", "data_dir", "filename", "path"):
        val = getattr(dataset, attr, None)
        if val is not None:
            entry["path"] = str(val)
            break

    if hasattr(dataset, "train"):
        entry["split"] = "train" if dataset.train else "test"

    if hasattr(dataset, "transform"):
        t = dataset.transform
        entry["transform"] = type(t).__name__ if t else None

    name = getattr(dataset, "name", None) or cls.__name__
    entry["dataset_name"] = name

    if hasattr(dataset, "url"):
        entry["url"] = str(dataset.url)
    if hasattr(dataset, "urls"):
        urls = dataset.urls
        if isinstance(urls, (list, tuple)):
            entry["urls"] = [str(u) for u in urls[:5]]
        elif isinstance(urls, dict):
            entry["urls"] = {k: str(v) for k, v in list(urls.items())[:5]}

    if entry.get("path"):
        fp = _path_fingerprint(entry["path"])
        if fp:
            entry["fingerprint"] = fp

    return entry


# ── HuggingFace datasets.load_dataset hook ───────────────────────────────────

# datasets' packaged builders that read files named by data_files/data_dir.
_FILE_BUILDERS = {
    "json", "csv", "parquet", "text", "arrow", "pandas", "xml",
    "imagefolder", "audiofolder", "videofolder", "webdataset",
}


def _data_files_name(entry):
    """Their common directory, the single file, or the files joined."""
    files = entry.get("data_files")
    if isinstance(files, dict):
        files = [f for v in files.values() for f in (v if isinstance(v, list) else [v])]
    if not files:
        return entry.get("data_dir")
    if len(files) == 1:
        return files[0]
    return os.path.commonprefix(files).rpartition("/")[0] or ", ".join(files)

def _install_hf_datasets_hook():
    try:
        import datasets
    except ImportError:
        _dbg("HF datasets hook: datasets not available, skipping")
        return

    if "hf_datasets" in _hooks_installed:
        return
    _orig_load = datasets.load_dataset
    _hooks_installed["hf_datasets"] = True
    _dbg("HF datasets hook: installed, patching datasets.load_dataset")

    def _patched_load(path, *args, **kwargs):
        _dbg(f"HF datasets hook: load_dataset({path!r}) called")
        result = _orig_load(path, *args, **kwargs)
        try:
            entry = {
                "source": "datasets.load_dataset",
                "dataset_name": str(path),
            }
            name = args[0] if args else kwargs.get("name")
            if name:
                entry["config_name"] = str(name)

            split = kwargs.get("split")
            if split:
                entry["split"] = str(split)

            revision = kwargs.get("revision")
            if revision:
                entry["revision"] = str(revision)

            data_dir = kwargs.get("data_dir")
            if data_dir:
                entry["data_dir"] = str(data_dir)

            data_files = kwargs.get("data_files")
            if data_files:
                if isinstance(data_files, str):
                    entry["data_files"] = [data_files]
                elif isinstance(data_files, (list, tuple)):
                    entry["data_files"] = [str(f) for f in data_files[:10]]
                elif isinstance(data_files, dict):
                    entry["data_files"] = {
                        k: ([str(x) for x in v] if isinstance(v, list) else str(v))
                        for k, v in data_files.items()
                    }

            # load_dataset("json", data_files=...) is named after its files,
            # not the builder, so two local loads don't share a name (#114).
            if entry["dataset_name"] in _FILE_BUILDERS:
                files_name = _data_files_name(entry)
                if files_name:
                    entry["builder"] = entry["dataset_name"]
                    entry["dataset_name"] = files_name

            ds = result
            parts = [result]
            if isinstance(result, dict) and result:
                parts = list(result.values())
                ds = parts[0]
                entry["splits"] = list(result.keys())
                _dbg(f"HF datasets hook: result is DatasetDict with splits {entry['splits']}, using first for metadata")

            if hasattr(ds, "_fingerprint"):
                entry["fingerprint"] = str(ds._fingerprint)
            elif hasattr(ds, "info") and ds.info:
                if hasattr(ds.info, "download_checksums") and ds.info.download_checksums:
                    checksums = list(ds.info.download_checksums.values())
                    if checksums and isinstance(checksums[0], dict):
                        entry["fingerprint"] = checksums[0].get("checksum")

            if hasattr(ds, "info") and ds.info:
                info = ds.info
                if hasattr(info, "version") and info.version:
                    entry["version"] = str(info.version)
                if hasattr(info, "license") and info.license:
                    entry["license"] = str(info.license)
                if hasattr(info, "description") and info.description:
                    entry["description"] = info.description[:200]

            _record(entry)
            # Every split of a DatasetDict belongs to this entry.
            with _lock:
                for part in parts:
                    _register_hf_dataset(part, entry)
        except Exception:
            _dbg_exc("HF datasets._patched_load")
        return result

    datasets.load_dataset = _patched_load


# ── torchvision.datasets hook ────────────────────────────────────────────────

_TORCHVISION_DATASETS = [
    "MNIST", "FashionMNIST", "KMNIST", "EMNIST",
    "CIFAR10", "CIFAR100",
    "ImageNet", "ImageFolder", "DatasetFolder",
    "CelebA", "LSUN", "STL10", "SVHN",
    "VOCDetection", "VOCSegmentation",
    "CocoDetection", "CocoCaptions",
    "Flickr8k", "Flickr30k",
    "Places365",
]


def _install_torchvision_hook():
    try:
        import torchvision.datasets as tvd
    except ImportError:
        _dbg("torchvision hook: torchvision not available, skipping")
        return

    if "torchvision" in _hooks_installed:
        return
    _hooks_installed["torchvision"] = True
    _dbg("torchvision hook: installed")

    patched = set()
    for name in _TORCHVISION_DATASETS:
        cls = getattr(tvd, name, None)
        if cls is None:
            continue
        patched.add(cls)

        _orig = cls.__init__

        def _make_patched(original, dataset_name, owner):
            def _patched(self, *args, **kwargs):
                original(self, *args, **kwargs)
                # A subclass runs its parent's patched __init__ too (CIFAR100
                # inherits CIFAR10's, EMNIST calls MNIST's): only the
                # most-derived patched class records (#114).
                if next((c for c in type(self).__mro__ if c in patched), None) is not owner:
                    return
                try:
                    entry = {
                        "source": f"torchvision.datasets.{dataset_name}",
                        "dataset_name": dataset_name,
                    }
                    if args:
                        entry["root"] = str(args[0])
                    elif "root" in kwargs:
                        entry["root"] = str(kwargs["root"])

                    train = kwargs.get("train")
                    if train is not None:
                        entry["split"] = "train" if train else "test"
                    elif len(args) > 1 and isinstance(args[1], bool):
                        entry["split"] = "train" if args[1] else "test"

                    if "split" in kwargs:
                        entry["split"] = str(kwargs["split"])

                    if "download" in kwargs:
                        entry["download"] = kwargs["download"]

                    if entry.get("root"):
                        fp = _path_fingerprint(entry["root"])
                        if fp:
                            entry["fingerprint"] = fp

                    _record(entry)
                    # So a DataLoader over it merges in instead of adding a
                    # second entry.
                    with _lock:
                        _dataset_registry[self] = entry
                except Exception:
                    _dbg_exc(f"torchvision._patched({dataset_name})")

            return _patched

        cls.__init__ = _make_patched(_orig, name, cls)


# ── webdataset hook ──────────────────────────────────────────────────────────

def _install_webdataset_hook():
    try:
        import webdataset as wds
    except ImportError:
        _dbg("webdataset hook: webdataset not available, skipping")
        return

    if "webdataset" in _hooks_installed:
        return
    _orig_init = wds.WebDataset.__init__
    _hooks_installed["webdataset"] = True
    _dbg("webdataset hook: installed")

    def _patched_init(self, urls, *args, **kwargs):
        _orig_init(self, urls, *args, **kwargs)
        try:
            entry = {
                "source": "webdataset.WebDataset",
                "dataset_name": "WebDataset",
            }
            if isinstance(urls, str):
                entry["urls"] = [urls]
            elif isinstance(urls, (list, tuple)):
                entry["urls"] = [str(u) for u in urls[:10]]
            _record(entry)
        except Exception:
            _dbg_exc("webdataset._patched_init")

    wds.WebDataset.__init__ = _patched_init


# ── transformers Trainer / model hook ────────────────────────────────────────
#
# CLI-argument parsing (postprocess.py's detect_trl_from_command) only sees
# training config passed as literal flags on a recognized CLI (trl sft/dpo).
# The far more common case -- a custom script that builds TrainingArguments
# and calls Model.from_pretrained() directly in Python -- exposes nothing on
# the command line at all. Hooking the real objects here, inside the training
# process, catches that case regardless of how the script assembled its
# config (CLI, YAML, hardcoded).

_QUANT_CLASS_NAME_HINTS = (
    ("BitsAndBytes", "bitsandbytes"),
    ("GPTQ", "gptq"),
    ("AWQ", "awq"),
    ("HQQ", "hqq"),
    ("AQLM", "aqlm"),
)


def _gpu_device_count(device_map):
    """How many accelerators a device_map places the model on, or None if it
    can't be told (an unresolved "auto"/"balanced" string). cpu/disk/meta
    offload doesn't count: "auto" on one GPU with cpu offload is 1 (#109)."""
    if not isinstance(device_map, dict):
        device_map = {"": device_map}
    devices = set()
    for v in device_map.values():
        d = str(v)
        if d in ("cpu", "disk", "meta"):
            continue
        if d in ("auto", "balanced", "balanced_low_0", "sequential"):
            return None
        if d.startswith("cuda:"):
            d = d[len("cuda:"):]
        devices.add("0" if d == "cuda" else d)
    return len(devices)


# transformers loads its classes lazily: `transformers.TrainingArguments`
# imports transformers.training_args on first access. Reading it from a hook
# forced that import at whatever moment the hook ran -- e.g. while peft (whose
# __init__ imports transformers) was half-initialized, so training_args'
# `from peft import PeftMixedModel` raised. So each class is patched when its
# own module finishes importing (the transformers.training_args and
# transformers.modeling_utils triggers), and the hooks only read sys.modules.
# Immediate mode (install_hooks(), called mid-script) has no finder to wait
# on, so it imports them here, as its other installers import their packages.
def _install_transformers_hook():
    for name, install in (("transformers.training_args", _install_training_args_hook),
                          ("transformers.modeling_utils", _install_from_pretrained_hook)):
        try:
            importlib.import_module(name)
        except Exception as e:
            _dbg(f"transformers hook: can't import {name} ({e!r}), skipping")
            continue
        install()


def _install_training_args_hook():
    training_args = sys.modules.get("transformers.training_args")
    cls = getattr(training_args, "TrainingArguments", None)
    if cls is None or "transformers_training_args" in _hooks_installed:
        return
    _orig_ta_post_init = cls.__post_init__
    _hooks_installed["transformers_training_args"] = True
    _dbg("transformers hook: installed, patching TrainingArguments")

    # TrainingArguments is a dataclass, and so are its subclasses (trl's
    # SFTConfig/DPOConfig/GRPOConfig, Seq2SeqTrainingArguments, ...). Each
    # subclass gets its own generated __init__ that never calls the parent's,
    # so patching TrainingArguments.__init__ only ever caught the base class.
    # Every generated __init__ does call __post_init__, and subclasses that
    # override it call super().__post_init__(), so hooking that catches them
    # all -- after TrainingArguments' own normalization has run.
    def _patched_ta_post_init(self, *args, **kwargs):
        global _training_activity
        _orig_ta_post_init(self, *args, **kwargs)
        try:
            _training_activity = True
            info = {"training_framework": "transformers.Trainer"}
            if getattr(self, "learning_rate", None) is not None:
                info["learning_rate"] = self.learning_rate
            if getattr(self, "per_device_train_batch_size", None) is not None:
                info["batch_size"] = self.per_device_train_batch_size
            if getattr(self, "num_train_epochs", None) is not None:
                info["epochs"] = self.num_train_epochs
            if getattr(self, "optim", None) is not None:
                # TrainingArguments.__post_init__ normalizes a plain string like
                # "adamw_torch_fused" into an OptimizerNames enum member, whose
                # default str() is "OptimizerNames.ADAMW_TORCH_FUSED" rather than
                # the plain value.
                info["optimizer"] = getattr(self.optim, "value", None) or str(self.optim)
            for attr in ("adam_beta1", "adam_beta2", "adam_epsilon", "weight_decay",
                         "warmup_ratio", "warmup_steps", "optim_args"):
                if getattr(self, attr, None) is not None:
                    info[attr] = getattr(self, attr)
            if getattr(self, "lr_scheduler_type", None) is not None:
                # A SchedulerType enum after normalization, like optim.
                scheduler = self.lr_scheduler_type
                info["lr_scheduler_type"] = getattr(scheduler, "value", None) or str(scheduler)
            if getattr(self, "seed", None) is not None:
                info["random_seed"] = self.seed
            # Seeds the Trainer's data sampler separately from `seed`.
            if getattr(self, "data_seed", None) is not None:
                info["data_seed"] = self.data_seed
            if getattr(self, "full_determinism", False):
                info["full_determinism"] = True
            # Mixed precision is the compute dtype, not the weights' dtype
            # (from_pretrained's), so it's kept under its own key (#109).
            if getattr(self, "bf16", False):
                info["mixed_precision"] = "bf16"
            elif getattr(self, "fp16", False):
                info["mixed_precision"] = "fp16"
            try:
                distributed = _training_args_distributed(self)
                if distributed:
                    info["training_args_distributed"] = distributed
            except Exception:
                _dbg_exc("_training_args_distributed")
            with _lock:
                _runtime_info.update(info)
            _dbg(f"transformers hook: captured TrainingArguments {info}")
        except Exception:
            _dbg_exc("transformers._patched_ta_post_init")

    cls.__post_init__ = _patched_ta_post_init


def _record_requested_model(name, kwargs):
    """What a load asked for, recorded before it runs, so a process killed
    mid-load (an OOM loading full-precision weights on every rank) still
    reports it. The finished load overwrites these with the model's own
    values; a load that raises removes them."""
    info = {"model_name": str(name)}
    dtype = kwargs.get("dtype", kwargs.get("torch_dtype"))
    if dtype is not None and dtype != "auto":
        info["dtype"] = str(dtype).replace("torch.", "")
    if kwargs.get("device_map") is not None:
        info["model_device_map"] = str(kwargs["device_map"])
    try:
        with _lock:
            _runtime_info.update(info)
    except Exception:
        _dbg_exc("transformers._record_requested_model")
        return {}
    return info


def _install_from_pretrained_hook():
    modeling_utils = sys.modules.get("transformers.modeling_utils")
    cls = getattr(modeling_utils, "PreTrainedModel", None)
    if cls is None or "transformers_from_pretrained" in _hooks_installed:
        return
    _orig_from_pretrained = cls.from_pretrained.__func__
    _hooks_installed["transformers_from_pretrained"] = True
    _dbg("transformers hook: installed, patching PreTrainedModel.from_pretrained")

    # Only the process's first model load is recorded: a DPO reference model,
    # reward model or distillation teacher loaded afterwards would otherwise
    # replace the model being trained (#109). Claimed on entry, so a load
    # nested inside another's from_pretrained doesn't win over its caller.
    # ponytail: assumes the trained model loads first; a teacher/reward model
    # loaded before it is still misreported (recording every load with a
    # role would fix that).
    claimed = [False]

    def _patched_from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):
        primary = not claimed[0]
        claimed[0] = True
        requested = _record_requested_model(pretrained_model_name_or_path, kwargs) if primary else {}
        try:
            model = _orig_from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs)
        except BaseException:
            if primary:
                claimed[0] = False
                with _lock:
                    for key, value in requested.items():
                        if _runtime_info.get(key) == value:
                            del _runtime_info[key]
            raise
        if not primary:
            return model
        try:
            info = {"model_name": str(pretrained_model_name_or_path)}

            device_map = kwargs.get("device_map")
            if device_map is not None:
                info["model_device_map"] = str(device_map)
                count = _gpu_device_count(getattr(model, "hf_device_map", None) or device_map)
                if count is not None:
                    info["model_device_count"] = count

            config = getattr(model, "config", None)
            architectures = getattr(config, "architectures", None) if config else None
            if architectures:
                info["model_architecture"] = architectures[0]

            dtype = getattr(model, "dtype", None)
            if dtype is not None:
                info["dtype"] = str(dtype).replace("torch.", "")

            quant_config = getattr(config, "quantization_config", None) if config else None
            if quant_config is not None:
                method = getattr(quant_config, "quant_method", None)
                # transformers' QuantizationMethod is a (str, Enum), whose
                # str() is "QuantizationMethod.BITS_AND_BYTES" (#109).
                method = (getattr(method, "value", None) or str(method)) if method else None
                if not method and (
                    getattr(quant_config, "load_in_4bit", False)
                    or getattr(quant_config, "load_in_8bit", False)
                ):
                    method = "bitsandbytes"
                if not method:
                    cls_name = type(quant_config).__name__
                    for needle, name in _QUANT_CLASS_NAME_HINTS:
                        if needle.lower() in cls_name.lower():
                            method = name
                            break
                if method:
                    info["quantization_method"] = method

                bits = getattr(quant_config, "bits", None)
                if bits is None and getattr(quant_config, "load_in_4bit", False):
                    bits = 4
                elif bits is None and getattr(quant_config, "load_in_8bit", False):
                    bits = 8
                if bits is not None:
                    info["quantization_bits"] = bits

            with _lock:
                _runtime_info.update(info)
            _dbg(f"transformers hook: captured model {info}")
        except Exception:
            _dbg_exc("transformers._patched_from_pretrained")
        return model

    cls.from_pretrained = classmethod(_patched_from_pretrained)


# ── peft LoraConfig hook ──────────────────────────────────────────────────────

def _install_peft_hook():
    try:
        import peft
    except ImportError:
        _dbg("peft hook: peft not available, skipping")
        return

    if "peft" in _hooks_installed:
        return
    _orig_init = peft.LoraConfig.__init__
    _hooks_installed["peft"] = True
    _dbg("peft hook: installed, patching LoraConfig.__init__")

    def _patched_init(self, *args, **kwargs):
        _orig_init(self, *args, **kwargs)
        try:
            info = {}
            if getattr(self, "r", None) is not None:
                info["lora_rank"] = self.r
            if getattr(self, "lora_alpha", None) is not None:
                info["lora_alpha"] = self.lora_alpha

            # "lora" on a quantized base becomes "qlora" in postprocess.py,
            # since the LoraConfig is often built before the model loads (#109).
            if getattr(self, "use_dora", False):
                info["adaptation_method"] = "dora"
            elif getattr(self, "use_rslora", False):
                info["adaptation_method"] = "rslora"
            else:
                info["adaptation_method"] = "lora"
            with _lock:
                _runtime_info.update(info)
            _dbg(f"peft hook: captured LoraConfig {info}")
        except Exception:
            _dbg_exc("peft._patched_init")

    peft.LoraConfig.__init__ = _patched_init


# ── Seeding hooks and determinism flags ──────────────────────────────────────
#
# A process's seeds are one observation, kept under a single runtime_info key
# ("seeds") so they merge as a unit across processes (here) and pods (the
# watcher's mergeDatasets), never mixing one process's torch seed with
# another's Python seed. "values" is each generator's most recent explicit
# seed, the one governing whatever ran after it; "history" lists the distinct
# values in the order first seen, only for generators seeded with more than
# one (a script that seeds 1234 and then lets Trainer reseed with 42).
#
# Seeds torch itself sets in a DataLoader worker (base_seed + worker_id, a
# derived NumPy state, then transformers' seed_worker reseeding from those)
# are not the script's choice and are ignored. So are seeds on ranks other
# than 0, which differ by design under accelerate's set_seed(device_specific=True).
#
# Not captured: local generators (numpy.random.default_rng, RandomState,
# torch.Generator) and torch.cuda.manual_seed* called on its own.

_SEED_HISTORY_MAX = 8
# Ints beyond this can't be canonicalized under RFC 8785, which would leave
# the compiled AIBOM unsigned; they're recorded as strings instead.
_JSON_SAFE_INT = 2 ** 53 - 1
_last_seeds = {}
_seed_history = {}
# Set by anything only a training process does (a seed call, a DataLoader,
# TrainingArguments), so determinism flags aren't recorded by a launcher like
# torchrun, which imports torch and exits last, after its ranks.
_training_activity = False


def _seed_value(seed):
    if seed is None or isinstance(seed, bool):
        return None
    if isinstance(seed, str):
        return seed[:64]
    try:
        value = operator.index(seed)  # int, numpy integer
    except TypeError:
        return None  # bytes, arrays, ...
    return value if abs(value) <= _JSON_SAFE_INT else str(value)


def _in_dataloader_worker():
    frame = sys._getframe(1)
    while frame is not None:
        if frame.f_globals.get("__name__") == "torch.utils.data._utils.worker":
            return True
        frame = frame.f_back
    return False


def _is_primary_rank():
    return os.environ.get("RANK", "0") in ("", "0")


def _record_seed(generator, seed):
    global _training_activity
    if _in_dataloader_worker():
        return
    _training_activity = True
    value = _seed_value(seed)
    if value is None or not _is_primary_rank():
        return
    with _lock:
        _last_seeds[generator] = value
        history = _seed_history.setdefault(generator, [])
        if value not in history and len(history) < _SEED_HISTORY_MAX:
            history.append(value)
        observation = {"values": dict(_last_seeds)}
        reseeded = {g: list(h) for g, h in _seed_history.items() if len(h) > 1}
        if reseeded:
            observation["history"] = reseeded
        _runtime_info["seeds"] = observation
    _dbg(f"seed hook: {generator} seeded with {value!r}")


def _wrap_seed_fn(fn, generator, param):
    @functools.wraps(fn)
    def seed(*args, **kwargs):
        result = fn(*args, **kwargs)
        try:
            _record_seed(generator, args[0] if args else kwargs.get(param))
        except Exception:
            _dbg_exc(f"seed hook ({generator})")
        return result
    return seed


def _install_random_seed_hook():
    import random

    if "random_seed" in _hooks_installed:
        return
    orig = random.seed
    _hooks_installed["random_seed"] = True
    random.seed = _wrap_seed_fn(orig, "python", "a")
    _dbg("seed hook: patched random.seed")


def _install_numpy_seed_hook():
    try:
        # import_module, not `import numpy.random as npr`: this runs while
        # numpy.random is still finishing its import, before numpy has the
        # attribute bound.
        npr = importlib.import_module("numpy.random")
    except ImportError:
        _dbg("seed hook: numpy not available, skipping")
        return

    if "numpy_seed" in _hooks_installed:
        return
    orig = npr.seed
    _hooks_installed["numpy_seed"] = True
    npr.seed = _wrap_seed_fn(orig, "numpy", "seed")
    _dbg("seed hook: patched numpy.random.seed")


def _install_torch_seed_hook():
    try:
        import torch
    except ImportError:
        return

    if "torch_seed" in _hooks_installed:
        return
    orig = getattr(torch, "manual_seed", None)
    if orig is None:
        _dbg("seed hook: torch.manual_seed not found, skipping")
        return
    _hooks_installed["torch_seed"] = True
    wrapped = _wrap_seed_fn(orig, "torch", "seed")
    torch.manual_seed = wrapped
    # torch.manual_seed is a re-export of torch.random.manual_seed.
    torch_random = getattr(torch, "random", None)
    if torch_random is not None and getattr(torch_random, "manual_seed", None) is orig:
        torch_random.manual_seed = wrapped
    _dbg("seed hook: patched torch.manual_seed")


# ── torch.optim.Optimizer hook ──────────────────────────────────────────────
#
# Trainer's optimizer, DeepSpeed's, bitsandbytes' and one a script builds
# itself all subclass torch.optim.Optimizer, whose __init__ they call, so this
# records the hyperparameters that were actually used. They're read from
# param_groups, not `defaults`: Trainer passes weight_decay per group (0 for
# biases and norm weights) rather than as a constructor argument, so
# `defaults` holds torch's own weight_decay. Settings every group shares go in
# `params`; when any differ, `param_groups` lists each group's differing
# settings and its tensor count (the shape oc-aibom and the console plugin
# read).
# ponytail: the first optimizer a process builds wins; a second one (a GAN's
# discriminator, a multi-optimizer script) isn't recorded.

_OPTIMIZER_MAX_PARAMS = 16
# ponytail: groups past this (per-layer LR decay) are dropped, not summarized.
_OPTIMIZER_MAX_GROUPS = 32
_optimizer_recorded = False


def _is_json_number(value):
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return abs(value) <= _JSON_SAFE_INT
    return isinstance(value, float) and math.isfinite(value)


def _optimizer_value(value):
    if hasattr(value, "item") and getattr(value, "ndim", None) == 0:
        value = value.item()  # a tensor lr (capturable/fused optimizers)
    if isinstance(value, bool) or _is_json_number(value):
        return value
    if isinstance(value, (tuple, list)) and 0 < len(value) <= 4 and all(map(_is_json_number, value)):
        return list(value)  # betas
    return None


def _record_optimizer(optimizer):
    global _optimizer_recorded, _training_activity
    if _optimizer_recorded or _in_dataloader_worker():
        return
    _optimizer_recorded = True
    _training_activity = True
    groups = []
    for group in (getattr(optimizer, "param_groups", None) or [])[:_OPTIMIZER_MAX_GROUPS]:
        settings = {}
        for key, value in group.items():
            value = _optimizer_value(value) if key != "params" and isinstance(key, str) else None
            if value is not None:
                settings[key[:64]] = value
        tensors = group.get("params")
        groups.append((settings, len(tensors) if isinstance(tensors, list) else None))
    keys = sorted({k for settings, _ in groups for k in settings})[:_OPTIMIZER_MAX_PARAMS]
    first = groups[0][0] if groups else {}
    shared = {k: first[k] for k in keys if all(k in g and g[k] == first.get(k) for g, _ in groups)}
    cls = type(optimizer)
    observation = {"class": f"{cls.__module__}.{cls.__qualname__}"[:128], "params": shared}
    if len(shared) < len(keys):
        observation["param_groups"] = [
            {
                **{k: settings[k] for k in keys if k not in shared and k in settings},
                **({"param_tensors": tensors} if tensors is not None else {}),
            }
            for settings, tensors in groups
        ]
    with _lock:
        _runtime_info["optimizer_constructed"] = observation
    _dbg(f"optimizer hook: captured {observation}")


def _install_torch_optimizer_hook():
    base = getattr(getattr(sys.modules.get("torch"), "optim", None), "Optimizer", None)
    if base is None or "torch_optimizer" in _hooks_installed:
        return
    orig = base.__init__
    _hooks_installed["torch_optimizer"] = True

    @functools.wraps(orig)
    def __init__(self, *args, **kwargs):
        orig(self, *args, **kwargs)
        try:
            _record_optimizer(self)
        except Exception:
            _dbg_exc("optimizer hook")

    base.__init__ = __init__
    _dbg("optimizer hook: patched torch.optim.Optimizer.__init__")


def _capture_determinism_flags():
    """Read torch's determinism switches and the env vars that matter to
    them. Read at flush time rather than hooked, since transformers'
    enable_full_determinism and scripts set them by plain assignment
    (torch.backends.cudnn.deterministic = True). torch is never imported
    here, only read if the process already has it."""
    flags = {}
    torch = sys.modules.get("torch")
    if torch is not None:
        try:
            cudnn = getattr(getattr(torch, "backends", None), "cudnn", None)
            for attr, key in (("deterministic", "cudnn_deterministic"), ("benchmark", "cudnn_benchmark")):
                value = getattr(cudnn, attr, None)
                if isinstance(value, bool):
                    flags[key] = value
            enabled = getattr(torch, "are_deterministic_algorithms_enabled", None)
            if callable(enabled):
                flags["deterministic_algorithms"] = bool(enabled())
                warn_only = getattr(torch, "is_deterministic_algorithms_warn_only_enabled", None)
                if flags["deterministic_algorithms"] and callable(warn_only) and warn_only():
                    flags["deterministic_algorithms_warn_only"] = True
        except Exception:
            _dbg_exc("_capture_determinism_flags")
    cublas = os.environ.get("CUBLAS_WORKSPACE_CONFIG")
    if cublas:
        flags["cublas_workspace_config"] = cublas
    if _STARTUP_PYTHONHASHSEED:
        flags["python_hash_seed"] = _STARTUP_PYTHONHASHSEED
    if flags:
        _runtime_info["determinism_flags"] = flags


# ── Numerical precision ─────────────────────────────────────────────────────
#
# Mixed precision is recorded from the objects that apply it, not from config
# files: Accelerator (which resolves `accelerate launch --mixed_precision`,
# its config file, ACCELERATE_MIXED_PRECISION and Trainer's bf16/fp16 into
# one value), DeepSpeedEngine (its JSON config's bf16/fp16), FSDP's
# MixedPrecision/MixedPrecisionPolicy, Transformer Engine's fp8 autocast,
# torchao's float8 conversion, and torch.autocast for a custom loop. Each is
# recorded once per process, from the first one built. None of these hooks
# imports anything: each patches its module when the module itself finishes
# importing. TF32 is a pair of global switches, read at flush time like the
# determinism flags.

_AUTOCAST_MAX = 8
_autocast_seen = set()


def _dtype_name(dtype):
    return str(dtype).replace("torch.", "")[:32] if dtype is not None else None


def _record_once(key, value):
    if not value or _in_dataloader_worker():
        return
    with _lock:
        if key in _runtime_info:
            return
        _runtime_info[key] = value
    _dbg(f"hook: {key}={value}")


def _wrap_after(cls, name, record):
    """Patch cls.<name> to call record(self) after it runs (once per class)."""
    orig = cls.__dict__.get(name) if cls is not None else None
    if orig is None or getattr(orig, "_aibom_wrapped", False):
        return False

    @functools.wraps(orig)
    def wrapper(self, *args, **kwargs):
        result = orig(self, *args, **kwargs)
        try:
            record(self)
        except Exception:
            _dbg_exc(f"hook ({cls.__name__}.{name})")
        return result

    wrapper._aibom_wrapped = True
    setattr(cls, name, wrapper)
    return True


def _wrap_function(module, name, record):
    """Patch module.<name> to call record(args, kwargs) before it runs."""
    orig = getattr(module, name, None)
    if orig is None or getattr(orig, "_aibom_wrapped", False):
        return

    @functools.wraps(orig)
    def wrapper(*args, **kwargs):
        try:
            record(args, kwargs)
        except Exception:
            _dbg_exc(f"hook ({name})")
        return orig(*args, **kwargs)

    wrapper._aibom_wrapped = True
    setattr(module, name, wrapper)


def _record_autocast(ac):
    if not getattr(ac, "_enabled", False):
        return
    entry = f"{getattr(ac, 'device', None)}:{_dtype_name(getattr(ac, 'fast_dtype', None))}"[:48]
    # Runs every step: the already-seen case skips the stack walk and lock.
    if entry in _autocast_seen or len(_autocast_seen) >= _AUTOCAST_MAX or _in_dataloader_worker():
        return
    with _lock:
        if entry in _autocast_seen or len(_autocast_seen) >= _AUTOCAST_MAX:
            return
        _autocast_seen.add(entry)
        _runtime_info["autocast"] = sorted(_autocast_seen)


def _install_autocast_hook():
    torch = sys.modules.get("torch")
    autocast = getattr(getattr(getattr(torch, "amp", None), "autocast_mode", None), "autocast", None)
    if "torch_autocast" in _hooks_installed or autocast is None:
        return
    # Its subclasses (torch.cuda.amp.autocast, ...) call it through super().
    if _wrap_after(autocast, "__init__", _record_autocast):
        _hooks_installed["torch_autocast"] = True


_ACCELERATE_FP8_BACKENDS = {"te": "transformer_engine", "ao": "torchao", "msamp": "msamp"}


def _record_accelerator(acc):
    value = {}
    mp = getattr(acc, "mixed_precision", None)
    if isinstance(mp, str) and mp:
        value["mixed_precision"] = mp[:16]
    if mp == "fp8":
        backend = str(getattr(acc, "fp8_backend", "") or "").lower()
        if backend:
            value["fp8_backend"] = _ACCELERATE_FP8_BACKENDS.get(backend, backend[:32])
    _record_once("accelerator_precision", value)
    try:
        _record_accelerator_distributed(acc)
    except Exception:
        _dbg_exc("_record_accelerator_distributed")


def _install_accelerate_hook():
    acc = getattr(sys.modules.get("accelerate"), "Accelerator", None)
    if "accelerate" not in _hooks_installed and _wrap_after(acc, "__init__", _record_accelerator):
        _hooks_installed["accelerate"] = True


def _record_deepspeed_engine(engine):
    if engine.bfloat16_enabled():
        value = "bf16"
    elif engine.fp16_enabled():
        value = "fp16"
    else:
        value = "no"
    _record_once("deepspeed_precision", value)
    _record_once("deepspeed_engine", _deepspeed_summary(
        engine.zero_optimization_stage(), engine.zero_offload_optimizer(), engine.zero_offload_param()))


def _install_deepspeed_hook():
    deepspeed = sys.modules.get("deepspeed")
    engine = getattr(deepspeed, "DeepSpeedEngine", None)
    if "deepspeed" not in _hooks_installed and _wrap_after(engine, "__init__", _record_deepspeed_engine):
        _hooks_installed["deepspeed"] = True
        # Sets num_stages after DeepSpeedEngine.__init__ returns.
        _wrap_after(getattr(deepspeed, "PipelineEngine", None), "__init__",
                    lambda e: _record_once("deepspeed_pipeline_stages", getattr(e, "num_stages", None)))


def _record_fsdp_policy(policy):
    value = {"policy": type(policy).__name__[:64]}
    # buffer_dtype is FSDP1's, output_dtype FSDP2's.
    for attr in ("param_dtype", "reduce_dtype", "buffer_dtype", "output_dtype"):
        name = _dtype_name(getattr(policy, attr, None))
        if name:
            value[attr] = name
    # A policy with no dtypes isn't one the run chose: FSDP1 builds an
    # all-None MixedPrecision() when given none, and fully_shard builds a
    # dtype-less MixedPrecisionPolicy internally. Neither may claim the
    # once-per-process slot.
    if len(value) > 1:
        _record_once("fsdp_mixed_precision", value)


def _install_fsdp_hook():
    fsdp = sys.modules.get("torch.distributed.fsdp")
    if fsdp is None or "fsdp_precision" in _hooks_installed:
        return
    _hooks_installed["fsdp_precision"] = True
    for name in ("MixedPrecision", "MixedPrecisionPolicy"):
        _wrap_after(getattr(fsdp, name, None), "__init__", _record_fsdp_policy)
    # FSDP1 wraps each submodule in its own instance, FSDP2 calls
    # fully_shard per submodule; the first one is recorded.
    _wrap_after(getattr(fsdp, "FullyShardedDataParallel", None), "__init__", lambda m: _record_once(
        "fsdp_module", _fsdp_summary(1, getattr(m, "sharding_strategy", None), None, getattr(m, "cpu_offload", None))))
    _wrap_function(fsdp, "fully_shard", _record_fully_shard)


def _install_transformer_engine_hook():
    te = sys.modules.get("transformer_engine.pytorch")
    if te is None or "transformer_engine" in _hooks_installed:
        return
    _hooks_installed["transformer_engine"] = True

    def record(args, kwargs):
        if not kwargs.get("enabled", args[0] if args else True):
            return
        recipe = kwargs.get("fp8_recipe") or kwargs.get("recipe")
        value = {"backend": "transformer_engine"}
        if recipe is not None:
            value["recipe"] = type(recipe).__name__[:64]
        _record_once("fp8", value)

    # fp8_autocast, and autocast, its newer name.
    for name in ("fp8_autocast", "autocast"):
        _wrap_function(te, name, record)


def _install_torchao_float8_hook():
    float8 = sys.modules.get("torchao.float8")
    if float8 is None or "torchao_float8" in _hooks_installed:
        return
    _hooks_installed["torchao_float8"] = True
    _wrap_function(float8, "convert_to_float8_training",
                   lambda args, kwargs: _record_once("fp8", {"backend": "torchao"}))


def _capture_precision_flags():
    """TF32 switches (TrainingArguments(tf32=True) and
    torch.set_float32_matmul_precision set these too) and the mixed precision
    accelerate launch hands its ranks. torch is only read if imported."""
    flags = {}
    torch = sys.modules.get("torch")
    if torch is not None:
        try:
            backends = getattr(torch, "backends", None)
            matmul = getattr(getattr(backends, "cuda", None), "matmul", None)
            for obj, key in ((matmul, "tf32_matmul"), (getattr(backends, "cudnn", None), "tf32_cudnn")):
                value = getattr(obj, "allow_tf32", None)
                if isinstance(value, bool):
                    flags[key] = value
            get_precision = getattr(torch, "get_float32_matmul_precision", None)
            if callable(get_precision):
                flags["float32_matmul_precision"] = str(get_precision())[:16]
        except Exception:
            _dbg_exc("_capture_precision_flags")
    env = os.environ.get("ACCELERATE_MIXED_PRECISION")
    if env:
        flags["accelerate_mixed_precision"] = env[:16]
    if flags:
        _runtime_info["precision_flags"] = flags


# ── Distributed topology ─────────────────────────────────────────────────────
#
# What sharded or split the model, read from the object that applied it
# (Accelerator, DeepSpeedEngine, the FSDP module, Megatron's
# initialize_model_parallel, a named DeviceMesh), with the accelerate config
# file and TrainingArguments as fallbacks for a run that dies before them.

_FSDP_STRATEGIES = ("FULL_SHARD", "SHARD_GRAD_OP", "NO_SHARD", "HYBRID_SHARD", "HYBRID_SHARD_ZERO2")
_OFFLOAD_DEVICES = ("none", "cpu", "nvme")
_MESH_DIMS_MAX = 8


def _fsdp_strategy_name(value):
    """ShardingStrategy, its name, or its 1-based number (accelerate configs)."""
    value = getattr(value, "name", value)
    if isinstance(value, str) and value.isdigit():
        value = int(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return _FSDP_STRATEGIES[value - 1] if 1 <= value <= len(_FSDP_STRATEGIES) else None
    if isinstance(value, str) and value.upper() in _FSDP_STRATEGIES:
        return value.upper()
    return None


def _offload_flag(value):
    """FSDP1's CPUOffload, FSDP2's offload policy, or a plain bool."""
    if isinstance(value, bool) or value is None:
        return value
    flag = getattr(value, "offload_params", None)
    if isinstance(flag, bool):
        return flag
    # FSDP2's base OffloadPolicy means no offload.
    return type(value).__name__ == "CPUOffloadPolicy"


def _fsdp_summary(version=None, strategy=None, reshard=None, cpu_offload=None):
    """reshard_after_forward is FSDP2's bool, but accelerate and transformers
    also use the name for FSDP1's strategy, and when they do, the separate
    sharding_strategy is a stale default."""
    out = {}
    if version in (1, 2):
        out["version"] = version
    if isinstance(reshard, bool):
        out["reshard_after_forward"] = reshard
    name = _fsdp_strategy_name(reshard) or _fsdp_strategy_name(strategy)
    if name:
        out["sharding_strategy"] = name
    offload = _offload_flag(cpu_offload)
    if offload is not None:
        out["cpu_offload"] = offload
    return out


def _deepspeed_summary(stage, offload_optimizer=None, offload_param=None):
    out = {}
    if isinstance(stage, int) and not isinstance(stage, bool) and 0 <= stage <= 3:
        out["zero_stage"] = stage
    for key, device in (("offload_optimizer", offload_optimizer), ("offload_param", offload_param)):
        device = getattr(device, "device", device)  # the engine's offload config
        device = getattr(device, "value", device)   # OffloadDeviceEnum
        if isinstance(device, str) and device.lower() in _OFFLOAD_DEVICES:
            out[key] = device.lower()
    return out


def _deepspeed_json_summary(config):
    """A DeepSpeed config dict, or the path to its JSON file."""
    if isinstance(config, str) and os.path.isfile(config) and os.path.getsize(config) < 1 << 20:
        with open(config) as f:
            config = json.load(f)
    if not isinstance(config, dict):
        return {}
    zero = config.get("zero_optimization")
    if not isinstance(zero, dict):
        return {}

    def device(key):
        return zero[key].get("device") if isinstance(zero.get(key), dict) else None

    return _deepspeed_summary(zero.get("stage"), device("offload_optimizer"), device("offload_param"))


def _training_args_distributed(args):
    """FSDP/DeepSpeed settings TrainingArguments asked for. fsdp is True plus
    fsdp_config on transformers 5, a list of options on 4.x."""
    out = {}
    fsdp = getattr(args, "fsdp", None)
    if fsdp:
        config = getattr(args, "fsdp_config", None)
        config = config if isinstance(config, dict) else {}
        options = fsdp.split() if isinstance(fsdp, str) else fsdp if isinstance(fsdp, (list, tuple)) else []
        options = [str(getattr(o, "value", o)).lower() for o in options]
        strategy = next((o for o in options if _fsdp_strategy_name(o)), None)
        offload = config.get("cpu_offload", True if "offload" in options else None)
        out["fsdp"] = _fsdp_summary(config.get("version"), strategy, config.get("reshard_after_forward"), offload)
    deepspeed = getattr(args, "deepspeed", None)
    if deepspeed:
        out["deepspeed"] = _deepspeed_json_summary(deepspeed)
    return out


def _positive_int(value):
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else None


def _record_accelerator_distributed(acc):
    state = getattr(acc, "state", None)
    value = {}
    distributed_type = getattr(state, "distributed_type", None)
    distributed_type = getattr(distributed_type, "value", distributed_type)
    if isinstance(distributed_type, str) and distributed_type:
        value["distributed_type"] = distributed_type[:32]
    world = _positive_int(getattr(state, "num_processes", None))
    if world:
        value["world_size"] = world
    plugin = getattr(state, "fsdp_plugin", None)
    if plugin is not None:
        value["fsdp"] = _fsdp_summary(
            getattr(plugin, "fsdp_version", None), getattr(plugin, "sharding_strategy", None),
            getattr(plugin, "reshard_after_forward", None), getattr(plugin, "cpu_offload", None))
    plugin = getattr(state, "deepspeed_plugin", None)
    if plugin is not None:
        value["deepspeed"] = _deepspeed_summary(
            getattr(plugin, "zero_stage", None), getattr(plugin, "offload_optimizer_device", None),
            getattr(plugin, "offload_param_device", None))
    _record_once("accelerator_distributed", value)


def _record_fully_shard(args, kwargs):
    value = _fsdp_summary(2, None, kwargs.get("reshard_after_forward"), kwargs.get("offload_policy"))
    # A 2-D mesh is HSDP: replicate across one dim, shard across the other.
    if getattr(kwargs.get("mesh"), "ndim", None) == 2:
        value["sharding_strategy"] = "HYBRID_SHARD"
    _record_once("fsdp_module", value)


def _install_megatron_hook():
    parallel_state = sys.modules.get("megatron.core.parallel_state")
    if parallel_state is None or "megatron" in _hooks_installed:
        return
    _hooks_installed["megatron"] = True

    def record(args, kwargs):
        def size(name, index=None):
            if name in kwargs:
                return _positive_int(kwargs[name])
            return _positive_int(args[index]) if index is not None and index < len(args) else None

        value = {
            "tensor": size("tensor_model_parallel_size", 0) or 1,
            "pipeline": size("pipeline_model_parallel_size", 1) or 1,
            "context": size("context_parallel_size") or 1,
            "expert": size("expert_model_parallel_size") or 1,
        }
        virtual = size("virtual_pipeline_model_parallel_size", 2)
        if virtual:
            value["virtual_pipeline"] = virtual
        _record_once("megatron_parallel", value)

    # megatron.core.mpu is the same module object.
    _wrap_function(parallel_state, "initialize_model_parallel", record)


def _install_device_mesh_hook():
    device_mesh = sys.modules.get("torch.distributed.device_mesh")
    if device_mesh is None or "device_mesh" in _hooks_installed:
        return
    _hooks_installed["device_mesh"] = True
    orig = getattr(device_mesh, "init_device_mesh", None)

    def record(args, kwargs):
        names = kwargs.get("mesh_dim_names")
        shape = kwargs.get("mesh_shape", args[1] if len(args) > 1 else None)
        # An unnamed mesh (FSDP2's default 1-D one) says nothing about the split.
        if not names or not isinstance(shape, (tuple, list)) or len(names) != len(shape):
            return
        _record_once("device_mesh", {
            str(n)[:32]: s for n, s in list(zip(names, shape))[:_MESH_DIMS_MAX] if _positive_int(s)
        })

    _wrap_function(device_mesh, "init_device_mesh", record)
    # torch.distributed re-exports it; bound before this hook if torch.distributed
    # was already imported.
    dist = sys.modules.get("torch.distributed")
    if dist is not None and getattr(dist, "init_device_mesh", None) is orig:
        dist.init_device_mesh = device_mesh.init_device_mesh


def _capture_distributed_env():
    """World size from the launcher's env: torchrun (and accelerate launch,
    which uses it), the DeepSpeed launcher, Open MPI."""
    def env_int(*names):
        for name in names:
            value = os.environ.get(name, "")
            if value.isdigit() and int(value) > 0:
                return int(value)
        return None

    world = env_int("WORLD_SIZE", "OMPI_COMM_WORLD_SIZE")
    if not world:
        return
    value = {"world_size": world}
    local = env_int("LOCAL_WORLD_SIZE", "LOCAL_SIZE", "OMPI_COMM_WORLD_LOCAL_SIZE")
    if local:
        value["local_world_size"] = local
    nodes = env_int("GROUP_WORLD_SIZE") or (world // local if local and world % local == 0 else None)
    if nodes:
        value["nodes"] = nodes
    _runtime_info["distributed_env"] = value


# ── Software versions ────────────────────────────────────────────────────────
#
# Only libraries the process actually imported are listed, so an image that
# ships vllm alongside a training stack doesn't report it for a training run.
# A library imported lazily (flash_attn, bitsandbytes) appears from the first
# flush after its import. Versions come from the installed distribution's
# metadata, else the module's __version__ (a source checkout on PYTHONPATH).

# (distribution name, module whose presence in sys.modules means it was used)
_TRACKED_PACKAGES = (
    ("torch", "torch"),
    ("torchvision", "torchvision"),
    ("torchao", "torchao"),
    ("numpy", "numpy"),
    ("transformers", "transformers"),
    ("tokenizers", "tokenizers"),
    ("safetensors", "safetensors"),
    ("datasets", "datasets"),
    ("webdataset", "webdataset"),
    ("accelerate", "accelerate"),
    ("peft", "peft"),
    ("trl", "trl"),
    ("deepspeed", "deepspeed"),
    ("megatron-core", "megatron.core"),
    ("bitsandbytes", "bitsandbytes"),
    ("flash-attn", "flash_attn"),
    ("xformers", "xformers"),
    ("triton", "triton"),
    ("liger-kernel", "liger_kernel"),
    ("axolotl", "axolotl"),
    ("llamafactory", "llamafactory"),
    ("vllm", "vllm"),
    ("sglang", "sglang"),
    ("lmdeploy", "lmdeploy"),
    ("text-generation-server", "text_generation_server"),
)
_package_versions = {}  # distribution -> version, or None once looked up and not found
_torch_build = None


def _short_str(value, limit=64):
    return value[:limit] if isinstance(value, str) and value else None


def _package_version(dist, module_name):
    try:
        import importlib.metadata
        return _short_str(importlib.metadata.version(dist))
    except Exception:
        pass
    return _short_str(getattr(sys.modules.get(module_name), "__version__", None))


def _format_cudnn_version(value):
    # cuDNN 9 encodes major*10000 + minor*100 + patch; cuDNN 8 and earlier
    # major*1000 + minor*100 + patch.
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        return None
    major, rest = divmod(value, 10000) if value >= 90000 else divmod(value, 1000)
    return f"{major}.{rest // 100}.{rest % 100}"


def _format_nccl_version(value):
    if isinstance(value, (tuple, list)) and len(value) >= 3:
        return ".".join(str(v) for v in value[:3])
    # Older torch returned NCCL_VERSION_CODE: major*10000 + minor*100 + patch
    # from 2.9 on, major*1000 + minor*100 + patch before.
    if isinstance(value, int) and not isinstance(value, bool) and value > 0:
        major, rest = divmod(value, 10000) if value >= 20900 else divmod(value, 1000)
        return f"{major}.{rest // 100}.{rest % 100}"
    return None


def _capture_torch_build(torch):
    """The CUDA/HIP toolkit torch was built against and the cuDNN/NCCL it
    loaded -- not the driver's CUDA version, which is what nvidia-smi
    reports in environment.cuda_version."""
    build = {}
    version = getattr(torch, "version", None)
    for attr, key in (("cuda", "torch_cuda"), ("hip", "torch_hip")):
        value = _short_str(getattr(version, attr, None), 32)
        if value:
            build[key] = value
    # The binding, not torch.backends.cudnn.version(): that one's first call
    # checks every device's compute capability, which initializes CUDA in the
    # workload's process (a forked DataLoader worker can't use CUDA after
    # that) and raises on an incompatible device. On ROCm the binding is
    # MIOpen's.
    try:
        get_version = torch.backends.cudnn._cudnn.getVersionInt
        cudnn = None if "torch_hip" in build else _format_cudnn_version(get_version())
        if cudnn:
            build["cudnn"] = cudnn
    except Exception:
        pass
    try:
        nccl = _format_nccl_version(torch.cuda.nccl.version())
        if nccl:
            build["nccl"] = nccl
    except Exception:
        pass  # CPU-only build
    return build


def _capture_software_versions():
    global _torch_build
    try:
        for dist, module_name in _TRACKED_PACKAGES:
            if dist not in _package_versions and module_name in sys.modules:
                _package_versions[dist] = _package_version(dist, module_name)
        torch = sys.modules.get("torch")
        if _torch_build is None and torch is not None:
            _torch_build = _capture_torch_build(torch)
        versions = {"python": "%d.%d.%d" % sys.version_info[:3]}
        packages = {d: v for d, v in _package_versions.items() if v}
        if packages:
            versions["packages"] = packages
        versions.update(_torch_build or {})
        _runtime_info["software_versions"] = versions
    except Exception:
        _dbg_exc("_capture_software_versions")


# ── Public API ───────────────────────────────────────────────────────────────

def install_hooks():
    """Install all available dataset detection hooks (immediate).

    Use when frameworks are already imported (e.g., mid-script activation).
    """
    _dbg("install_hooks: installing all hooks (immediate mode)")
    _install_dataloader_hook()
    _install_hf_datasets_hook()
    _install_torchvision_hook()
    _install_webdataset_hook()
    _install_transformers_hook()
    _install_peft_hook()
    _install_random_seed_hook()
    _install_numpy_seed_hook()
    _install_torch_seed_hook()
    _install_torch_optimizer_hook()
    _install_autocast_hook()
    _install_accelerate_hook()
    _install_deepspeed_hook()
    _install_fsdp_hook()
    _install_device_mesh_hook()
    _install_megatron_hook()
    _install_transformer_engine_hook()
    _install_torchao_float8_hook()
    _register_durable_flush()
    _dbg(f"install_hooks: done, output will go to {_OUTPUT_PATH}")


def _install_torch_hooks():
    _install_dataloader_hook()
    _install_torch_seed_hook()
    _install_torch_optimizer_hook()
    _install_autocast_hook()


# Top-level module -> the hook to install once it has finished importing.
_LAZY_TRIGGERS = {
    "torch": _install_torch_hooks,
    "datasets": _install_hf_datasets_hook,
    "torchvision": _install_torchvision_hook,
    "webdataset": _install_webdataset_hook,
    "transformers.training_args": _install_training_args_hook,
    "transformers.modeling_utils": _install_from_pretrained_hook,
    "peft": _install_peft_hook,
    "random": _install_random_seed_hook,
    # numpy 2 can import numpy.random lazily, on first attribute access.
    "numpy.random": _install_numpy_seed_hook,
    "accelerate": _install_accelerate_hook,
    "deepspeed": _install_deepspeed_hook,
    "torch.distributed.fsdp": _install_fsdp_hook,
    "torch.distributed.device_mesh": _install_device_mesh_hook,
    "megatron.core.parallel_state": _install_megatron_hook,
    "transformer_engine.pytorch": _install_transformer_engine_hook,
    "torchao.float8": _install_torchao_float8_hook,
}


class _PostImportHookFinder:
    """sys.meta_path finder that runs a trigger's hook the moment its module
    finishes executing -- before the import statement that loaded it binds
    anything.

    This replaced a builtins.__import__ wrapper that only installed hooks
    once the import stack unwound back to depth 0. That missed any module
    that first imported a framework from inside another import -- a user
    helper module, or trl's own CLI modules, doing `from datasets import
    load_dataset` at their top level bound the unpatched function before the
    hook ran. It also didn't see importlib.import_module() or lazy loaders,
    which bypass builtins.__import__, and its depth counter was shared across
    threads.

    The finder never loads anything itself: it asks the finders after it for
    the real spec and wraps that spec's loader's exec_module on the loader
    instance (keeping the loader's type, which importlib.resources and
    friends may check), then removes the wrapper once it has fired."""

    def __init__(self, triggers):
        self._pending = dict(triggers)
        self._claim_lock = threading.Lock()
        self._resolving = threading.local()

    def _claim(self, name):
        # Hooks run outside this lock: one may run an import statement (the
        # torch hook's `import torch.utils.data`), and holding a lock across
        # an import risks deadlocking against another thread's module lock.
        with self._claim_lock:
            hook = self._pending.pop(name, None)
            if not self._pending:
                try:
                    sys.meta_path.remove(self)
                except ValueError:
                    pass
            return hook

    def fire(self, name):
        hook = self._claim(name)
        if hook is None:
            return
        _dbg(f"Lazy hook: '{name}' finished importing, installing hook")
        try:
            hook()
        except Exception:
            _dbg_exc(f"install_hooks_lazy({name})")

    def find_spec(self, fullname, path=None, target=None):
        if fullname not in self._pending:
            return None
        resolving = getattr(self._resolving, "names", None)
        if resolving is None:
            resolving = self._resolving.names = set()
        if fullname in resolving:
            return None
        resolving.add(fullname)
        try:
            spec = None
            for finder in list(sys.meta_path):
                if finder is self:
                    continue
                find = getattr(finder, "find_spec", None)
                if find is None:
                    continue
                spec = find(fullname, path, target)
                if spec is not None:
                    break
        finally:
            resolving.discard(fullname)
        if spec is None or spec.loader is None:
            return spec
        self._wrap_loader(spec.loader, fullname)
        return spec

    def _wrap_loader(self, loader, fullname):
        orig_exec = getattr(loader, "exec_module", None)
        if orig_exec is None or isinstance(loader, type):
            _dbg(f"Lazy hook: can't wrap loader for '{fullname}' ({loader!r})")
            return
        finder = self

        def exec_module(module):
            try:
                orig_exec(module)
            finally:
                # A loader instance can be shared across modules (e.g. one
                # zipimporter per archive), so only fire for our module, and
                # restore the original method once it has run.
                if getattr(module, "__name__", None) == fullname:
                    try:
                        del loader.exec_module
                    except AttributeError:
                        pass
            if getattr(module, "__name__", None) == fullname:
                finder.fire(fullname)

        try:
            loader.exec_module = exec_module
        except (AttributeError, TypeError):
            _dbg(f"Lazy hook: can't wrap loader for '{fullname}' ({loader!r})")


def install_hooks_lazy():
    """Install hooks lazily, as each framework finishes importing.

    Use when activated early (e.g., as sitecustomize.py at interpreter
    startup) before frameworks are imported. Frameworks that are already
    imported get their hook immediately.
    """
    finder = _PostImportHookFinder(_LAZY_TRIGGERS)
    already = [mod for mod in _LAZY_TRIGGERS if mod in sys.modules]
    if len(already) < len(_LAZY_TRIGGERS):
        sys.meta_path.insert(0, finder)
    for mod in already:
        _dbg(f"Lazy hook: '{mod}' already imported, installing hook now")
        finder.fire(mod)

    _register_durable_flush()
    _dbg(f"install_hooks_lazy: done, output will go to {_OUTPUT_PATH}")


def get_detected_datasets():
    """Return a copy of detected datasets (for testing)."""
    with _lock:
        return list(_detected_datasets)


def flush():
    """Force-write detected datasets to disk."""
    _flush()


def reset():
    """Clear detected datasets and stop any scheduled flush (for testing)."""
    global _durable_flush_enabled, _git_captured, _training_activity, _torch_build, _optimizer_recorded
    _cancel_pending_flush()
    _durable_flush_enabled = False
    _git_captured = False
    _training_activity = False
    _optimizer_recorded = False
    _torch_build = None
    _package_versions.clear()
    _autocast_seen.clear()
    with _lock:
        _detected_datasets.clear()
        _hf_dataset_key_registry.clear()
        _last_seeds.clear()
        _seed_history.clear()


# Auto-install when loaded via PYTHONSTARTUP or env var activation.
# Uses lazy hooks so frameworks don't need to be imported yet.
if os.environ.get("AIBOM_DATASET_DETECT", "0") == "1":
    _dbg(f"Auto-activating dataset detection (pid={os.getpid()})")
    _dbg(f"  PYTHONPATH={os.environ.get('PYTHONPATH', '<unset>')}")
    _dbg(f"  AIBOM_DATASET_OUTPUT={_OUTPUT_PATH}")
    _dbg(f"  Loaded from: {__file__}")
    install_hooks_lazy()


def _run_shadowed_sitecustomize():
    """When mounted as sitecustomize.py, this file sits on PYTHONPATH ahead of
    site-packages, so Python imports it *instead of* any sitecustomize the
    image ships (Debian/Ubuntu's apport hook, a conda env's, a platform
    team's own). Find the next one on sys.path and run it, so the image
    behaves as it would without instrumentation. Errors are reported the way
    site.py reports its own sitecustomize errors, and never propagate."""
    here = os.path.dirname(os.path.abspath(__file__))
    for entry in sys.path:
        base = os.path.abspath(entry or os.getcwd())
        if base == here:
            continue
        for candidate in (
            os.path.join(base, "sitecustomize.py"),
            os.path.join(base, "sitecustomize", "__init__.py"),
        ):
            if not os.path.isfile(candidate):
                continue
            try:
                spec = importlib.util.spec_from_file_location("_aibom_shadowed_sitecustomize", candidate)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                _dbg(f"Ran shadowed sitecustomize: {candidate}")
            except Exception as exc:
                print(
                    f"Error in sitecustomize; set PYTHONVERBOSE for traceback:\n"
                    f"{type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
            return


if __name__ == "sitecustomize":
    _run_shadowed_sitecustomize()
