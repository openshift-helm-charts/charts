# cert-manager Integration Improvement Plan

## Overview
This document outlines the implementation plan for improving PR #133 based on feedback to make the cert-manager integration more user-friendly with intelligent defaults.

## Current Implementation Issues

### 1. Hardcoded Values in certificate.yaml
```yaml
commonName: infinispan
dnsNames:
  - infinispan
  - infinispan.{{ .Release.Namespace }}
  - {{ printf "%s-ping.%s.svc.%s" (include "infinispan-helm-charts.name" .) .Release.Namespace .Values.deploy.clusterDomain }}
  - infinispan.{{ .Release.Namespace }}.{{ .Values.deploy.clusterDomain }}
```

**Problems:**
- Uses hardcoded "infinispan" instead of chart name
- Doesn't adapt to actual service names
- Doesn't include route/ingress hostnames when configured
- No way to add custom DNS names

### 2. Cluttered values.yaml
```yaml
certmanager:
  enabled: false
  endpoint:
    enabled: false
    # docs https://cert-manager.io/docs/usage/certificate/
    #issuerRef:
    #  name: selfsigned
    #  kind: ClusterIssuer
    # commonName: 'example-infinispan'
  transport:
    enabled: false
```

**Problems:**
- Commented configuration clutters the file
- No clear guidance on what's auto-computed vs manual

## Proposed Improvements

### Step 1: Enhanced certificate.yaml Template

#### 1.1 Auto-Computed DNS Names Logic

```yaml
{{- if and ( .Capabilities.APIVersions.Has "cert-manager.io/v1/Certificate" ) (.Values.deploy.ssl.certmanager.enabled) }}
{{- if .Values.deploy.ssl.certmanager.endpoint.enabled }}
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: {{ printf "%s-endpoint-cert" (include "infinispan-helm-charts.name" .) }}
  annotations:
    {{- include "infinispan-helm-charts.annotations" . | nindent 4 }}
  labels:
    app: infinispan-endpoint-cert
    {{- include "infinispan-helm-charts.labels" . | nindent 4 }}
spec:
  secretName: {{ .Values.deploy.ssl.endpointSecretName }}
  
  # Auto-computed commonName based on chart name
  commonName: {{ include "infinispan-helm-charts.name" . }}
  
  dnsNames:
    # Base cluster name
    - {{ include "infinispan-helm-charts.name" . }}
    
    # Namespace-qualified name
    - {{ include "infinispan-helm-charts.name" . }}.{{ .Release.Namespace }}
    
    # Ping service (always needed for clustering)
    - {{ printf "%s-ping.%s.svc.%s" (include "infinispan-helm-charts.name" .) .Release.Namespace .Values.deploy.clusterDomain }}
    
    # Fully qualified cluster domain name
    - {{ include "infinispan-helm-charts.name" . }}.{{ .Release.Namespace }}.svc.{{ .Values.deploy.clusterDomain }}
    
    {{- if ne .Values.deploy.expose.type "" }}
    # Main service DNS (only if service is exposed)
    - {{ printf "%s.%s.svc.%s" (include "infinispan-helm-charts.name" .) .Release.Namespace .Values.deploy.clusterDomain }}
    {{- end }}
    
    {{- if eq .Values.deploy.expose.type "Route" }}
    {{- if .Values.deploy.expose.host }}
    # Route hostname if explicitly configured
    - {{ .Values.deploy.expose.host }}
    {{- else }}
    # Default OpenShift route pattern (if we can determine it)
    # Note: Actual route hostname is determined by OpenShift, this is a best-effort
    - {{ include "infinispan-helm-charts.name" . }}-{{ .Release.Namespace }}.apps.{{ .Values.deploy.clusterDomain }}
    {{- end }}
    {{- end }}
    
    {{- if eq .Values.deploy.expose.type "Ingress" }}
    {{- if .Values.deploy.expose.host }}
    # Ingress hostname if configured
    - {{ .Values.deploy.expose.host }}
    {{- end }}
    {{- end }}
    
    {{- range .Values.deploy.ssl.certmanager.endpoint.additionalDnsNames }}
    # User-provided additional DNS names
    - {{ . }}
    {{- end }}
  
  issuerRef:
    {{- if .Values.deploy.ssl.certmanager.issuerRef }}
    # User-provided issuerRef
    {{- toYaml .Values.deploy.ssl.certmanager.issuerRef | nindent 4 }}
    {{- else }}
    # Default to self-signed issuer
    name: selfsigned-issuer
    kind: ClusterIssuer
    {{- end }}
{{- end }}
```

#### 1.2 Transport Certificate (Similar Logic)

```yaml
---
{{- if .Values.deploy.ssl.certmanager.transport.enabled }}
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: {{ printf "%s-transport-cert" (include "infinispan-helm-charts.name" .) }}
  annotations:
    {{- include "infinispan-helm-charts.annotations" . | nindent 4 }}
  labels:
    app: infinispan-transport-cert
    {{- include "infinispan-helm-charts.labels" . | nindent 4 }}
spec:
  secretName: {{ .Values.deploy.ssl.transportSecretName }}
  commonName: {{ include "infinispan-helm-charts.name" . }}
  
  dnsNames:
    # Transport only needs internal cluster DNS
    - {{ include "infinispan-helm-charts.name" . }}
    - {{ include "infinispan-helm-charts.name" . }}.{{ .Release.Namespace }}
    - {{ printf "%s-ping.%s.svc.%s" (include "infinispan-helm-charts.name" .) .Release.Namespace .Values.deploy.clusterDomain }}
    - {{ include "infinispan-helm-charts.name" . }}.{{ .Release.Namespace }}.svc.{{ .Values.deploy.clusterDomain }}
    - "*.{{ printf "%s-ping.%s.svc.%s" (include "infinispan-helm-charts.name" .) .Release.Namespace .Values.deploy.clusterDomain }}"
    
    {{- range .Values.deploy.ssl.certmanager.transport.additionalDnsNames }}
    - {{ . }}
    {{- end }}
  
  issuerRef:
    {{- if .Values.deploy.ssl.certmanager.issuerRef }}
    {{- toYaml .Values.deploy.ssl.certmanager.issuerRef | nindent 4 }}
    {{- else }}
    name: selfsigned-issuer
    kind: ClusterIssuer
    {{- end }}
{{- end }}
{{- end }}
```

### Step 2: Simplified values.yaml

```yaml
ssl:
  endpointSecretName: ""
  transportSecretName: ""
  certmanager:
    # Enable cert-manager integration for automatic certificate generation
    enabled: false
    
    # IssuerRef for certificate generation (optional)
    # If not specified, defaults to 'selfsigned-issuer' ClusterIssuer
    # issuerRef:
    #   name: letsencrypt-prod
    #   kind: ClusterIssuer
    
    endpoint:
      # Enable endpoint certificate generation
      enabled: false
      
      # Additional DNS names to include in the certificate (optional)
      # The following are automatically included:
      # - Chart name
      # - Chart name with namespace
      # - Ping service DNS
      # - Main service DNS (if expose.type is set)
      # - Route/Ingress hostname (if configured)
      additionalDnsNames: []
      # - custom.example.com
      # - another.example.com
    
    transport:
      # Enable transport certificate generation (for JGroups encryption)
      enabled: false
      
      # Additional DNS names for transport certificate (optional)
      additionalDnsNames: []
```

### Step 3: Implementation Tasks

#### Phase 1: Core Template Changes
1. **Update certificate.yaml**
   - Replace hardcoded "infinispan" with `{{ include "infinispan-helm-charts.name" . }}`
   - Add conditional blocks for service DNS inclusion
   - Add conditional blocks for route/ingress hostname inclusion
   - Add loop for additionalDnsNames
   - Add default issuerRef logic

2. **Test DNS Name Generation**
   - Verify all DNS names are correctly computed
   - Test with different expose.type values
   - Test with custom hostnames

#### Phase 2: Values Configuration
1. **Simplify values.yaml**
   - Remove commented issuerRef from endpoint/transport sections
   - Move issuerRef to top-level certmanager section
   - Add additionalDnsNames arrays
   - Add clear comments explaining auto-computation

2. **Update values.schema.json**
   - Add schema for new additionalDnsNames arrays
   - Update issuerRef location in schema
   - Add descriptions for auto-computed behavior

#### Phase 3: Documentation
1. **Update README.md**
   - Document cert-manager integration
   - Explain auto-computed DNS names
   - Provide configuration examples
   - Document issuerRef options

2. **Add Examples**
   - Basic self-signed certificate
   - Let's Encrypt with Route
   - Custom DNS names
   - Transport encryption

#### Phase 4: Testing
1. **Test Scenarios**
   - Default configuration (no expose)
   - With Route exposure
   - With LoadBalancer exposure
   - With custom hostname
   - With additionalDnsNames
   - Transport certificate generation

2. **Validation**
   - Verify certificate creation
   - Check DNS names in generated certificates
   - Test actual TLS connections
   - Validate with different issuers

## Benefits of This Approach

### For Users
- ✅ **Zero configuration for common cases** - Just enable and it works
- ✅ **Intelligent defaults** - Automatically includes all necessary DNS names
- ✅ **Flexibility** - Can override or extend with additionalDnsNames
- ✅ **Clear documentation** - Understands what's automatic vs manual

### For Maintainers
- ✅ **Less support burden** - Fewer configuration questions
- ✅ **Cleaner code** - Logic in templates, not scattered in values
- ✅ **Better testing** - Clear test cases for different scenarios
- ✅ **Future-proof** - Easy to add new auto-computed names

## Migration Path

For users of the current PR implementation:
1. Remove `commonName` from values.yaml (now auto-computed)
2. Move `issuerRef` to top-level `certmanager` section
3. Add any custom DNS names to `additionalDnsNames` array

## Next Steps

1. Create working branch from nierhoff-certmanager
2. Implement certificate.yaml changes
3. Update values.yaml
4. Update values.schema.json
5. Test with various configurations
6. Update documentation
7. Request review from maintainers
