NAME: infinispan-example
LAST DEPLOYED: Thu Apr 23 11:26:53 2026
NAMESPACE: helm-lb
STATUS: deployed
REVISION: 1
NOTES:
## Thank you for installing infinispan.

Release name: infinispan-example.
Namespace: helm-lb
Cluster Name: infinispan-example
Replicas: 1

To learn more about the release, try:

    helm status infinispan-example -n helm-lb
    helm get all infinispan-example -n helm-lb

## Connecting Info
Cluster infinispan-example is exposed with LoadBalancer

To get the LoadBalancer address:

    LB_ADDRESS=$(oc get svc infinispan-example -n helm-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
    [ -z "$LB_ADDRESS" ] && LB_ADDRESS=$(oc get svc infinispan-example -n helm-lb -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
    echo $LB_ADDRESS
REST API example:

  $ LB_ADDRESS=$(oc get svc infinispan-example -n helm-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
  $ [ -z "$LB_ADDRESS" ] && LB_ADDRESS=$(oc get svc infinispan-example -n helm-lb -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
  $ PASSWORD=$(oc get secret infinispan-example-generated-secret -n helm-lb -o jsonpath='{.data.password}' | base64 -d)
  $ curl --digest -u developer:$PASSWORD http://$LB_ADDRESS:11222/rest/v3/caches

Hot Rod client configuration (hotrod-client.properties):

  # Server connection
  infinispan.client.hotrod.server_list=$LB_ADDRESS:11222
  infinispan.client.hotrod.intelligence=BASIC
  
  # Authentication
  infinispan.client.hotrod.use_auth=true
  infinispan.client.hotrod.sasl_mechanism=DIGEST-SHA-256
  infinispan.client.hotrod.auth_username=developer
  infinispan.client.hotrod.auth_password=$PASSWORD
  infinispan.client.hotrod.auth_realm=default

Security is enabled with auto-generated credentials.
Default users created: developer (with admin role), monitor (for metrics)

To retrieve the password:

  $ oc get secret infinispan-example-generated-secret -n helm-lb -o jsonpath='{.data.password}' | base64 -d

For more information, visit:
  - Documentation: https://infinispan.org/documentation/
  - GitHub: https://github.com/infinispan/infinispan-helm-charts
