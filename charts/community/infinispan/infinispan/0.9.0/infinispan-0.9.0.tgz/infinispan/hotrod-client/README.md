# Infinispan Hot Rod Client Test

A simple Java application to test Hot Rod connectivity to an Infinispan cluster deployed via Helm.

## Prerequisites

- Java 21 or higher
- Maven 3.6 or higher
- Access to an Infinispan cluster

## Building

```bash
cd hotrod-client
mvn clean package
```

## Configuration

The client uses a **properties file** for configuration: `src/main/resources/hotrod-client.properties`

### Default Configuration

Edit `hotrod-client.properties` to configure your connection:

```properties
# Server connection
infinispan.client.hotrod.server_list=localhost:11222

# Authentication
infinispan.client.hotrod.use_auth=true
infinispan.client.hotrod.sasl_mechanism=SCRAM-SHA-512
infinispan.client.hotrod.auth_username=developer
infinispan.client.hotrod.auth_password=changeme
infinispan.client.hotrod.auth_realm=default

# SSL/TLS (uncomment to enable)
#infinispan.client.hotrod.use_ssl=true
#infinispan.client.hotrod.sni_host_name=your-route-hostname
#infinispan.client.hotrod.trust_store_file_name=/path/to/truststore.jks
#infinispan.client.hotrod.trust_store_password=truststore-password
```

### Environment Variable Overrides

You can override properties using environment variables (useful for CI/CD):

| Variable | Overrides Property |
|----------|-------------------|
| `INFINISPAN_HOST` | `infinispan.client.hotrod.server_list` (host part) |
| `INFINISPAN_PORT` | `infinispan.client.hotrod.server_list` (port part) |
| `INFINISPAN_USERNAME` | `infinispan.client.hotrod.auth_username` |
| `INFINISPAN_PASSWORD` | `infinispan.client.hotrod.auth_password` |
| `INFINISPAN_USE_SSL` | `infinispan.client.hotrod.use_ssl` |
| `INFINISPAN_SNI_HOST` | `infinispan.client.hotrod.sni_host_name` |
| `INFINISPAN_TRUSTSTORE` | `infinispan.client.hotrod.trust_store_file_name` |
| `INFINISPAN_TRUSTSTORE_PASSWORD` | `infinispan.client.hotrod.trust_store_password` |

## Running

### Method 1: Using Properties File Only

1. Edit `src/main/resources/hotrod-client.properties`
2. Run:

```bash
mvn clean compile exec:java
```

### Method 2: Using Environment Variables

```bash
# Override properties with environment variables
export INFINISPAN_HOST=your-host
export INFINISPAN_PORT=11222
export INFINISPAN_USERNAME=developer
export INFINISPAN_PASSWORD=your-password

mvn exec:java
```

### Method 3: Using the Run Script

```bash
# Edit run.sh with your connection details
chmod +x run.sh
./run.sh
```

## Testing with Helm-deployed Infinispan

### 1. Get the connection details from NOTES.txt

After deploying Infinispan with Helm, the NOTES.txt will show you the connection details.

### 2. For Route exposure (OpenShift):

**Option A: Edit properties file**

Edit `src/main/resources/hotrod-client.properties`:
```properties
infinispan.client.hotrod.server_list=your-route-host:443
infinispan.client.hotrod.auth_username=developer
infinispan.client.hotrod.auth_password=your-password
infinispan.client.hotrod.use_ssl=true
infinispan.client.hotrod.sni_host_name=your-route-host
```

**Option B: Use environment variables**

```bash
ROUTE_HOST=$(oc get route infinispan -n default -o jsonpath='{.spec.host}')
PASSWORD=$(kubectl get secret infinispan-generated-secret -n default -o jsonpath='{.data.password}' | base64 -d)

export INFINISPAN_HOST=$ROUTE_HOST
export INFINISPAN_PORT=443
export INFINISPAN_USERNAME=developer
export INFINISPAN_PASSWORD=$PASSWORD
export INFINISPAN_USE_SSL=true
export INFINISPAN_SNI_HOST=$ROUTE_HOST

mvn exec:java
```

### 3. For LoadBalancer exposure:

**Option A: Edit properties file**

Edit `src/main/resources/hotrod-client.properties`:
```properties
infinispan.client.hotrod.server_list=your-lb-address:11222
infinispan.client.hotrod.auth_username=developer
infinispan.client.hotrod.auth_password=your-password
```

**Option B: Use environment variables**

```bash
LB_ADDRESS=$(kubectl get svc infinispan -n default -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
[ -z "$LB_ADDRESS" ] && LB_ADDRESS=$(kubectl get svc infinispan -n default -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
PASSWORD=$(kubectl get secret infinispan-generated-secret -n default -o jsonpath='{.data.password}' | base64 -d)

export INFINISPAN_HOST=$LB_ADDRESS
export INFINISPAN_PORT=11222
export INFINISPAN_USERNAME=developer
export INFINISPAN_PASSWORD=$PASSWORD

mvn exec:java
```

### 4. For port-forwarding (no external exposure):

**Option A: Edit properties file**

Keep defaults in `src/main/resources/hotrod-client.properties`:
```properties
infinispan.client.hotrod.server_list=localhost:11222
infinispan.client.hotrod.auth_username=developer
infinispan.client.hotrod.auth_password=your-password
```

**Option B: Use environment variables**

```bash
# Start port forwarding in a separate terminal
kubectl port-forward -n default svc/infinispan 11222:11222

# Get password and run
PASSWORD=$(kubectl get secret infinispan-generated-secret -n default -o jsonpath='{.data.password}' | base64 -d)
export INFINISPAN_PASSWORD=$PASSWORD

mvn exec:java
```

## Expected Output

```
=================================================
Infinispan Hot Rod Client Test
=================================================
Loaded configuration from hotrod-client.properties

Connection Configuration:
-------------------------------------------------
  Server: localhost:11222
  Username: developer
  SSL: false
-------------------------------------------------

Connecting to Infinispan cluster...
✓ Connected successfully!

Available caches (0):
-------------------------------------------------
  (no caches defined)
-------------------------------------------------

Cluster information:
-------------------------------------------------
  Servers: [localhost:11222]
-------------------------------------------------

✓ Test completed successfully!
```

## Available Hot Rod Client Properties

For a complete list of available properties, see the [Infinispan Hot Rod Client documentation](https://infinispan.org/docs/stable/titles/hotrod_java/hotrod_java.html#hotrod_configuration).

Common properties include:
- `infinispan.client.hotrod.server_list` - Server addresses
- `infinispan.client.hotrod.use_auth` - Enable authentication
- `infinispan.client.hotrod.auth_username` - Username
- `infinispan.client.hotrod.auth_password` - Password
- `infinispan.client.hotrod.sasl_mechanism` - SASL mechanism (SCRAM-SHA-512, DIGEST-MD5, etc.)
- `infinispan.client.hotrod.use_ssl` - Enable SSL/TLS
- `infinispan.client.hotrod.sni_host_name` - SNI hostname
- `infinispan.client.hotrod.trust_store_file_name` - Truststore path
- `infinispan.client.hotrod.connection_pool.max_active` - Max connections
- `infinispan.client.hotrod.connect_timeout` - Connection timeout (ms)
- `infinispan.client.hotrod.socket_timeout` - Socket timeout (ms)

## Troubleshooting

### Connection refused
- Check if the Infinispan cluster is running
- Verify the hostname and port
- Check if port-forwarding is active (if using it)

### Authentication failed
- Verify the username and password
- Check if the secret exists: `kubectl get secret infinispan-generated-secret -n default`

### SSL/TLS errors
- Ensure `INFINISPAN_USE_SSL=true` is set
- Verify the SNI hostname matches the route hostname
- Check if truststore is properly configured