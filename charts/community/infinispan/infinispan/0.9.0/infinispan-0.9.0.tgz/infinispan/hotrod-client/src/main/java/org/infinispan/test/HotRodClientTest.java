package org.infinispan.test;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.client.hotrod.annotation.ClientCacheEntryCreated;
import org.infinispan.client.hotrod.annotation.ClientCacheEntryModified;
import org.infinispan.client.hotrod.annotation.ClientCacheEntryRemoved;
import org.infinispan.client.hotrod.annotation.ClientListener;
import org.infinispan.client.hotrod.configuration.Configuration;
import org.infinispan.client.hotrod.configuration.ConfigurationBuilder;
import org.infinispan.client.hotrod.event.ClientCacheEntryCreatedEvent;
import org.infinispan.client.hotrod.event.ClientCacheEntryModifiedEvent;
import org.infinispan.client.hotrod.event.ClientCacheEntryRemovedEvent;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

/**
 * Simple Hot Rod client to test Infinispan connectivity.
 * This client connects to an Infinispan cluster and retrieves the list of available caches.
 * 
 * Configuration is loaded from hotrod-client.properties file.
 * You can override properties using environment variables or system properties.
 */
public class HotRodClientTest {

    private static final String PROPERTIES_FILE = "hotrod-client.properties";

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("Infinispan Hot Rod Client Test");
        System.out.println("=================================================\n");

        // Load properties from file
        Properties properties = loadProperties();
        
        // Allow environment variables to override properties
        //overrideFromEnvironment(properties);
        
        // Display connection information
        displayConnectionInfo(properties);

        RemoteCacheManager cacheManager = null;
        try {
            // Create configuration from properties
            System.out.println("Connecting to Infinispan cluster...");
            Configuration configuration = new ConfigurationBuilder()
                    .withProperties(properties)
                    .build();
            
            cacheManager = new RemoteCacheManager(configuration);

            // Test connection by getting cache names
            System.out.println("✓ Connected successfully!\n");
            
            Set<String> cacheNames = cacheManager.getCacheNames();

            System.out.println("Available caches (" + cacheNames.size() + "):");
            System.out.println("-------------------------------------------------");
            if (cacheNames.isEmpty()) {
                System.out.println("  (no caches defined)");
            } else {
                for (String cacheName : cacheNames) {
                    System.out.println("  - " + cacheName);
                }
            }
            System.out.println("-------------------------------------------------\n");

            // Create dissectorTest cache
            System.out.println("Creating cache 'dissectorTest'...");
            RemoteCache<String, String> dissectorCache = cacheManager.administration().getOrCreateCache("dissectorTest", (String) null);
            System.out.println("✓ Cache 'dissectorTest' created successfully!\n");

            // Clear the cache
            System.out.println("Clearing cache 'dissectorTest'...");
            dissectorCache.clear();
            System.out.println("✓ Cache cleared!\n");

            // Register event listener
            System.out.println("Registering cache event listener...");
            CacheEventListener listener = new CacheEventListener();
            dissectorCache.addClientListener(listener);
            System.out.println("✓ Event listener registered!\n");

            // Insert 10 Cars movie characters
            System.out.println("Inserting Cars movie characters...");
            System.out.println("-------------------------------------------------");

            dissectorCache.put("Lightning McQueen", "A hotshot rookie race car who learns the importance of friendship and humility in Radiator Springs");
            System.out.println("  ✓ Added Lightning McQueen");

            dissectorCache.put("Mater", "A rusty tow truck with a heart of gold, best friend to Lightning McQueen and master of tall tales");
            System.out.println("  ✓ Added Mater");

            dissectorCache.put("Sally Carrera", "A beautiful blue Porsche 911 and the town attorney of Radiator Springs who becomes Lightning's love interest");
            System.out.println("  ✓ Added Sally Carrera");

            dissectorCache.put("Doc Hudson", "The wise Hudson Hornet who was once a racing legend, now serves as Radiator Springs' judge and doctor");
            System.out.println("  ✓ Added Doc Hudson");

            dissectorCache.put("Luigi", "An excitable Italian Fiat 500 who runs a tire shop and is a devoted Ferrari fan");
            System.out.println("  ✓ Added Luigi");

            dissectorCache.put("Guido", "Luigi's best friend and assistant, a small forklift who dreams of performing a real pit stop");
            System.out.println("  ✓ Added Guido");

            dissectorCache.put("Ramone", "A 1959 Impala lowrider who runs Ramone's House of Body Art and loves changing his paint job daily");
            System.out.println("  ✓ Added Ramone");

            dissectorCache.put("Flo", "A stylish 1950s show car who owns Flo's V8 Cafe and is married to Ramone");
            System.out.println("  ✓ Added Flo");

            dissectorCache.put("Sheriff", "A 1949 Mercury Police Cruiser who keeps law and order in Radiator Springs with his gentle demeanor");
            System.out.println("  ✓ Added Sheriff");

            dissectorCache.put("Fillmore", "A peace-loving 1960s VW Bus who runs an organic fuel shop and believes in conspiracies");
            System.out.println("  ✓ Added Fillmore");

            System.out.println("-------------------------------------------------");
            System.out.println("✓ Successfully inserted " + dissectorCache.size() + " characters into cache!\n");

            // Get cluster information
            System.out.println("Cluster information:");
            System.out.println("-------------------------------------------------");
            System.out.println("  Servers: " + configuration.servers());
            System.out.println("-------------------------------------------------\n");

            System.out.println("✓ Test completed successfully!");

        } catch (Exception e) {
            System.err.println("✗ Error connecting to Infinispan:");
            System.err.println("  " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } finally {
            if (cacheManager != null) {
                cacheManager.stop();
            }
        }
    }

    /**
     * Load properties from the hotrod-client.properties file
     */
    private static Properties loadProperties() {
        Properties properties = new Properties();
        
        try (InputStream input = HotRodClientTest.class.getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {
            
            if (input == null) {
                System.err.println("Unable to find " + PROPERTIES_FILE);
                System.err.println("Using default configuration...\n");
                return properties;
            }
            
            properties.load(input);
            System.out.println("Loaded configuration from " + PROPERTIES_FILE + "\n");
            
            // Debug: Check if truststore file can be found
            String truststorePath = properties.getProperty("infinispan.client.hotrod.trust_store_file_name");
            if (truststorePath != null && !truststorePath.isEmpty()) {
                java.net.URL truststoreUrl = HotRodClientTest.class.getClassLoader().getResource(truststorePath);
                System.out.println("Truststore configuration:");
                System.out.println("  File name: " + truststorePath);
                System.out.println("  Found in classpath: " + (truststoreUrl != null ? truststoreUrl : "NOT FOUND"));
                System.out.println();
            }
            
        } catch (IOException e) {
            System.err.println("Error loading properties file: " + e.getMessage());
            System.err.println("Using default configuration...\n");
        }
        
        return properties;
    }

    /**
     * Override properties with environment variables if they exist
     */
    private static void overrideFromEnvironment(Properties properties) {
        // Server list
        String host = System.getenv("INFINISPAN_HOST");
        String port = System.getenv("INFINISPAN_PORT");
        if (host != null && port != null) {
            properties.setProperty("infinispan.client.hotrod.server_list", host + ":" + port);
        } else if (host != null) {
            properties.setProperty("infinispan.client.hotrod.server_list", host + ":11222");
        }
        
        // Authentication
        String username = System.getenv("INFINISPAN_USERNAME");
        if (username != null) {
            properties.setProperty("infinispan.client.hotrod.auth_username", username);
        }
        
        String password = System.getenv("INFINISPAN_PASSWORD");
        if (password != null) {
            properties.setProperty("infinispan.client.hotrod.auth_password", password);
        }
        
        // SSL
        String useSsl = System.getenv("INFINISPAN_USE_SSL");
        if (useSsl != null) {
            properties.setProperty("infinispan.client.hotrod.use_ssl", useSsl);
        }
        
        String sniHost = System.getenv("INFINISPAN_SNI_HOST");
        if (sniHost != null) {
            properties.setProperty("infinispan.client.hotrod.sni_host_name", sniHost);
        }
        
        String trustStore = System.getenv("INFINISPAN_TRUSTSTORE");
        if (trustStore != null) {
            properties.setProperty("infinispan.client.hotrod.trust_store_file_name", trustStore);
        }
        
        String trustStorePassword = System.getenv("INFINISPAN_TRUSTSTORE_PASSWORD");
        if (trustStorePassword != null) {
            properties.setProperty("infinispan.client.hotrod.trust_store_password", trustStorePassword);
        }
    }

    /**
     * Display connection information
     */
    private static void displayConnectionInfo(Properties properties) {
        System.out.println("Connection Configuration:");
        System.out.println("-------------------------------------------------");
        System.out.println("  Server: " + properties.getProperty("infinispan.client.hotrod.server_list", "not set"));
        System.out.println("  Username: " + properties.getProperty("infinispan.client.hotrod.auth_username", "not set"));
        System.out.println("  SSL: " + properties.getProperty("infinispan.client.hotrod.use_ssl", "false"));
        
        String sniHost = properties.getProperty("infinispan.client.hotrod.sni_host_name");
        if (sniHost != null && !sniHost.isEmpty()) {
            System.out.println("  SNI Host: " + sniHost);
        }
        System.out.println("-------------------------------------------------\n");
    }

    /**
     * Client listener for cache events
     */
    @ClientListener
    public static class CacheEventListener {

        @ClientCacheEntryCreated
        public void handleCreatedEvent(ClientCacheEntryCreatedEvent<String> event) {
            System.out.println("  [EVENT] Entry CREATED: key=" + event.getKey());
        }

        @ClientCacheEntryModified
        public void handleModifiedEvent(ClientCacheEntryModifiedEvent<String> event) {
            System.out.println("  [EVENT] Entry MODIFIED: key=" + event.getKey());
        }

        @ClientCacheEntryRemoved
        public void handleRemovedEvent(ClientCacheEntryRemovedEvent<String> event) {
            System.out.println("  [EVENT] Entry REMOVED: key=" + event.getKey());
        }
    }
}

// Made with Bob
